-- Create the Database
CREATE DATABASE IF NOT EXISTS stakeholder_management;
USE stakeholder_management;

-- Create Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    role ENUM('superuser', 'admin', 'manager', 'user') NOT NULL
);

-- Create Stakeholders Table
CREATE TABLE stakeholders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    surname VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    company VARCHAR(100) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    phone VARCHAR(15),
    email VARCHAR(100) UNIQUE,
    preferred_communication_channel INT,
    classification VARCHAR(100),
    rating FLOAT CHECK (rating BETWEEN 0 AND 5),
    relationship_manager INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (relationship_manager) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (preferred_communication_channel) REFERENCES communication_channels(id)
);

-- Create Engagements Table
CREATE TABLE engagements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stakeholder_id INT NOT NULL,
    engagement_type INT NOT NULL,
    date_of_engagement DATE NOT NULL,
    details TEXT,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stakeholder_id) REFERENCES stakeholders(id) ON DELETE CASCADE,
    FOREIGN KEY (engagement_type) REFERENCES engagement_types(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Create Preferences Table
CREATE TABLE preferences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    theme ENUM('light', 'dark') DEFAULT 'light',
    other_options JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create Stakeholder_Status_History Table
CREATE TABLE stakeholder_status_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stakeholder_id INT NOT NULL,
    previous_status VARCHAR(100),
    new_status VARCHAR(100),
    changed_by INT NOT NULL,
    change_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stakeholder_id) REFERENCES stakeholders(id) ON DELETE CASCADE,
    FOREIGN KEY (changed_by) REFERENCES users(id)
);

-- Create Engagement_Types Table
CREATE TABLE engagement_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
);

-- Create Communication_Channels Table
CREATE TABLE communication_channels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
);

-- Pre-populate Engagement_Types
INSERT INTO engagement_types (name) VALUES 
('Meeting'), ('Phone Call'), ('Email'), ('Site Visit'), ('Virtual Call');

-- Pre-populate Communication_Channels
INSERT INTO communication_channels (name) VALUES 
('Email'), ('Phone'), ('Text Message'), ('In-App Messaging'), ('Social Media');

-- Pre-populate Users (Optional for Testing)
INSERT INTO users (username, full_name, email, password, role) VALUES
('admin', 'Admin User', 'admin@example.com', MD5('password123'), 'superuser'),
('jdoe', 'John Doe', 'johndoe@example.com', MD5('password123'), 'manager'),
('asmith', 'Alice Smith', 'alicesmith@example.com', MD5('password123'), 'user');

-- Sample Stakeholders (Optional for Testing)
INSERT INTO stakeholders (surname, first_name, company, designation, phone, email, preferred_communication_channel, classification, rating, relationship_manager)
VALUES
('Brown', 'Jane', 'TechCorp', 'CEO', '1234567890', 'jane.brown@techcorp.com', 1, 'High Value', 4.8, 2),
('Smith', 'John', 'MediCare', 'Manager', '0987654321', 'john.smith@medicare.com', 2, 'Medium Value', 3.9, 3);

-- Sample Preferences (Optional for Testing)
INSERT INTO preferences (user_id, theme, other_options) VALUES
(1, 'dark', '{"notifications": true, "language": "en"}'),
(2, 'light', '{"notifications": false, "language": "fr"}');

-- Sample Engagements (Optional for Testing)
INSERT INTO engagements (stakeholder_id, engagement_type, date_of_engagement, details, created_by)
VALUES
(1, 1, '2024-11-10', 'Initial Meeting', 2),
(2, 2, '2024-11-12', 'Follow-up Call', 3);
