-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2025 at 01:21 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stakeholder_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `approvals`
--

CREATE TABLE `approvals` (
  `id` int(11) NOT NULL,
  `request_type` enum('stakeholder_assignment','classification_change') NOT NULL,
  `request_data` text NOT NULL,
  `requested_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `communication_channels`
--

CREATE TABLE `communication_channels` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `engagement_types`
--

CREATE TABLE `engagement_types` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stakeholders`
--

CREATE TABLE `stakeholders` (
  `id` int(11) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `organization` varchar(150) DEFAULT NULL,
  `organization_type` varchar(100) DEFAULT NULL,
  `influence_level` varchar(50) DEFAULT NULL,
  `interest_level` varchar(50) DEFAULT NULL,
  `preferred_communication_channel` int(11) DEFAULT NULL,
  `classification` varchar(100) DEFAULT NULL,
  `rating` float DEFAULT NULL CHECK (`rating` between 0 and 5),
  `relationship_manager` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approval_status` enum('pending','approved','rejected') DEFAULT 'pending',
  `status` enum('pending_approval','approved','pending_review','pending_update','pending_retirement','retired') DEFAULT 'pending_approval',
  `account_status` enum('active','retired') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stakeholders`
--

INSERT INTO `stakeholders` (`id`, `s_name`, `first_name`, `location`, `designation`, `contact`, `phone`, `email`, `organization`, `organization_type`, `influence_level`, `interest_level`, `preferred_communication_channel`, `classification`, `rating`, `relationship_manager`, `created_at`, `approval_status`, `status`, `account_status`) VALUES
(2, 'Kuntu-Blankson, Peter', '', 'Nyamekye-Accra /Awoshie -Accra ', 'Owner (CEO)', '+233 54 413 1310', NULL, 'info@portmasterz.com', 'Portmasters Limited', 'Vendor/Partner', 'Low Influence - Relevant individuals who currently', 'High Interest - Individuals who actively support a', NULL, 'Cheer Leader', 3, 2, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(3, 'Akumpele, Gifty ', '', 'Tema Comm. 1, Opposite GWCL', 'Owner/CEO', '+2332492403636', NULL, 'royalnelgifts@gmail.com', 'Royal Nelgifts Ent. Ltd', 'Vendor/Partner', 'Low Influence - Relevant individuals who currently', 'High Interest - Individuals who actively support a', NULL, NULL, NULL, 1, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(5, 'Atakele Fortune', '', 'Azare, Bauchi State.', 'Commanding Officer/ 133 Special Force Battalion. ', '08039230425', NULL, 'fortuneobaroatakele@gmail.com', 'Nigerian Army.', 'Vendor/Partner', 'High Influence - Individuals who can influence our', 'High Interest - Individuals who actively support a', NULL, 'Fan', 3, 1, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(6, 'MBAKWE, CHIDINMA', '', 'LAGOS, NIGERIA', 'COMMERCIAL TRUST ADVISOR', '08089253366', NULL, 'Chidinma.Mbakwe@arm.com.ng', 'ARM PENSION', 'Business Clients', 'Low Influence - Relevant individuals who currently', 'High Interest - Individuals who actively support a', NULL, 'Cheer Leader', 4, 1, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(7, 'OKORJI UTCHAY', '', 'lagos, ng', 'VA;UATION TEAM', '09086595424', NULL, 'uoa.associates@gmail.com', 'UTCHAY OKORJI ASSOCIATES', 'Regulators', 'High Influence - Individuals who can influence our', 'High Interest - Individuals who actively support a', NULL, NULL, NULL, 2, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(8, 'Chike Anii', '', 'Lagos', 'Aviation Manager', '08060572385', NULL, 'Chikere Ani <Chikere.Ani@nnpcgroup.com>', 'NRL', 'Business Clients', 'Low Influence - Relevant individuals who currently', 'High Interest - Individuals who actively support a', NULL, NULL, NULL, 2, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(9, 'SMITH,FRANCIS', '', 'ACCRA', 'TAX CONSULTANT', '+233 20 8159 221', NULL, 'frsers@yahoo.com', 'F&R SERVICES', 'Regulators', 'Low Influence - Relevant individuals who currently', 'High Interest - Individuals who actively support a', NULL, NULL, NULL, 2, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(10, 'AKROFI-QUARCOO, FRANK', '', 'ACCRA', 'RELATIONSHIP MANAGER', '+233 577 735 409', NULL, 'frank.akrofi@firstbankgroup.com', 'FIRST BANK GROUP', 'Business Clients', 'Low Influence - Relevant individuals who currently', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, 1, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(11, 'NYAME, CALINA', '', 'ACCRA', 'RELATIONSHIP MANAGER', '+233 202 527 772   ', NULL, 'calina.nyame@petraonline.com', 'PETRA ADVANTAGE PENSION SCHEME', 'Regulators', 'Low Influence - Relevant individuals who currently', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, NULL, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(12, 'KWAMI, HILLARY SELORM', '', 'ACCRA', 'RELATIONSHIP MANAGER', '+233 208 366 527   ', NULL, 'htomety@ssnit.org.gh', 'SOCIAL SECURITY & NATIONAL INSURANCE TRUST', 'Regulators', 'Low Influence - Relevant individuals who currently', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, 1, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(13, 'BLABOE, ISHMAEL KAMETEY', '', 'ACCRA', 'RELATIONSHIP MANAGER', '+233 559 051 048   ', NULL, 'Ishmael.kameteyblaboe@zenithbank.com.gh', 'ZENITH BANK GHANA', 'Business Clients', 'Low Influence - Relevant individuals who currently', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, NULL, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(14, 'AGAGLO, GODWIN', '', 'ACCRA', 'RELATIONSHIP MANAGER', '+233 577 735 409   ', NULL, 'gaglago@myfidelitybank.net', 'FIDELITY GHANA', 'Business Clients', 'Low Influence - Relevant individuals who currently', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, NULL, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(15, 'NARTEY, HELINA', '', 'ACCRA', 'RELATIONSHIP MANAGER', '+233 240 611 382   ', NULL, 'hnartey@firstatlanticbank.com.gh', 'FIRST NATIONAL BANK', 'Business Clients', 'Low Influence - Relevant individuals who currently', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, NULL, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(16, 'AYEDZI, VICENTIA', '', 'ACCRA', 'RELATIONSHIP MANAGER', '+233 249 966 945   ', NULL, 'vincentia.ayedzi@ubagroup.com', 'UNITED BANK OF AFRICA', 'Business Clients', 'Low Influence - Relevant individuals who currently', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, NULL, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(17, 'KETEKU, ERIC', '', 'ACCRA', 'RELATIONSHIP MANAGER', '+233 242 143 433   ', NULL, 'EKETEKU@ecobank.com', 'ECOBANK GHANA', 'Business Clients', 'Low Influence - Relevant individuals who currently', 'Low Interest - Individuals who have limited or no ', NULL, 'Cheer Leader', 3.5, 1, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(18, 'BOAKYE, ENOCH', '', 'ACCRA', 'RELATIONSHIP MANAGER', '+233 244 662 939   ', NULL, 'enoch.yiadom@bost.gov.gh', 'BOST', 'Business Clients', 'High Influence - Individuals who can influence our', 'High Interest - Individuals who actively support a', NULL, NULL, NULL, 1, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(19, 'OPPONG, JAMES', '', 'ACCRA', 'AUDIT PARTNER', '+233 547 037 044   ', NULL, 'joppong@kpmg.com', 'KPMG', 'Regulators', 'High Influence - Individuals who can influence our', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, 1, '2025-05-14 20:18:46', 'pending', 'pending_approval', 'active'),
(23, 'Olorunju Tajudeen Lasisi', '', 'Ibeju Lekki', 'Baale', '+2347061500912', NULL, 'NA', 'Iba Oloja', 'Community', 'High Influence - Individuals who can influence our', 'High Interest - Individuals who actively support a', NULL, NULL, NULL, 2, '2025-05-15 04:23:05', 'pending', 'pending_approval', 'active'),
(24, 'Engr. Moyi Mai Dunama', '', 'Abuja', 'ED Operations', 'tel:+2348033789978', NULL, 'moyi.mai-dunama@nnpcgroup.com', 'NPSC', 'Business Clients', 'High Influence - Individuals who can influence our', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, 2, '2025-05-15 04:23:05', 'pending', 'pending_approval', 'active'),
(25, 'Sagir Alhassan', '', 'Abuja', 'Manager Pipeline and Maintenance', '+2348055586620', NULL, 'sagir.alhassan@nnpcgroup.com', 'NPSC', 'Business Clients', 'High Influence - Individuals who can influence our', 'Low Interest - Individuals who have limited or no ', NULL, NULL, NULL, 1, '2025-05-15 04:23:05', 'pending', 'retired', 'retired');

-- --------------------------------------------------------

--
-- Table structure for table `stakeholder_audit_log`
--

CREATE TABLE `stakeholder_audit_log` (
  `id` int(11) NOT NULL,
  `stakeholder_id` int(11) NOT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  `performed_by` varchar(255) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stakeholder_audit_log`
--

INSERT INTO `stakeholder_audit_log` (`id`, `stakeholder_id`, `action_type`, `performed_by`, `timestamp`) VALUES
(1, 25, 'DELETE', 'Unknown', '2025-06-26 11:49:18'),
(2, 25, 'RETIRE', 'Unknown', '2025-06-26 12:00:28'),
(3, 25, 'retire_stakeholder', 'Unknown', '2025-06-26 12:18:21'),
(4, 2, 'DELETE', 'Unknown', '2025-06-26 14:16:13');

-- --------------------------------------------------------

--
-- Table structure for table `stakeholder_engagements`
--

CREATE TABLE `stakeholder_engagements` (
  `id` int(11) NOT NULL,
  `stakeholder_id` int(11) NOT NULL,
  `department` varchar(100) NOT NULL,
  `staff_full_name` varchar(100) NOT NULL,
  `interaction_date` date NOT NULL,
  `company` varchar(150) DEFAULT NULL,
  `stakeholder_type` enum('Business','Regulatory','Vendors','Community','Advocacy Group') NOT NULL,
  `stakeholder_category` enum('Cheer Leader','Uncharted','Fans','Observers') NOT NULL,
  `stakeholder_fullname` varchar(150) DEFAULT NULL,
  `in_department_db` enum('Yes','No') DEFAULT 'No',
  `interaction_nature` text DEFAULT NULL,
  `other_details` text DEFAULT NULL,
  `follow_up_action` text DEFAULT NULL,
  `follow_up_status` enum('Yes','No') DEFAULT 'No',
  `trace_score` tinyint(4) DEFAULT NULL CHECK (`trace_score` between 1 and 5),
  `relationship_manager_id` int(11) DEFAULT NULL,
  `relationship_manager_email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `attachment_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stakeholder_engagements`
--

INSERT INTO `stakeholder_engagements` (`id`, `stakeholder_id`, `department`, `staff_full_name`, `interaction_date`, `company`, `stakeholder_type`, `stakeholder_category`, `stakeholder_fullname`, `in_department_db`, `interaction_nature`, `other_details`, `follow_up_action`, `follow_up_status`, `trace_score`, `relationship_manager_id`, `relationship_manager_email`, `created_at`, `attachment_path`) VALUES
(3, 8, 'IT', 'Theophilus Lartey', '2025-06-16', 'NRL', 'Regulatory', 'Observers', 'Chike Anli', 'Yes', 'Virtual', 'Zoom', 'Schedule breakfast meeting', 'Yes', 4, NULL, NULL, '2025-06-17 13:01:41', NULL),
(4, 17, 'IT', 'Nii Laatey', '2025-06-16', 'ECOBANK GHANA', 'Business', 'Cheer Leader', 'Keteku Eric', 'Yes', 'Meeting', 'In-person', 'Prepare contract for review', 'No', 3, NULL, NULL, '2025-06-17 13:26:21', NULL),
(5, 17, 'IT', 'Theophilus Lartey', '2025-06-11', 'ECOBANK GHANA', 'Business', 'Cheer Leader', 'Keteku Eric', 'Yes', 'Face-to-Face', '', 'Prepare SLA for commitment between parties', 'No', 4, NULL, NULL, '2025-06-23 09:22:56', NULL),
(6, 6, 'IT', 'Nii Laatey', '2025-06-17', 'ARM PENSION', 'Business', 'Observers', 'Mbakwe Chidinma', 'Yes', 'In-Person', '', 'Consult with internal clients over next steps for onboarding', 'No', 3, NULL, NULL, '2025-06-26 14:22:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` enum('superuser','admin','manager','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `full_name`, `email`, `password`, `created_at`, `role`) VALUES
(1, 'Nii_Laatey', 'Nii Laatey', 'niilaatey@sms.com', '$2y$10$RN/qQb4CiE5XX5Ls4suPxumEONvjR6.hagaRE41xCTZZRiNhxQwUu', '2025-03-12 01:03:03', 'superuser'),
(2, 'demo_user', 'Demo User', 'demo@sms.com', '$2y$10$qae.YeFegIAd.1.bm3MAzOOOr7PrvlHe2KQoHnbTv.4/Ak2dmMLk.', '2025-03-12 10:13:53', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approvals`
--
ALTER TABLE `approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requested_by` (`requested_by`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `communication_channels`
--
ALTER TABLE `communication_channels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `engagement_types`
--
ALTER TABLE `engagement_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `stakeholders`
--
ALTER TABLE `stakeholders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_relationship_manager` (`relationship_manager`);

--
-- Indexes for table `stakeholder_audit_log`
--
ALTER TABLE `stakeholder_audit_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stakeholder_engagements`
--
ALTER TABLE `stakeholder_engagements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_stakeholder` (`stakeholder_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approvals`
--
ALTER TABLE `approvals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `communication_channels`
--
ALTER TABLE `communication_channels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `engagement_types`
--
ALTER TABLE `engagement_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stakeholders`
--
ALTER TABLE `stakeholders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `stakeholder_audit_log`
--
ALTER TABLE `stakeholder_audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `stakeholder_engagements`
--
ALTER TABLE `stakeholder_engagements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `approvals`
--
ALTER TABLE `approvals`
  ADD CONSTRAINT `approvals_ibfk_1` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `approvals_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `stakeholders`
--
ALTER TABLE `stakeholders`
  ADD CONSTRAINT `fk_relationship_manager` FOREIGN KEY (`relationship_manager`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `stakeholder_engagements`
--
ALTER TABLE `stakeholder_engagements`
  ADD CONSTRAINT `fk_stakeholder` FOREIGN KEY (`stakeholder_id`) REFERENCES `stakeholders` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
