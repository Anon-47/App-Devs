-- database/schema.sql

CREATE DATABASE IF NOT EXISTS stakeholder_management;

USE stakeholder_management;

-- Table for storing user accounts
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,  -- Passwords will be hashed
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Update to users table to include role
ALTER TABLE users ADD COLUMN role ENUM('superuser', 'administrator', 'manager', 'user') DEFAULT 'user';

-- Table for stakeholders
CREATE TABLE IF NOT EXISTS stakeholders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50),  -- Example: client, partner, vendor, etc.
    rating DECIMAL(3, 2) DEFAULT 0.00,  -- Rating out of 5.00
    status VARCHAR(20) DEFAULT 'active',  -- Example: active, retired
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Table for tracking stakeholder activities
CREATE TABLE IF NOT EXISTS stakeholder_activities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stakeholder_id INT NOT NULL,
    description TEXT NOT NULL,  -- Activity description
    activity_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stakeholder_id) REFERENCES stakeholders(id)
);

-- You can add more tables here for advanced features like tasks, attachments, etc.
