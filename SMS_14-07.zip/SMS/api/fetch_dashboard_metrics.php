<?php
header('Content-Type: application/json');

include_once '../includes/config.php';
include_once '../includes/session.php';

$role = $_SESSION['role'] ?? 'user';
$user_id = $_SESSION['user_id'] ?? null;
$department = $_SESSION['department'] ?? null;

$filters = "WHERE s.account_status = 'active'";
$params = [];

if ($role === 'user') {
    $filters .= " AND s.relationship_manager = :user_id";
    $params['user_id'] = $user_id;
} elseif ($role === 'manager' && $department) {
    $filters .= " AND u.department = :department";
    $params['department'] = $department;
}

// Total Stakeholders
$stmt = $pdo->prepare("SELECT COUNT(*) FROM stakeholders s LEFT JOIN users u ON s.relationship_manager = u.id $filters");
$stmt->execute($params);
$total_stakeholders = $stmt->fetchColumn();

// This Month’s Engagements
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM stakeholder_engagements se
    JOIN stakeholders s ON se.stakeholder_id = s.id
    LEFT JOIN users u ON s.relationship_manager = u.id
    $filters AND MONTH(se.interaction_date) = MONTH(CURDATE()) AND YEAR(se.interaction_date) = YEAR(CURDATE())
");
$stmt->execute($params);
$monthly_engagements = $stmt->fetchColumn();

// Average Rating
$stmt = $pdo->prepare("SELECT AVG(s.rating) FROM stakeholders s LEFT JOIN users u ON s.relationship_manager = u.id $filters");
$stmt->execute($params);
$average_rating = round($stmt->fetchColumn(), 1);

// Top Classification
$stmt = $pdo->prepare("SELECT s.classification, COUNT(*) AS count FROM stakeholders s LEFT JOIN users u ON s.relationship_manager = u.id $filters GROUP BY s.classification ORDER BY count DESC LIMIT 1");
$stmt->execute($params);
$top_classification = $stmt->fetch(PDO::FETCH_ASSOC)['classification'] ?? null;

// Top RM
$top_rm = null;
if (in_array($role, ['superuser', 'admin'])) {
    $stmt = $pdo->query("
        SELECT u.full_name, COUNT(*) AS engagements 
        FROM stakeholder_engagements se 
        JOIN stakeholders s ON se.stakeholder_id = s.id 
        JOIN users u ON s.relationship_manager = u.id 
        GROUP BY u.id 
        ORDER BY engagements DESC 
        LIMIT 1
    ");
    $top_rm = $stmt->fetch(PDO::FETCH_ASSOC)['full_name'] ?? null;
}

// Engagements by RM
$engagements_by_rm = [];
if (in_array($role, ['superuser', 'admin', 'manager'])) {
    $stmt = $pdo->prepare("
        SELECT u.full_name AS rm, COUNT(*) AS count
        FROM stakeholder_engagements se
        JOIN stakeholders s ON se.stakeholder_id = s.id
        JOIN users u ON s.relationship_manager = u.id
        $filters
        GROUP BY s.relationship_manager
    ");
    $stmt->execute($params);
    $engagements_by_rm = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Classification distribution
$stmt = $pdo->prepare("
    SELECT s.classification, COUNT(*) AS count
    FROM stakeholders s 
    LEFT JOIN users u ON s.relationship_manager = u.id
    $filters
    GROUP BY s.classification
");
$stmt->execute($params);
$classification_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Stakeholders per Department
$stakeholders_per_department = [];
if (in_array($role, ['superuser', 'admin'])) {
    $stmt = $pdo->prepare("
        SELECT u.department, COUNT(*) AS stakeholder_count
        FROM stakeholders s
        JOIN users u ON s.relationship_manager = u.id
        WHERE s.account_status = 'active'
        GROUP BY u.department
    ");
    $stmt->execute();
    $stakeholders_per_department = $stmt->fetchAll(PDO::FETCH_ASSOC);
} elseif ($role === 'manager' && $department) {
    $stmt = $pdo->prepare("
        SELECT u.department, COUNT(*) AS stakeholder_count
        FROM stakeholders s
        JOIN users u ON s.relationship_manager = u.id
        WHERE s.account_status = 'active' AND u.department = :department
        GROUP BY u.department
    ");
    $stmt->execute(['department' => $department]);
    $stakeholders_per_department = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// ✅ Final output (ONLY ONCE!)
$response_array = [
    'total_stakeholders' => $total_stakeholders,
    'monthly_engagements' => $monthly_engagements,
    'average_rating' => $average_rating,
    'top_classification' => $top_classification,
    'top_rm' => $top_rm,
    'engagements_by_rm' => $engagements_by_rm,
    'classification_distribution' => $classification_distribution,
    'stakeholders_per_department' => $stakeholders_per_department
];

echo json_encode($response_array);
exit;
?>
