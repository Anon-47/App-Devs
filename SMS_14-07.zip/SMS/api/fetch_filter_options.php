<?php
ob_clean();
header('Content-Type: application/json');
include_once '../includes/config.php';

// Fetch distinct months (format: YYYY-MM)
$months = $pdo->query("
    SELECT DISTINCT DATE_FORMAT(interaction_date, '%Y-%m') AS month_value
    FROM stakeholder_engagements
    ORDER BY month_value DESC
")->fetchAll(PDO::FETCH_COLUMN);

// Format into label/value pairs
$monthOptions = array_map(function ($month) {
    $date = DateTime::createFromFormat('Y-m', $month);
    return [
        'label' => $date->format('F Y'),
        'value' => $month
    ];
}, $months);

// Fetch Relationship Managers
$rms = $pdo->query("
    SELECT id, full_name AS name
    FROM users
    WHERE role IN ('user', 'manager', 'superuser', 'admin')
    ORDER BY full_name ASC
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch Classifications
$classifications = $pdo->query("
    SELECT DISTINCT classification 
    FROM stakeholders 
    WHERE classification IS NOT NULL AND classification != ''
    ORDER BY classification ASC
")->fetchAll(PDO::FETCH_COLUMN);

// Output
echo json_encode([
    'months' => $monthOptions,
    'rms' => $rms,
    'classifications' => $classifications
]);
