<?php
// api/fetch_filters.php

header('Content-Type: application/json');
require_once('../includes/config.php');

// Enable debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    $departments = [];
    $rms = [];

    // Fetch unique departments from stakeholder_engagements
    $stmt = $pdo->query("SELECT DISTINCT department FROM stakeholder_engagements WHERE department IS NOT NULL AND department != ''");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $departments[] = $row['department'];
    }

    // Fetch relationship managers from users table
    $stmt = $pdo->query("SELECT id, full_name FROM users WHERE role IN ('manager', 'admin', 'superuser', 'user')");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $rms[] = [
            'id' => $row['id'],
            'name' => $row['full_name']
        ];
    }

    echo json_encode([
        'departments' => $departments,
        'rms' => $rms
    ]);

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
