<?php
require '../includes/config.php';

$type = $_GET['type'] ?? '';
$dept = $_GET['department'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';
$export = $_GET['export'] ?? '';

// Build base SQL
$sql = "SELECT department, tsl_contact, interaction_date, client_company, type, category, stakeholder_name, nature_of_interaction, action_notes, trace_score FROM stakeholder_engagements WHERE 1=1";

$params = [];
if (!empty($type)) {
    $sql .= " AND type = :type";
    $params[':type'] = $type;
}
if (!empty($dept)) {
    $sql .= " AND department LIKE :department";
    $params[':department'] = "%$dept%";
}
if (!empty($dateFrom)) {
    $sql .= " AND interaction_date >= :date_from";
    $params[':date_from'] = $dateFrom;
}
if (!empty($dateTo)) {
    $sql .= " AND interaction_date <= :date_to";
    $params[':date_to'] = $dateTo;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($export === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="filtered_engagements.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, array_keys($rows[0] ?? []));

    foreach ($rows as $row) {
        fputcsv($out, $row);
    }
    fclose($out);
    exit;
}

// Default JSON return for frontend view
echo json_encode([
    'success' => true,
    'data' => $rows
]);
