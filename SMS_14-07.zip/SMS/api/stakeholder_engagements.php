<?php
require '../includes/config.php';

$stakeholderId = isset($_GET['stakeholder_id']) ? intval($_GET['stakeholder_id']) : 0;

$stmt = $pdo->prepare("SELECT * FROM stakeholder_engagements WHERE stakeholder_id = ? ORDER BY date_of_interaction DESC");
$stmt->execute([$stakeholderId]);
$engagements = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($engagements);
