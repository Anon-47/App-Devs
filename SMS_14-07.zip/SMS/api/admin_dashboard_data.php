<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

$response = [
    'userRoles' => [],
    'engagementTypes' => [],
    'activeDepartments' => [],
    'summary' => []
];

try {
    // 1. Users by Role
    $stmt = $pdo->query("SELECT role, COUNT(*) AS count FROM users GROUP BY role");
    $response['userRoles'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2. Engagements by Interaction Nature (was previously wrongly assumed as 'type')
    $stmt = $pdo->query("SELECT interaction_nature AS type, COUNT(*) AS count 
                         FROM stakeholder_engagements 
                         GROUP BY interaction_nature");
    $response['engagementTypes'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 3. Most Active Departments
    $stmt = $pdo->query("SELECT department, COUNT(*) AS engagements 
                         FROM stakeholder_engagements 
                         GROUP BY department 
                         ORDER BY engagements DESC 
                         LIMIT 5");
    $response['activeDepartments'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Summary Counts
    $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $stakeholderCount = $pdo->query("SELECT COUNT(*) FROM stakeholders")->fetchColumn();
    $engagementCount = $pdo->query("SELECT COUNT(*) FROM stakeholder_engagements")->fetchColumn();

    $response['summary'] = [
        'users' => $userCount,
        'stakeholders' => $stakeholderCount,
        'engagements' => $engagementCount
    ];

    echo json_encode($response);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
