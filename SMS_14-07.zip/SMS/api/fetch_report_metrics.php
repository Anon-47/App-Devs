<?php
require_once '../includes/config.php';

// Summary
$summary = [
  'users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
  'stakeholders' => $pdo->query("SELECT COUNT(*) FROM stakeholders")->fetchColumn(),
  'engagements' => $pdo->query("SELECT COUNT(*) FROM stakeholder_engagements")->fetchColumn()
];

// Top Departments by Engagement Count
$stmt = $pdo->query("SELECT department, COUNT(*) AS count FROM stakeholder_engagements GROUP BY department ORDER BY count DESC LIMIT 5");
$top_departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Top Relationship Managers by Engagements
$stmt = $pdo->query("
  SELECT u.username AS name, COUNT(e.id) AS count
  FROM stakeholder_engagements e
  JOIN stakeholders s ON e.stakeholder_id = s.id
  JOIN users u ON s.relationship_manager = u.id
  GROUP BY u.username
  ORDER BY count DESC
  LIMIT 5
");
$top_rms = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Engagement Types
$stmt = $pdo->query("SELECT type, COUNT(*) AS count FROM stakeholder_engagements GROUP BY type ORDER BY count DESC");
$engagement_types = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Output
echo json_encode([
  'summary' => $summary,
  'top_departments' => $top_departments,
  'top_rms' => $top_rms,
  'engagement_types' => $engagement_types
]);
