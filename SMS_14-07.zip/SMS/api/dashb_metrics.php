<?php
include_once '../includes/config.php';
include_once '../includes/session.php';

$role = $_SESSION['role'] ?? 'user';
$user_id = $_SESSION['user_id'] ?? null;
$department = $_SESSION['department'] ?? null;

$filters = "WHERE s.account_status = 'active'";
$params = [];

if ($role === 'user') {
    $filters .= " AND s.relationship_manager = :user_id";
    $params['user_id'] = $user_id;
} elseif ($role === 'manager' && $department) {
    $filters .= " AND u.department = :department";
    $params['department'] = $department;
}

// Total Stakeholders
$stmt = $pdo->prepare("SELECT COUNT(*) FROM stakeholders s LEFT JOIN users u ON s.relationship_manager = u.id $filters");
$stmt->execute($params);
$total_stakeholders = $stmt->fetchColumn();

// This Month’s Engagements
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM stakeholder_engagements se
    JOIN stakeholders s ON se.stakeholder_id = s.id
    LEFT JOIN users u ON s.relationship_manager = u.id
    $filters AND MONTH(se.interaction_date) = MONTH(CURDATE()) AND YEAR(se.interaction_date) = YEAR(CURDATE())
");
$stmt->execute($params);
$monthly_engagements = $stmt->fetchColumn();

// Average Rating
$stmt = $pdo->prepare("SELECT AVG(s.rating) FROM stakeholders s LEFT JOIN users u ON s.relationship_manager = u.id $filters");
$stmt->execute($params);
$average_rating = round($stmt->fetchColumn(), 1);

// Top Classification
$stmt = $pdo->prepare("SELECT s.classification, COUNT(*) AS count FROM stakeholders s LEFT JOIN users u ON s.relationship_manager = u.id $filters GROUP BY s.classification ORDER BY count DESC LIMIT 1");
$stmt->execute($params);
$top_classification = $stmt->fetch(PDO::FETCH_ASSOC)['classification'] ?? null;

// Top RM (Admins & Supers Only)
$top_rm = null;
if (in_array($role, ['superuser', 'admin'])) {
    $stmt = $pdo->query("
        SELECT u.full_name, COUNT(*) AS engagements 
        FROM stakeholder_engagements se 
        JOIN stakeholders s ON se.stakeholder_id = s.id 
        JOIN users u ON s.relationship_manager = u.id 
        GROUP BY u.id 
        ORDER BY engagements DESC 
        LIMIT 1
    ");
    $top_rm = $stmt->fetch(PDO::FETCH_ASSOC)['full_name'] ?? null;
}

// Data for Charts

// Engagements by RM
$engagements_by_rm = [];
if (in_array($role, ['superuser', 'admin', 'manager'])) {
    $stmt = $pdo->prepare("
        SELECT u.full_name AS rm, COUNT(*) AS count
        FROM stakeholder_engagements se
        JOIN stakeholders s ON se.stakeholder_id = s.id
        JOIN users u ON s.relationship_manager = u.id
        $filters
        GROUP BY s.relationship_manager
    ");
    $stmt->execute($params);
    $engagements_by_rm = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Classification distribution
$stmt = $pdo->prepare("
    SELECT s.classification, COUNT(*) AS count
    FROM stakeholders s 
    LEFT JOIN users u ON s.relationship_manager = u.id
    $filters
    GROUP BY s.classification
");
$stmt->execute($params);
$classification_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Respond
echo json_encode([
    'total_stakeholders' => $total_stakeholders,
    'monthly_engagements' => $monthly_engagements,
    'average_rating' => $average_rating,
    'top_classification' => $top_classification,
    'top_rm' => $top_rm,
    'engagements_by_rm' => $engagements_by_rm,
    'classification_distribution' => $classification_distribution
]);
