<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo "Access denied.";
    exit;
}

require '../includes/config.php';

// Validate the report type
$validReports = ['engagement_history', 'classification_summary', 'pending_actions'];
$type = isset($_GET['type']) && in_array($_GET['type'], $validReports) ? $_GET['type'] : null;

if (!$type) {
    header('HTTP/1.1 400 Bad Request');
    echo "Invalid report type.";
    exit;
}

try {
    // Prepare queries based on report type
    if ($type === 'engagement_history') {
        $query = "SELECT stakeholders.company AS 'Company', engagements.date AS 'Date', 
                         engagements.type AS 'Engagement Type', engagements.notes AS 'Notes'
                  FROM engagements 
                  INNER JOIN stakeholders ON engagements.stakeholder_id = stakeholders.id";
    } elseif ($type === 'classification_summary') {
        $query = "SELECT stakeholders.classification AS 'Classification', 
                         COUNT(*) AS 'Total Stakeholders' 
                  FROM stakeholders 
                  GROUP BY stakeholders.classification";
    } elseif ($type === 'pending_actions') {
        $query = "SELECT stakeholders.company AS 'Company', actions.type AS 'Action Type', 
                         actions.status AS 'Status' 
                  FROM actions 
                  INNER JOIN stakeholders ON actions.stakeholder_id = stakeholders.id
                  WHERE actions.status = 'pending'";
    }

    $stmt = $pdo->query($query);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($data)) {
        header('HTTP/1.1 404 Not Found');
        echo "No data available for this report.";
        exit;
    }

    // Generate CSV
    $filename = $type . "_report_" . date('Y-m-d_H-i-s') . ".csv";
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $output = fopen('php://output', 'w');

    // Write header row
    fputcsv($output, array_keys($data[0]));

    // Write data rows
    foreach ($data as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
} catch (PDOException $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo "Error generating report: " . $e->getMessage();
}
?>
