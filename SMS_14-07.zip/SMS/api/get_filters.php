<?php
require '../includes/config.php';
header('Content-Type: application/json');

$response = ['years' => []];

try {
    $stmt = $pdo->query("
        SELECT DISTINCT YEAR(interaction_date) AS yr
        FROM stakeholder_engagements
        WHERE interaction_date IS NOT NULL
        ORDER BY yr DESC
    ");

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if (!empty($row['yr'])) {
            $response['years'][] = (int) $row['yr'];
        }
    }

    // Fallback to current year if nothing is found
    if (empty($response['years'])) {
        $response['years'][] = (int) date('Y');
    }

} catch (PDOException $e) {
    $response['error'] = 'Database error: ' . $e->getMessage();
}

// Output JSON response
echo json_encode($response);
