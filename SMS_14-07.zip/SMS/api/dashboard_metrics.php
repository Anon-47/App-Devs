<?php
require '../includes/config.php';
header('Content-Type: application/json');

$response = [
    'total_stakeholders' => 0,
    'total_engagements' => 0,
    'avg_trace_score' => 0,
    'follow_up_rate' => 0,
    'types' => [],
    'categories' => []
];

try {
    // Total Stakeholders
    $stmt = $pdo->query("SELECT COUNT(*) FROM stakeholders");
    $response['total_stakeholders'] = (int) $stmt->fetchColumn();

    // Total Engagements
    $stmt = $pdo->query("SELECT COUNT(*) FROM stakeholder_engagements");
    $response['total_engagements'] = (int) $stmt->fetchColumn();

    // Average TRACE Score
    $stmt = $pdo->query("SELECT AVG(trace_rating) as avg_trace FROM stakeholder_engagements WHERE trace_rating IS NOT NULL");
    $avgTrace = $stmt->fetchColumn();
    $response['avg_trace_score'] = $avgTrace ? round($avgTrace, 1) : 0;

    // Follow-up Rate
    $stmt = $pdo->query("SELECT 
        (COUNT(CASE WHEN follow_up_status = 'Yes' THEN 1 END) * 100.0) / NULLIF(COUNT(*), 0) AS follow_rate 
        FROM stakeholder_engagements");
    $followRate = $stmt->fetchColumn();
    $response['follow_up_rate'] = $followRate ? round($followRate, 1) : 0;


    // Stakeholders by Type
    $stmt = $pdo->query("SELECT stakeholder_type AS label, COUNT(*) AS count 
                         FROM stakeholders 
                         GROUP BY stakeholder_type 
                         ORDER BY count DESC");
    $response['types'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Stakeholders by Category
    $stmt = $pdo->query("SELECT stakeholder_category AS label, COUNT(*) AS count 
                         FROM stakeholders 
                         GROUP BY stakeholder_category 
                         ORDER BY count DESC");
    $response['categories'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($response);

} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
