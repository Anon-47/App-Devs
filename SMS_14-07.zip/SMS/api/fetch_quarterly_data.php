<?php
require '../includes/config.php';
header('Content-Type: application/json');

$year = $_GET['year'] ?? null;
$quarter = $_GET['quarter'] ?? null;

if (!$year || !$quarter) {
    echo json_encode(['departments' => [], 'counts' => []]);
    exit;
}

// Define quarter range
$quarterMonths = [
    'Q1' => ['01', '03'],
    'Q2' => ['04', '06'],
    'Q3' => ['07', '09'],
    'Q4' => ['10', '12']
];

[$startMonth, $endMonth] = $quarterMonths[$quarter] ?? ['01', '12'];

$startDate = "$year-$startMonth-01";
$endDate = date("Y-m-t", strtotime("$year-$endMonth-01"));

$stmt = $pdo->prepare("
    SELECT department, COUNT(*) as total
    FROM stakeholder_engagements
    WHERE interaction_date BETWEEN ? AND ?
    GROUP BY department
");
$stmt->execute([$startDate, $endDate]);

$departments = [];
$counts = [];

while ($row = $stmt->fetch()) {
    $departments[] = $row['department'];
    $counts[] = (int)$row['total'];
}

echo json_encode(['departments' => $departments, 'counts' => $counts]);
