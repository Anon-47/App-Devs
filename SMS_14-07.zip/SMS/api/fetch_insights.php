<?php
// api/fetch_insights.php

header('Content-Type: application/json');
require_once('../includes/config.php');

// Enable debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Collect filters from URL
$dept = $_GET['dept'] ?? '';
$rm = $_GET['rm'] ?? '';
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';

$where = [];
$params = [];

// Apply filters if any
if (!empty($dept)) {
    $where[] = "department = ?";
    $params[] = $dept;
}
if (!empty($rm)) {
    $where[] = "relationship_manager_id = ?";
    $params[] = $rm;
}
if (!empty($start) && !empty($end)) {
    $where[] = "interaction_date BETWEEN ? AND ?";
    $params[] = $start;
    $params[] = $end;
}

$whereSQL = count($where) > 0 ? "WHERE " . implode(" AND ", $where) : "";

// Output chart data
$response = [
    'charts' => [],
    'html' => '' // You can build this HTML dynamically later
];

// === Chart 1: Stakeholder Types ===
$stmt = $pdo->prepare("
    SELECT stakeholder_type AS label, COUNT(*) AS total
    FROM stakeholder_engagements
    $whereSQL
    GROUP BY stakeholder_type
");
$stmt->execute($params);
$types = $stmt->fetchAll(PDO::FETCH_ASSOC);
$response['charts']['types'] = [        
    'labels' => array_column($types, 'label'),
    'values' => array_column($types, 'total')
];

// === Chart 2: Stakeholder Categories ===
$stmt = $pdo->prepare("
    SELECT stakeholder_category AS label, COUNT(*) AS total
    FROM stakeholder_engagements
    $whereSQL
    GROUP BY stakeholder_category
");
$stmt->execute($params);
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
$response['charts']['categories'] = [
    'labels' => array_column($categories, 'label'),
    'values' => array_column($categories, 'total')
];

// === Chart 3: Follow-Up Status ===
$stmt = $pdo->prepare("
    SELECT follow_up_status, COUNT(*) AS total
    FROM stakeholder_engagements
    $whereSQL
    GROUP BY follow_up_status
");
$stmt->execute($params);
$followUp = ['Yes' => 1, 'No' => 0];
foreach ($stmt as $row) {
    $status = $row['follow_up_status'] === 'Yes' ? 'Yes' : 'No';
    $followUp[$status] = (int) $row['total'];
}
$response['charts']['followupRate'] = array_values($followUp);

// Evaluate if we got meaningful data
$response['success'] = (
    !empty($response['charts']['types']['labels']) ||
    !empty($response['charts']['categories']['labels']) ||
    !empty($response['charts']['followupRate'])
);

// Prepare chart containers only if there's chart data
if (!empty($response['charts']['types']) || !empty($response['charts']['categories']) || !empty($response['charts']['followupRate'])) {
    $response['html'] = '
    <div class="chart-grid">
        <div class="chart-box">
            <h4>Stakeholder Types</h4>
            <canvas id="typeChart"></canvas>
        </div>
        <div class="chart-box">
            <h4>Stakeholder Categories</h4>
            <canvas id="catChart"></canvas>
        </div>
        <div class="chart-box">
            <h4>Follow-Up Rate</h4>
            <canvas id="followChart"></canvas>
        </div>
        <div class="chart-box placeholder">
            <h4>Coming Soon</h4>
            <p class="note">More metrics will appear here...</p>
        </div>
    </div>
    ';
    $response['success'] = true;
} else {
    $response['html'] = '';
    $response['success'] = false;
}

// Optional: Debug dump
$response['debug'] = [
    'types' => $types,
    'categories' => $categories,
    'followUpRaw' => $followUp
];

echo json_encode($response);
