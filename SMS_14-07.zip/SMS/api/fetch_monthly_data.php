<?php
ob_clean();
header('Content-Type: application/json');
include_once '../includes/config.php';

$month = $_GET['month'] ?? '';
$rm = $_GET['rm'] ?? '';
$classification = $_GET['classification'] ?? '';

$params = [];
$where = "WHERE 1=1";

if ($month) {
    $where .= " AND DATE_FORMAT(se.interaction_date, '%Y-%m') = :month";
    $params['month'] = $month;
}
if ($rm) {
    $where .= " AND s.relationship_manager = :rm";
    $params['rm'] = $rm;
}
if ($classification) {
    $where .= " AND s.classification = :classification";
    $params['classification'] = $classification;
}

// Aggregate engagements by stakeholder
$stmt = $pdo->prepare("
    SELECT s.organization AS stakeholder_name, COUNT(se.id) AS engagement_count
    FROM stakeholder_engagements se
    JOIN stakeholders s ON se.stakeholder_id = s.id
    $where
    GROUP BY s.id
    ORDER BY engagement_count DESC
    LIMIT 20
");
$stmt->execute($params);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Prepare for chart
$labels = array_column($data, 'stakeholder_name');
$values = array_column($data, 'engagement_count');

echo json_encode([
    'labels' => $labels,
    'data' => $values
]);
