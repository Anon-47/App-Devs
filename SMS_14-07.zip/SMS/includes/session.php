<?php
// includes/session.php

// Inactivity timeout (in seconds)
$timeout = 900; // 15 minutes

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle timeout
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout) {
    session_unset(); // Clear session variables
    session_destroy(); // Destroy session
    header("Location: ../views/index.php?timeout=1");
    exit();
}

$_SESSION['LAST_ACTIVITY'] = time(); // Update activity timestamp
?>
