<?php
// /includes/helpers.php

function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function format_date($date) {
    return date("d M, Y", strtotime($date));
}
?>
