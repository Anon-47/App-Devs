<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Stakeholder Management System</title>
    
    <!-- Favicon -->
    <link rel="icon" href="/SMS/assets/img/favicon.ico" type="image/x-icon">

    <!-- Main CSS -->
    <link rel="stylesheet" href="/SMS/assets/css/style.css">

    <!-- Optional Theme Switching -->
    <?php
    session_start();
    $theme = $_SESSION['theme'] ?? 'light';
    if ($theme === 'dark') {
        echo '<link rel="stylesheet" href="/SMS/assets/css/dark.css">';
    } else {
        echo '<link rel="stylesheet" href="/SMS/assets/css/light.css">';
    }
    ?>

    <!-- Page Loader -->
    <div id="page-loader">
        <div class="spinner"></div>
    </div>
    
    <!-- Optional JS -->
    <script src="/SMS/assets/js/scripts.js" defer></script>
</head>
<body>
