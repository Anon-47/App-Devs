<?php
// /includes/oauth.php

require_once 'db.php';
require_once '../vendor/autoload.php';

use League\OAuth2\Client\Provider\GenericProvider;

$oauthProvider = new GenericProvider([
    'clientId'                => $_ENV['OAUTH_CLIENT_ID'],
    'clientSecret'            => $_ENV['OAUTH_CLIENT_SECRET'],
    'redirectUri'             => $_ENV['OAUTH_REDIRECT_URI'],
    'urlAuthorize'            => 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    'urlAccessToken'          => 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    'urlResourceOwnerDetails' => 'https://graph.microsoft.com/v1.0/me'
]);
?>
