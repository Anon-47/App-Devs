<?php
// includes/config.php

$host = 'localhost';  // Database host (could be an IP or 'localhost')
$dbname = 'stakeholder_management'; // Database name
$user = 'root';  // Database username
$password = '';  // Database password

// Connection string
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}

// MySQLi
$conn = mysqli_connect($host, $user, $password, $dbname);
if (!$conn) {
    die("MySQLi connection failed: " . mysqli_connect_error());
}
?>

<?php
// Set the inactivity limit to 5 minutes (300 seconds)
$inactivity_limit = 900;

// Check if last_activity is set in the session
if (isset($_SESSION['last_activity'])) {
    // Calculate time since last activity
    $time_inactive = time() - $_SESSION['last_activity'];
    
    // If inactive for too long, destroy session and redirect to login
    if ($time_inactive >= $inactivity_limit) {
        session_unset();  // Clear session data
        session_destroy(); // Destroy the session
        header("Location: login.php?message=Session expired due to inactivity. Please log in again.");
        exit();
    }
}

// Update last_activity to the current time
$_SESSION['last_activity'] = time();
?>
