    <!-- Animation and Utility Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        AOS.init({
            duration: 700,
            once: true
        });
    </script>

    <!-- Optional: Loading Spinner Handling -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const loader = document.getElementById('page-loader');
            if (loader) loader.style.display = 'none';
        });
    </script>
    
    <script>
    window.addEventListener("load", function () {
        const loader = document.getElementById("page-loader");
        if (loader) {
            loader.style.display = "none";
        }
    });
    </script>


    <!-- Footer Scripts -->
    <script src="/SMS/assets/js/scripts.js"></script>

</body>
</html>
