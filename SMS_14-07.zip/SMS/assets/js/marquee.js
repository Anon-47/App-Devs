// Basic Marquee Control: Smooth and Steady
// You can use JavaScript to adjust speed or add controls, but CSS alone can handle basic sliding here.
