document.addEventListener("DOMContentLoaded", function () {
    const iframeModal = document.getElementById("iframeModal");
    const formIframe = document.getElementById("formIframe");
    const closeIframeModal = document.getElementById("closeIframeModal");

    // Event listener for buttons with 'data-form' attribute
    document.addEventListener("click", function (event) {
        if (event.target.matches("[data-form]")) {
            event.preventDefault();

            // Get the form URL from the data-form attribute and load it into the iframe
            const formUrl = event.target.getAttribute("data-form");
            formIframe.src = `forms/${formUrl}.php`;
            
            // Show the modal
            iframeModal.style.display = "block";
        }
    });

    // Close the modal when the close button is clicked
    closeIframeModal.addEventListener("click", function () {
        iframeModal.style.display = "none";
        formIframe.src = ""; // Clear iframe source
    });

    // Close modal when clicking outside of the modal content
    window.addEventListener("click", function (event) {
        if (event.target === iframeModal) {
            iframeModal.style.display = "none";
            formIframe.src = "";
        }
    });
});


// Function to validate form input
function validateForm() {
    const surname = document.getElementById("surname").value.trim();
    const firstName = document.getElementById("firstName").value.trim();
    const company = document.getElementById("company").value.trim();
    const designation = document.getElementById("designation").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const email = document.getElementById("email").value.trim();
    const channel = document.getElementById("communicationChannel").value;

    // Validate required fields
    if (!surname || !firstName || !company || !designation) {
        alert("Please fill out all required fields.");
        return false;
    }

    // Validate phone number (optional, but must be a valid pattern if filled)
    const phonePattern = /^[0-9]{10,15}$/;
    if (phone && !phonePattern.test(phone)) {
        alert("Please enter a valid phone number (10-15 digits).");
        return false;
    }

    // Validate email (optional, but must be a valid format if filled)
    if (email && !/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }

    return true; // Submit form if validation passes
}
