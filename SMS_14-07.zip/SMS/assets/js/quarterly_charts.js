window.initQuarterlyReport = function () {
    const yearSelect = document.getElementById('filter-year');
    const ctx = document.getElementById('quarterlyChart')?.getContext('2d');
    let chartInstance;

    if (!yearSelect || !ctx) return;

    // 1. Populate year dropdown
    fetch('../../api/get_filters.php')
        .then(res => res.json())
        .then(data => {
            yearSelect.innerHTML = '';
            if (data.years && data.years.length > 0) {
                data.years.forEach(year => {
                    const opt = document.createElement('option');
                    opt.value = year;
                    opt.textContent = year;
                    yearSelect.appendChild(opt);
                });
            } else {
                yearSelect.innerHTML = '<option>No years found</option>';
            }
        })
        .catch(err => {
            console.error('Error fetching years:', err);
            yearSelect.innerHTML = '<option>Error loading years</option>';
        });

    // 2. Load report
    window.loadReport = function () {
        const year = yearSelect?.value;
        const quarter = document.getElementById('quarter')?.value;
        if (!year || !quarter) return;

        fetch(`../../api/fetch_quarterly_data.php?year=${year}&quarter=${quarter}`)
            .then(res => res.json())
            .then(data => {
                if (chartInstance) chartInstance.destroy();

                chartInstance = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: data.departments || [],
                        datasets: [{
                            label: `Engagements for ${quarter} ${year}`,
                            data: data.counts || [],
                            backgroundColor: ['#DA8A1D', '#F6C542', '#EC8424', '#A65E2E', '#DFB239']
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: { display: true, text: 'Engagement Count' }
                            }
                        }
                    }
                });
            })
            .catch(err => {
                console.error('Error loading chart data:', err);
            });
    };
};
