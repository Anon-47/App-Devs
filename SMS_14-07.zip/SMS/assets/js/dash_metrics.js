export function initDashboard() {
    fetch('../../api/fetch_dashboard_metrics.php')
      .then(res => res.json())
      .then(data => {
          if (document.getElementById("totalStakeholders")) {
              document.getElementById("totalStakeholders").innerText = data.total_stakeholders;
              document.getElementById("monthlyEngagements").innerText = data.monthly_engagements;
              document.getElementById("averageRating").innerText = data.average_rating;
              document.getElementById("topClassification").innerText = data.top_classification || "—";
              if (data.top_rm !== undefined) {
                  document.getElementById("topRM").innerText = data.top_rm || "—";
              }

              renderEngagementsByRMChart(data.engagements_by_rm);
              renderClassificationPieChart(data.classification_distribution);
              renderStakeholdersPerDepartment(data.stakeholders_per_department);
          }
      })
      .catch(err => {
          console.error("Dashboard Load Error:", err);
      });
}

function renderEngagementsByRMChart(data) {
    const ctx = document.getElementById('engagementsByRMChart');
    if (!ctx) return;
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.rm),
            datasets: [{
                label: '# of Engagements',
                data: data.map(d => d.count),
                backgroundColor: '#ffc107'
            }]
        },
        options: { responsive: true }
    });
}

function renderClassificationPieChart(data) {
    const ctx = document.getElementById('classificationPieChart');
    if (!ctx) return;
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: data.map(d => d.classification),
            datasets: [{
                data: data.map(d => d.count),
                backgroundColor: ['#ffcc00', '#ff6600', '#66ccff', '#66ff66', '#ff3366']
            }]
        },
        options: { responsive: true }
    });
}

function renderStakeholdersPerDepartment(data) {
    const ctx = document.getElementById('departmentChart');
    if (!ctx) return;
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.department || 'Unassigned'),
            datasets: [{
                label: 'Stakeholders',
                data: data.map(d => d.stakeholder_count),
                backgroundColor: '#4caf50'
            }]
        },
        options: { responsive: true }
    });
}

//initDashboard(); // ensures it runs when loaded directly
export default { initDashboard };
