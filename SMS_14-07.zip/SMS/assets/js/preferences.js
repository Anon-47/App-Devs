// Path: js/preferences.js
document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("preferences-form");
    
    // Load current preferences
    fetch('scripts/load_preferences.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('theme').value = data.theme || 'default';
            document.getElementById('other_setting').value = data.other_setting || '';
            updateTheme(data.theme);
        });

    // Update preferences on form submission
    form.addEventListener("submit", function(e) {
        e.preventDefault();
        
        const formData = new FormData(form);
        fetch('scripts/save_preferences.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert(data.message);
                updateTheme(formData.get('theme'));
            } else {
                alert(data.message);
            }
        });
    });

    // Function to apply theme
    function updateTheme(theme) {
        const themeLink = document.getElementById("theme-stylesheet");
        themeLink.href = `css/themes/${theme}.css`; // Assume theme files are structured in 'css/themes/'
    }
});
