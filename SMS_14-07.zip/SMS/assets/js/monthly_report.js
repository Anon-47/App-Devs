function initMonthlyReport() {
    const monthSelect = document.getElementById('filterMonth');
    const rmSelect = document.getElementById('filterRM');
    const classSelect = document.getElementById('filterClassification');
    const generateBtn = document.getElementById('applyFilters');
    const chartCanvas = document.getElementById('monthlyEngagementChart');

    if (!monthSelect || !rmSelect || !classSelect || !generateBtn || !chartCanvas) {
        console.warn("Monthly report elements not yet available.");
        return;
    }

    let chartInstance = null;

    async function fetchFilters() {
        try {
            const res = await fetch('../../api/fetch_filter_options.php');
            const data = await res.json();

            data.months.forEach(opt => {
                const o = new Option(opt.label, opt.value);
                monthSelect.appendChild(o);
            });

            data.rms.forEach(opt => {
                const o = new Option(opt.name, opt.id);
                rmSelect.appendChild(o);
            });

            data.classifications.forEach(opt => {
                const o = new Option(opt, opt);
                classSelect.appendChild(o);
            });
        } catch (err) {
            console.error("Failed to load filters:", err);
        }
    }

    async function loadChart() {
        const params = new URLSearchParams({
            month: monthSelect.value,
            rm: rmSelect.value,
            classification: classSelect.value,
        });

        try {
            const res = await fetch(`../../api/fetch_monthly_data.php?${params.toString()}`);
            const data = await res.json();

            if (chartInstance) chartInstance.destroy();

            chartInstance = new Chart(chartCanvas, {
                type: 'bar',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Monthly Engagements',
                        data: data.data,
                        backgroundColor: '#f39c12',
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { display: false },
                        title: {
                            display: true,
                            text: 'Monthly Stakeholder Engagements'
                        }
                    }
                }
            });
        } catch (err) {
            console.error("Failed to render chart:", err);
        }
    }

    generateBtn.addEventListener('click', loadChart);
    fetchFilters();
}

// Load immediately if the page is standalone
if (document.readyState !== 'loading') {
    initMonthlyReport();
} else {
    document.addEventListener('DOMContentLoaded', initMonthlyReport);
}
