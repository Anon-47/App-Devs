function loadAdminDashboardCharts() {
    fetch('../../api/admin_dashboard_data.php')
        .then(res => res.json())
        .then(data => {
            if (!data || !data.userRoles) return;

            const ctx1 = document.getElementById('userRolesChart');
            const ctx2 = document.getElementById('engagementTypesChart');
            const ctx3 = document.getElementById('activeDepartmentsChart');

            if (ctx1) {
                new Chart(ctx1.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: data.userRoles.map(r => r.role),
                        datasets: [{
                            label: 'Users by Role',
                            data: data.userRoles.map(r => r.count),
                            backgroundColor: 'rgba(75, 192, 192, 0.6)'
                        }]
                    },
                    options: { responsive: true }
                });
            }

            if (ctx2) {
                new Chart(ctx2.getContext('2d'), {
                    type: 'doughnut',
                    data: {
                        labels: data.engagementTypes.map(e => e.type),
                        datasets: [{
                            label: 'Engagements',
                            data: data.engagementTypes.map(e => e.count),
                            backgroundColor: ['#ff6384', '#36a2eb', '#cc65fe', '#ffce56']
                        }]
                    },
                    options: { responsive: true }
                });
            }

            if (ctx3) {
                new Chart(ctx3.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: data.activeDepartments.map(d => d.department),
                        datasets: [{
                            label: 'Engagements',
                            data: data.activeDepartments.map(d => d.engagements),
                            backgroundColor: 'rgba(153, 102, 255, 0.6)'
                        }]
                    },
                    options: { responsive: true }
                });
            }

            if (data.summary) {
                document.getElementById('dbSummary').innerHTML = `
                    <li><strong>Users:</strong> ${data.summary.users}</li>
                    <li><strong>Stakeholders:</strong> ${data.summary.stakeholders}</li>
                    <li><strong>Engagements:</strong> ${data.summary.engagements}</li>
                `;
            }
        })
        .catch(err => console.error('Dashboard Chart Error:', err));
}
