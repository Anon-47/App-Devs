document.addEventListener("DOMContentLoaded", function () {
    const iframeModal = document.getElementById("iframeModal");
    const formIframe = document.getElementById("formIframe");
    const closeIframeModal = document.getElementById("closeIframeModal");

    // Event listener for buttons with 'data-form' attribute
    document.addEventListener("click", function (event) {
        if (event.target.matches("[data-form]")) {
            event.preventDefault();

            // Get the form URL from the data-form attribute and load it into the iframe
            const formUrl = event.target.getAttribute("data-form");
            formIframe.src = `forms/${formUrl}.php`;
            
            // Show the modal
            iframeModal.style.display = "block";
        }
    });

    // Close the modal when the close button is clicked
    closeIframeModal.addEventListener("click", function () {
        iframeModal.style.display = "none";
        formIframe.src = ""; // Clear iframe source
    });

    // Close modal when clicking outside of the modal content
    window.addEventListener("click", function (event) {
        if (event.target === iframeModal) {
            iframeModal.style.display = "none";
            formIframe.src = "";
        }
    });
});
