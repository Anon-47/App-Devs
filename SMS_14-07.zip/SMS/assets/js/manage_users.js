// Filter users based on input
function filterUsers() {
    const nameFilter = document.getElementById("searchName").value.toLowerCase();
    const roleFilter = document.getElementById("filterRole").value;

    const rows = document.querySelectorAll("#userTableBody tr");
    rows.forEach(row => {
        const name = row.cells[0].textContent.toLowerCase();
        const role = row.cells[2].textContent;

        const nameMatch = name.includes(nameFilter);
        const roleMatch = roleFilter === "" || role === roleFilter;

        row.style.display = nameMatch && roleMatch ? "" : "none";
    });
}

// Sort users by name (ascending order)
function sortUsers() {
    const tableBody = document.getElementById("userTableBody");
    const rowsArray = Array.from(tableBody.querySelectorAll("tr"));

    rowsArray.sort((a, b) => {
        const nameA = a.cells[0].textContent.toLowerCase();
        const nameB = b.cells[0].textContent.toLowerCase();
        return nameA.localeCompare(nameB);
    });

    // Re-append sorted rows to the table body
    rowsArray.forEach(row => tableBody.appendChild(row));
}

// Placeholder for Modify User function
function modifyUser(userName) {
    alert("Modify user: " + userName);
}
