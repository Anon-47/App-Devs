document.addEventListener("DOMContentLoaded", () => {
    const links = document.querySelectorAll("a[data-page]");
    const contentArea = document.getElementById("contentArea");
    const loader = document.getElementById("loader");

    function showLoader() { loader.style.display = "flex"; }
    function hideLoader() { loader.style.display = "none"; }

    links.forEach(link => {
        link.addEventListener("click", function (e) {
            e.preventDefault();
            const page = this.getAttribute("data-page");

            showLoader();
            fetch(page)
                .then(response => {
                    if (!response.ok) throw new Error("Page not found");
                    return response.text();
                })
                .then(html => {
                contentArea.innerHTML = html;

                    // 🔄 Call chart rendering if function is defined
                    if (typeof renderMyChart === 'function') renderMyChart();
                    if (typeof renderAdminChart === 'function') renderAdminChart();
                    if (typeof renderSuperuserWidgets === 'function') renderSuperuserWidgets();
                })
                .catch(err => {
                    contentArea.innerHTML = `
                        <div style="text-align:center; padding:40px;">
                            <h2>Oops! Failed to load content.</h2>
                            <p>${err.message}</p>
                            <p>Please check the page path or contact support.</p>
                        </div>
                    `;
                })
                .finally(() => {
                    hideLoader();
                });
        });
    });
});

function toggleSubmenu(submenuId) {
    const submenu = document.getElementById(submenuId);
    submenu.style.display = submenu.style.display === "none" || submenu.style.display === "" ? "block" : "none";
}
