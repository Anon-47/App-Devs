// Function to filter table based on search input
function filterTable() {
    const input = document.getElementById("searchInput");
    const filter = input.value.toLowerCase();
    const table = document.getElementById("stakeholderTable");
    const rows = table.getElementsByTagName("tr");

    for (let i = 1; i < rows.length; i++) { // Skip header row
        const cells = rows[i].getElementsByTagName("td");
        let match = false;
        for (let j = 0; j < cells.length; j++) {
            if (cells[j].innerText.toLowerCase().includes(filter)) {
                match = true;
                break;
            }
        }
        rows[i].style.display = match ? "" : "none";
    }
}

// Function to sort table by column
function sortTable(columnIndex) {
    const table = document.getElementById("stakeholderTable");
    const rows = Array.from(table.rows).slice(1); // Exclude header row
    let ascending = true;

    // Check if the column is already sorted in ascending order
    if (table.dataset.sortedColumn == columnIndex) {
        ascending = table.dataset.sortDirection === "asc" ? false : true;
        table.dataset.sortDirection = ascending ? "asc" : "desc";
    } else {
        table.dataset.sortedColumn = columnIndex;
        table.dataset.sortDirection = "asc";
    }

    rows.sort((rowA, rowB) => {
        const cellA = rowA.cells[columnIndex].innerText.toLowerCase();
        const cellB = rowB.cells[columnIndex].innerText.toLowerCase();

        if (cellA < cellB) return ascending ? -1 : 1;
        if (cellA > cellB) return ascending ? 1 : -1;
        return 0;
    });

    // Append sorted rows back to the table
    rows.forEach(row => table.appendChild(row));
}

document.addEventListener("DOMContentLoaded", function () {
    const iframeModal = document.getElementById("iframeModal");
    const formIframe = document.getElementById("formIframe");
    const closeIframeModal = document.getElementById("closeIframeModal");

    // Event listener for buttons with 'data-form' attribute
    document.addEventListener("click", function (event) {
        if (event.target.matches("[data-form]")) {
            event.preventDefault();

            // Get the form URL from the data-form attribute and load it into the iframe
            const formUrl = event.target.getAttribute("data-form");
            formIframe.src = `forms/${formUrl}.php`;
            
            // Show the modal
            iframeModal.style.display = "block";
        }
    });

    // Close the modal when the close button is clicked
    closeIframeModal.addEventListener("click", function () {
        iframeModal.style.display = "none";
        formIframe.src = ""; // Clear iframe source
    });

    // Close modal when clicking outside of the modal content
    window.addEventListener("click", function (event) {
        if (event.target === iframeModal) {
            iframeModal.style.display = "none";
            formIframe.src = "";
        }
    });
});
