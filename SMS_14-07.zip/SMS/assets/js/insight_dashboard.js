document.addEventListener("DOMContentLoaded", () => {
    fetchFilters();

    // Bind the Apply button to load insights only on click
    document.getElementById("applyBtn").addEventListener("click", loadInsights);
});

function fetchFilters() {
    fetch("../../api/fetch_filters.php")
        .then(res => res.json())
        .then(data => {
            const deptSelect = document.getElementById("department");
            const rmSelect = document.getElementById("rm");

            // Clear existing options except 'All'
            deptSelect.innerHTML = '<option value="">All</option>';
            rmSelect.innerHTML = '<option value="">All</option>';

            data.departments.forEach(dep => {
                const opt = document.createElement("option");
                opt.value = dep;
                opt.textContent = dep;
                deptSelect.appendChild(opt);
            });

            data.rms.forEach(rm => {
                const opt = document.createElement("option");
                opt.value = rm.id;
                opt.textContent = rm.name;
                rmSelect.appendChild(opt);
            });
        });
}

function loadInsights() {
    const dept = document.getElementById("department").value;
    const rm = document.getElementById("rm").value;
    const start = document.getElementById("startDate").value;
    const end = document.getElementById("endDate").value;

    const params = new URLSearchParams({ dept, rm, start, end });

    fetch(`../../api/fetch_insights.php?${params.toString()}`)
        .then(res => res.json())
        .then(data => {
            console.log("INSIGHT RESPONSE:", data); // 👈 inspect this in browser console

            if (data.success && data.html) {
                document.getElementById("insights").innerHTML = data.html;
                drawCharts(data);
            } else {
                document.getElementById("insights").innerHTML = '';
                alert("No insights available.");
            }
        })
        .catch(err => {
            console.error("Fetch Insights Error:", err);
            alert("Failed to load insights. Please check console for details.");
        });
}

//OLD Logic
// function drawCharts(data) {
//     const charts = data.charts || {};

//     // === Stakeholder Types ===
//     if (charts.types && charts.types.labels.length > 0) {
//         const ctx = document.getElementById("typeChart").getContext("2d");
//         new Chart(ctx, {
//             type: 'bar',
//             data: {
//                 labels: charts.types.labels,
//                 datasets: [{
//                     label: 'By Type',
//                     data: charts.types.values,
//                     backgroundColor: '#f59e0b'
//                 }]
//             }
//         });
//     }

//     // === Stakeholder Categories ===
//     if (charts.categories && charts.categories.labels.length > 0) {
//         const ctx = document.getElementById("catChart").getContext("2d");
//         new Chart(ctx, {
//             type: 'bar',
//             data: {
//                 labels: charts.categories.labels,
//                 datasets: [{
//                     label: 'By Category',
//                     data: charts.categories.values,
//                     backgroundColor: '#d97706'
//                 }]
//             }
//         });
//     }

//     // === Follow-Up Status ===
//     if (charts.followupRate && charts.followupRate.length > 0) {
//         const ctx = document.getElementById("followChart").getContext("2d");
//         new Chart(ctx, {
//             type: 'doughnut',
//             data: {
//                 labels: ['Not Followed', 'Followed Up'],
//                 datasets: [{
//                     data: charts.followupRate,
//                     backgroundColor: ['#dc2626', '#16a34a']
//                 }]
//             }
//         });
//     }
// }

//Updated Logic
// Mustard to Burgundy palette
const palette = ['#F0A500', '#C08457', '#7C3E2F', '#9A6324', '#F2C57C', '#D9BF77'];

function drawCharts(data) {
    const charts = data.charts || {};

    if (charts.types && charts.types.labels.length > 0) {
        const ctx = document.getElementById("typeChart").getContext("2d");
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: charts.types.labels,
                datasets: [{
                    label: 'By Type',
                    data: charts.types.values,
                    backgroundColor: palette.slice(0, charts.types.labels.length)
                }]
            },
            options: { animation: { duration: 800, easing: 'easeOutQuart' } }
        });
    }

    if (charts.categories && charts.categories.labels.length > 0) {
        const ctx = document.getElementById("catChart").getContext("2d");
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: charts.categories.labels,
                datasets: [{
                    label: 'By Category',
                    data: charts.categories.values,
                    backgroundColor: palette.slice(2, 2 + charts.categories.labels.length)
                }]
            },
            options: { animation: { duration: 800, easing: 'easeOutQuart' } }
        });
    }

    if (charts.followupRate && charts.followupRate.length > 0) {
        const ctx = document.getElementById("followChart").getContext("2d");
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Not Followed', 'Followed Up'],
                datasets: [{
                    data: charts.followupRate,
                    backgroundColor: ['#A4161A', '#16A34A']
                }]
            },
            options: {
                cutout: '65%',
                animation: {
                    animateRotate: true,
                    easing: 'easeOutBounce',
                    duration: 1000
                }
            }
        });
    }
}
