// ✅ dashboard.js (MODIFIED)
document.addEventListener("DOMContentLoaded", function () {
    const links = document.querySelectorAll(".sidebar .nav-item a[data-page]");
    const contentArea = document.getElementById("contentArea");

    links.forEach(link => {
        link.addEventListener("click", function (e) {
            e.preventDefault();

            links.forEach(l => l.classList.remove("active"));
            this.classList.add("active");

            const page = this.getAttribute("data-page");
            fetch(page)
                .then(response => {
                    if (!response.ok) throw new Error("Network response was not ok");
                    return response.text();
                })
                .then(html => {
                    contentArea.innerHTML = html;
                    if (page.includes("admin_reports.php")) {
                        loadAdminDashboardCharts();
                    }
                })
                .catch(error => {
                    console.error("Error loading page:", error);
                    contentArea.innerHTML = "<p>Error loading content. Please try again later.</p>";
                });
        });
    });
});

function toggleSubmenu(submenuId) {
    const submenu = document.getElementById(submenuId);
    submenu.style.display = submenu.style.display === "none" || submenu.style.display === "" ? "block" : "none";
}

document.addEventListener("DOMContentLoaded", function () {
    updatePendingBadge();
    setInterval(updatePendingBadge, 60000);
});

function updatePendingBadge() {
    fetch("../scripts/get_pending_actions_count.php")
        .then(response => response.json())
        .then(data => {
            const badge = document.getElementById("pendingBadge");
            badge.textContent = data.count;
            badge.style.display = data.count > 0 ? "inline-block" : "none";
        })
        .catch(error => console.error("Error fetching pending actions count:", error));
}

document.querySelectorAll("[data-page]").forEach(link => {
    link.addEventListener("click", async (e) => {
        e.preventDefault();
        const page = link.getAttribute("data-page");
        const target = document.getElementById("contentArea");

        const html = await (await fetch(page)).text();
        target.innerHTML = html;

        // Trigger dashboard render if it's the dashboard
        if (page.includes("demo_dash.php")) {
            setTimeout(async () => {
                try {
                    const module = await import(`../js/dash_metrics.js`);
                    if (module.default && module.default.initDashboard) {
                        module.default.initDashboard();
                    }
                } catch (err) {
                    console.error("Failed to initialize dashboard module:", err);
                }
            }, 100); // Give DOM time to settle
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const contentArea = document.getElementById("contentArea");
    const lastPage = sessionStorage.getItem("lastPage");
    if (lastPage) loadPage(lastPage);

    document.querySelectorAll(".dashboard-link").forEach(link => {
        link.addEventListener("click", function (e) {
            e.preventDefault();
            const page = this.getAttribute("data-page");
            sessionStorage.setItem("lastPage", page);
            loadPage(page);
        });
    });

    function loadPage(page) {
        fetch(page)
            .then(response => response.text())
            .then(html => {
                contentArea.innerHTML = html;
                if (page.includes("admin_reports.php")) {
                    loadAdminDashboardCharts();
                }
            })
            .catch(error => console.error("Error loading page:", error));
    }
});

const inactivityLimit = 1500000;
let inactivityTimer;
function resetInactivityTimer() {
    clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(() => {
        window.location.href = "../scripts/logout.php";
    }, inactivityLimit);
}

window.onload = resetInactivityTimer;
document.onmousemove = resetInactivityTimer;
document.onkeypress = resetInactivityTimer;

// ✅ Admin Dashboard Chart Initializer
// function loadAdminDashboardCharts() {
//     fetch('../../api/admin_dashboard_data.php')
//         .then(res => res.json())
//         .then(data => {
//             const ctx1 = document.getElementById('userRolesChart')?.getContext('2d');
//             if (ctx1) new Chart(ctx1, {
//                 type: 'bar',
//                 data: {
//                     labels: data.userRoles.map(r => r.role),
//                     datasets: [{ label: 'Users by Role', data: data.userRoles.map(r => r.count) }]
//                 },
//                 options: { responsive: true }
//             });

//             const ctx2 = document.getElementById('engagementTypesChart')?.getContext('2d');
//             if (ctx2) new Chart(ctx2, {
//                 type: 'doughnut',
//                 data: {
//                     labels: data.engagementTypes.map(e => e.type),
//                     datasets: [{ label: 'Engagements', data: data.engagementTypes.map(e => e.count) }]
//                 },
//                 options: { responsive: true }
//             });

//             const ctx3 = document.getElementById('activeDepartmentsChart')?.getContext('2d');
//             if (ctx3) new Chart(ctx3, {
//                 type: 'bar',
//                 data: {
//                     labels: data.activeDepartments.map(d => d.department),
//                     datasets: [{ label: 'Engagements', data: data.activeDepartments.map(d => d.engagements) }]
//                 },
//                 options: { responsive: true, indexAxis: 'y' }
//             });

//             const summary = data.summary;
//             document.getElementById('dbSummary').innerHTML = `
//                 <li><strong>Users:</strong> ${summary.users}</li>
//                 <li><strong>Stakeholders:</strong> ${summary.stakeholders}</li>
//                 <li><strong>Engagements:</strong> ${summary.engagements}</li>
//             `;
//         })
//         .catch(err => console.error('Failed to load dashboard data:', err));
// }
//Fetching & Displaying charts
document.querySelectorAll("[data-page]").forEach(link => {
    link.addEventListener("click", async (e) => {
        e.preventDefault();

        const page = link.getAttribute("data-page");
        const target = document.getElementById("contentArea");
        const html = await (await fetch(page)).text();
        target.innerHTML = html;

        if (page.includes("demo_dash.php")) {
        // Wait for content to render
        setTimeout(async () => {
            try {
                const module = await import('dash_metrics.js');
                if (module.initDashboard) {
                    module.initDashboard();
                }
            } catch (e) {
                console.error("Failed to load dashboard metrics script:", e);
            }
        }, 150);
        }

    });
});
