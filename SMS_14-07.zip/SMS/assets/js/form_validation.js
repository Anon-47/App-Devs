// form_validation.js
document.addEventListener("DOMContentLoaded", function () {
    const onboardForm = document.getElementById("onboardForm");

    onboardForm.addEventListener("submit", function (e) {
        let isValid = true;
        const requiredFields = ["surname", "firstName", "company", "designation"];

        // Basic required field validation
        requiredFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field && !field.value.trim()) {
                isValid = false;
                field.style.borderColor = "red";
            } else if (field) {
                field.style.borderColor = "#ccc";
            }
        });

        // Prevent form submission if not valid
        if (!isValid) {
            e.preventDefault();
            alert("Please fill in all required fields.");
        }
    });
});

// form_validation.js
document.addEventListener("DOMContentLoaded", function () {
    const onboardForm = document.getElementById("onboardForm");
    const engagementForm = document.getElementById("engagementForm");

    // Validate Onboard Form
    if (onboardForm) {
        onboardForm.addEventListener("submit", function (e) {
            let isValid = true;
            const requiredFields = ["surname", "firstName", "company", "designation"];

            requiredFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field && !field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = "red";
                } else if (field) {
                    field.style.borderColor = "#ccc";
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert("Please fill in all required fields.");
            }
        });
    }

    // Validate Engagement Form
    if (engagementForm) {
        engagementForm.addEventListener("submit", function (e) {
            let isValid = true;
            const requiredFields = ["engagementDate", "relationshipManager", "engagementType"];

            requiredFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field && !field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = "red";
                } else if (field) {
                    field.style.borderColor = "#ccc";
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert("Please complete all required fields.");
            }
        });
    }
});

// form_validation.js
document.addEventListener("DOMContentLoaded", function () {
    const onboardForm = document.getElementById("onboardForm");
    const engagementForm = document.getElementById("engagementForm");
    const ratingForm = document.getElementById("ratingForm");

    // Validate Onboard Form
    if (onboardForm) {
        onboardForm.addEventListener("submit", function (e) {
            // Validation logic for onboarding form
        });
    }

    // Validate Engagement Form
    if (engagementForm) {
        engagementForm.addEventListener("submit", function (e) {
            // Validation logic for engagement form
        });
    }

    // Validate Rating and Feedback Form
    if (ratingForm) {
        ratingForm.addEventListener("submit", function (e) {
            let isValid = true;
            const requiredFields = ["stakeholderName", "engagementRating", "engagementDate"];

            requiredFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field && !field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = "red";
                } else if (field) {
                    field.style.borderColor = "#ccc";
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert("Please complete all required fields.");
            }
        });
    }
});

// form_validation.js
document.addEventListener("DOMContentLoaded", function () {
    const onboardForm = document.getElementById("onboardForm");
    const engagementForm = document.getElementById("engagementForm");
    const ratingForm = document.getElementById("ratingForm");
    const classificationForm = document.getElementById("classificationForm");

    // Validate Onboard Form
    if (onboardForm) {
        onboardForm.addEventListener("submit", function (e) {
            // Validation logic for onboarding form
        });
    }

    // Validate Engagement Form
    if (engagementForm) {
        engagementForm.addEventListener("submit", function (e) {
            // Validation logic for engagement form
        });
    }

    // Validate Rating and Feedback Form
    if (ratingForm) {
        ratingForm.addEventListener("submit", function (e) {
            // Validation logic for rating form
        });
    }

    // Validate Classification Form
    if (classificationForm) {
        classificationForm.addEventListener("submit", function (e) {
            let isValid = true;
            const requiredFields = ["stakeholderName", "classificationCategory"];

            requiredFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field && !field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = "red";
                } else if (field) {
                    field.style.borderColor = "#ccc";
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert("Please complete all required fields.");
            }
        });
    }
});

// form_validation.js
document.addEventListener("DOMContentLoaded", function () {
    const onboardForm = document.getElementById("onboardForm");
    const engagementForm = document.getElementById("engagementForm");
    const ratingForm = document.getElementById("ratingForm");
    const classificationForm = document.getElementById("classificationForm");
    const retirementForm = document.getElementById("retirementForm");

    // Validate Onboard Form
    if (onboardForm) { /* Onboard form validation */ }

    // Validate Engagement Form
    if (engagementForm) { /* Engagement form validation */ }

    // Validate Rating and Feedback Form
    if (ratingForm) { /* Rating form validation */ }

    // Validate Classification Form
    if (classificationForm) { /* Classification form validation */ }

    // Validate Retirement Form
    if (retirementForm) {
        retirementForm.addEventListener("submit", function (e) {
            let isValid = true;
            const requiredFields = ["stakeholderName", "retirementReason"];

            requiredFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field && !field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = "red";
                } else if (field) {
                    field.style.borderColor = "#ccc";
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert("Please complete all required fields.");
            }
        });
    }
});
