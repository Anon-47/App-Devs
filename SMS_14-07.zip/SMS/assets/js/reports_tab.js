document.addEventListener("DOMContentLoaded", () => {
  fetch("../../api/fetch_report_metrics.php")
    .then(response => response.json())
    .then(data => {
      // Populate metrics
      document.getElementById('totalStakeholders').textContent = `Total Stakeholders: ${data.summary.stakeholders}`;
      document.getElementById('totalEngagements').textContent = `Total Engagements: ${data.summary.engagements}`;
      document.getElementById('totalUsers').textContent = `Total Users: ${data.summary.users}`;

      // Top Departments
      const deptList = document.getElementById('topDepartments');
      deptList.innerHTML = '';
      data.top_departments.forEach(d => {
        const li = document.createElement('li');
        li.textContent = `${d.department} - ${d.count} engagements`;
        deptList.appendChild(li);
      });

      // Top RMs
      const rmList = document.getElementById('topRMs');
      rmList.innerHTML = '';
      data.top_rms.forEach(rm => {
        const li = document.createElement('li');
        li.textContent = `${rm.name} - ${rm.count} engagements`;
        rmList.appendChild(li);
      });

      // Engagement Types
      const typeList = document.getElementById('engagementTypes');
      typeList.innerHTML = '';
      data.engagement_types.forEach(e => {
        const li = document.createElement('li');
        li.textContent = `${e.type}: ${e.count}`;
        typeList.appendChild(li);
      });
    })
    .catch(error => {
      console.error("Failed to load report data:", error);
    });
});
