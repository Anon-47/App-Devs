
// This script initializes charts for the admin dashboard
document.addEventListener("DOMContentLoaded", () => {
    fetch('../../api/admin_dashboard_data.php')
        .then(res => res.json())
        .then(data => {
            // User Roles Chart
            const userRoles = data.userRoles;
            const userLabels = userRoles.map(r => r.role);
            const userCounts = userRoles.map(r => r.count);
            const ctx1 = document.getElementById('userRolesChart')?.getContext('2d');
            if (ctx1) {
                new Chart(ctx1, {
                    type: 'bar',
                    data: {
                        labels: userLabels,
                        datasets: [{
                            label: 'Users by Role',
                            data: userCounts
                        }]
                    },
                    options: { responsive: true }
                });
            }

            // Engagement Types Chart
            const engagementTypes = data.engagementTypes;
            const engageLabels = engagementTypes.map(e => e.type);
            const engageCounts = engagementTypes.map(e => e.count);
            const ctx2 = document.getElementById('engagementTypesChart')?.getContext('2d');
            if (ctx2) {
                new Chart(ctx2, {
                    type: 'doughnut',
                    data: {
                        labels: engageLabels,
                        datasets: [{
                            label: 'Engagements',
                            data: engageCounts
                        }]
                    },
                    options: { responsive: true }
                });
            }

            // Active Departments Chart
            const activeDepts = data.activeDepartments;
            const deptLabels = activeDepts.map(d => d.department);
            const deptCounts = activeDepts.map(d => d.engagements);
            const ctx3 = document.getElementById('activeDepartmentsChart')?.getContext('2d');
            if (ctx3) {
                new Chart(ctx3, {
                    type: 'bar',
                    data: {
                        labels: deptLabels,
                        datasets: [{
                            label: 'Engagements',
                            data: deptCounts
                        }]
                    },
                    options: { responsive: true }
                });
            }

            // Summary Stats
            const summary = data.summary;
            const dbSummary = document.getElementById('dbSummary');
            if (dbSummary) {
                dbSummary.innerHTML = `
                    <li><strong>Users:</strong> ${summary.users}</li>
                    <li><strong>Stakeholders:</strong> ${summary.stakeholders}</li>
                    <li><strong>Engagements:</strong> ${summary.engagements}</li>
                `;
            }
        })
        .catch(error => console.error('Error loading dashboard data:', error));
});
