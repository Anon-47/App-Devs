<?php
require '../include/config.php';

$stakeholderId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$response = [];

try {
    // Fetch stakeholder core details
    $stmt = $pdo->prepare("SELECT s.*, u.email AS manager_email, u.full_name AS manager_name 
                           FROM stakeholders s
                           LEFT JOIN users u ON s.relationship_manager = u.id
                           WHERE s.id = ?");
    $stmt->execute([$stakeholderId]);
    $stakeholder = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$stakeholder) {
        echo json_encode(["error" => "Stakeholder not found"]);
        exit;
    }

    // Fetch engagement history
    $stmt2 = $pdo->prepare("SELECT * FROM stakeholder_engagements WHERE stakeholder_id = ? ORDER BY interaction_date DESC");
    $stmt2->execute([$stakeholderId]);
    $engagements = $stmt2->fetchAll(PDO::FETCH_ASSOC);

    $response['stakeholder'] = $stakeholder;
    $response['engagements'] = $engagements;

    header('Content-Type: application/json');
    echo json_encode($response);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
