<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

try {
    $conditions = [];
    $params = [];

    if (!empty($_GET['type'])) {
        $conditions[] = 'type = :type';
        $params[':type'] = $_GET['type'];
    }

    if (!empty($_GET['department'])) {
        $conditions[] = 'department = :department';
        $params[':department'] = $_GET['department'];
    }

    if (!empty($_GET['date_from']) && !empty($_GET['date_to'])) {
        $conditions[] = 'interaction_date BETWEEN :date_from AND :date_to';
        $params[':date_from'] = $_GET['date_from'];
        $params[':date_to'] = $_GET['date_to'];
    }

    $sql = "SELECT * FROM stakeholder_engagements";
    if (!empty($conditions)) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }
    $sql .= " ORDER BY interaction_date DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $data]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
