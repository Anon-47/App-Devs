<?php
require '../includes/config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['id']) && isset($_POST['rating'])) {
    $id = intval($_POST['id']);
    $rating = floatval($_POST['rating']);

    $stmt = $pdo->prepare("UPDATE stakeholders SET rating = ? WHERE id = ?");
    $stmt->execute([$rating, $id]);

    header("Location: ../views/evaluate_stakeholder.php?id=$id&status=success");
    exit;
}
