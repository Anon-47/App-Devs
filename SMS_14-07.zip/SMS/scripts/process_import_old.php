<?php
session_start();
require '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file']['tmp_name'];

    if (($handle = fopen($file, 'r')) !== false) {
        $header = fgetcsv($handle); // Skip header row

        while (($data = fgetcsv($handle, 1000, ',')) !== false) {
            // Extract fields from CSV (assuming order is fixed and matches the image)
            $s_name = $data[0];
            $organization = $data[1];
            $org_type = $data[2];
            $designation = $data[3];
            $contact = $data[4];
            $email = $data[5];
            $location = $data[6];
            $influence = $data[7];
            $interest = $data[8];
            $rel_manager_name = trim($data[9]);

            // Lookup relationship manager by full_name (Surname, Name)
            $rel_manager_id = null;
            if (!empty($rel_manager_name)) {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE full_name = ?");
                $stmt->execute([$rel_manager_name]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                $rel_manager_id = $result ? $result['id'] : null;
            }

            // Insert stakeholder record
            $insert = $pdo->prepare("INSERT INTO stakeholders 
                (s_name, organization, organization_type, designation, contact, email, location, influence_level, interest_level, relationship_manager)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $insert->execute([
                $s_name, $organization, $org_type, $designation, $contact, $email,
                $location, $influence, $interest, $rel_manager_id
            ]);
        }

        fclose($handle);
        $_SESSION['success'] = "Stakeholders imported successfully.";
    } else {
        $_SESSION['error'] = "Unable to read the file.";
    }
} else {
    $_SESSION['error'] = "Invalid request.";
}

header("Location: ../views/stakeholders/import_stakeholders.php");
exit();
?>
