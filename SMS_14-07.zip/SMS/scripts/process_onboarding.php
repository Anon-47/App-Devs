<?php
require '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO stakeholders 
        (s_name, organization, organization_type, designation, contact, email, location, influence_level, interest_level, relationship_manager)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    try {
        $stmt->execute([
            $_POST['s_name'],
            $_POST['organization'],
            $_POST['organization_type'],
            $_POST['designation'],
            $_POST['contact'],
            $_POST['email'],
            $_POST['location'],
            $_POST['influence_level'],
            $_POST['interest_level'],
            $_POST['relationship_manager']
        ]);
        header("Location: ../views/stakeholders.php?success=1");
        exit;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
