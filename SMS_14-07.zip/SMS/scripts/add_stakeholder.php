<?php
// scripts/add_stakeholder.php

require '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $type = $_POST['type'];
    $rating = $_POST['rating'];
    $status = 'pending';  // Default status for approval workflow

    try {
        $stmt = $pdo->prepare("INSERT INTO stakeholders (name, type, rating, status) VALUES (:name, :type, :rating, :status)");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':rating', $rating);
        $stmt->bindParam(':status', $status);
        $stmt->execute();
        header('Location: ../views/manage_stakeholders.php');
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
}
?>
