<?php
// File path: scripts/load_stakeholders.php

// Database connection
require_once '../includes/config.php';

try {
    // Fetch stakeholders with relationship manager email
    $query = "SELECT s.company, u.email AS relationship_manager, s.last_engagement, s.engagement_type, s.classification, s.rating
              FROM stakeholders s
              LEFT JOIN users u ON s.relationship_manager_id = u.id";
    $stmt = $pdo->prepare($query);
    $stmt->execute();

    // Check if records are found
    if ($stmt->rowCount() > 0) {
        echo "<table>";
        echo "<thead>";
        echo "<tr>
                <th>Company</th>
                <th>Relationship Manager</th>
                <th>Last Engagement</th>
                <th>Engagement Type</th>
                <th>Classification</th>
                <th>Rating</th>
              </tr>";
        echo "</thead>";
        echo "<tbody>";

        // Loop through stakeholders and display rows
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td><a href='stakeholder_profile.php?company=" . urlencode($row['company']) . "'>" . htmlspecialchars($row['company']) . "</a></td>";
            echo "<td>" . htmlspecialchars($row['relationship_manager']) . "</td>";
            echo "<td>" . htmlspecialchars($row['last_engagement']) . "</td>";
            echo "<td>" . htmlspecialchars($row['engagement_type']) . "</td>";
            echo "<td>" . htmlspecialchars($row['classification']) . "</td>";
            echo "<td>" . htmlspecialchars($row['rating']) . "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>No stakeholders found.</p>";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
