<?php
session_start();

$clientId = '862aa91a-d531-4bde-b74b-c76740efdb0b';
$clientSecret = '222c5dbf-eb04-4739-9ca9-d8b4cef57cc7';
$tenantId = '127ba93c-40ef-4d02-abf5-3ca72c8ab855';
$redirectUri = 'https://tsllogisticsltd.com/SMS/sso_callback.php';

if (!isset($_GET['code'])) {
    die("Authorization code missing.");
}

$tokenUrl = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token";

$postFields = [
    'client_id' => $clientId,
    'scope' => 'openid profile email',
    'code' => $_GET['code'],
    'redirect_uri' => $redirectUri,
    'grant_type' => 'authorization_code',
    'client_secret' => $clientSecret
];

// Request access token
$ch = curl_init($tokenUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

if (isset($data['access_token'])) {
    // Decode JWT to get user info
    $id_token_parts = explode(".", $data['id_token']);
    $claims = json_decode(base64_decode($id_token_parts[1]), true);

    $email = $claims['preferred_username'] ?? $claims['email'];

    // Check if user exists in your DB
    require 'config.php';
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user) {
    // User exists, log them in
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    header("Location: dashboard.php");
    exit;
} else {
    // Auto-create new user
    $username = explode("@", $email)[0]; // use prefix of email as username
    $role = 'User'; // default role

    $insert = $conn->prepare("INSERT INTO users (username, email, role, created_at) VALUES (?, ?, ?, NOW())");
    $insert->bind_param("sss", $username, $email, $role);
    if ($insert->execute()) {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $role;
        header("Location: dashboard.php");
        exit;
    } else {
        echo "Failed to auto-create user.";
    }
}


} else {
    echo "Token exchange failed.";
}
?>
