<?php
session_start();
session_unset();
session_destroy();

// Also logout from Microsoft (if applicable)
$logoutUrl = "https://login.microsoftonline.com/common/oauth2/v2.0/logout";
$redirectAfterLogout = "https://yourdomain.com/login.php";

header("Location: $logoutUrl?post_logout_redirect_uri=" . urlencode($redirectAfterLogout));
exit;
?>
