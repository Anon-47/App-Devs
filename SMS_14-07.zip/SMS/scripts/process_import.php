<?php
require '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($fileTmpPath, 'r');

        if ($handle === false) {
            header("Location: ../views/stakeholders/import_stakeholders.php?status=error&message=Could not open uploaded file.");
            exit;
        }

        // Skip header row
        fgetcsv($handle);

        $insertStmt = $pdo->prepare("INSERT INTO stakeholders (s_name, organization, organization_type, designation, contact, email, location, influence_level, interest_level, relationship_manager)
            VALUES (:name, :organization, :organization_type, :designation, :contact, :email, :location, :influence_level, :interest_level, :relationship_manager)");

        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM stakeholders WHERE email = :email");

        $skippedEmails = [];

        try {
            while (($data = fgetcsv($handle, 1000, ',')) !== false) {
                list($s_name, $organization, $organization_type, $designation, $contact, $email, $location, $influence_level, $interest_level, $relationship_manager) = $data;

                // Check if email already exists
                $checkStmt->execute([':email' => $email]);
                if ($checkStmt->fetchColumn() > 0) {
                    $skippedEmails[] = $email;
                    continue;
                }

                $insertStmt->execute([
                    ':name' => $s_name,
                    ':organization' => $organization,
                    ':organization_type' => $organization_type,
                    ':designation' => $designation,
                    ':contact' => $contact,
                    ':email' => $email,
                    ':location' => $location,
                    ':influence_level' => $influence_level,
                    ':interest_level' => $interest_level,
                    ':relationship_manager' => $relationship_manager
                ]);
            }

            fclose($handle);

            if (!empty($skippedEmails)) {
                $skippedMsg = 'Import completed. Skipped duplicate emails: ' . implode(', ', $skippedEmails);
                header("Location: ../views/stakeholders/import_stakeholders.php?status=partial&message=" . urlencode($skippedMsg));
            } else {
                header("Location: ../views/stakeholders/import_stakeholders.php?status=success");
            }
            exit;

        } catch (PDOException $e) {
            fclose($handle);
            header("Location: ../views/stakeholders/import_stakeholders.php?status=error&message=" . urlencode("Database error: " . $e->getMessage()));
            exit;
        }
    } else {
        header("Location: ../views/stakeholders/import_stakeholders.php?status=error&message=Invalid file upload.");
        exit;
    }
} else {
    header("Location: ../views/stakeholders/import_stakeholders.php?status=error&message=Invalid request.");
    exit;
}
