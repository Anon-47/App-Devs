<?php
// Path: /scripts/update_profile.php

session_start();
require_once '../includes/config.php'; // Include database connection

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];

// Validate input and prepare query
try {
    $query = "UPDATE users SET username = ?, email = ?";
    $params = [$username, $email];

    // If password is provided, hash it and add to update
    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $query .= ", password = ?";
        $params[] = $hashedPassword;
    }
    
    $query .= " WHERE id = ?";
    $params[] = $userId;

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);

    // Redirect back to profile page with a success message
    $_SESSION['message'] = "Profile updated successfully!";
    header("Location: ../views/my_profile.php");
} catch (PDOException $e) {
    die("Error updating profile: " . $e->getMessage());
}
?>
