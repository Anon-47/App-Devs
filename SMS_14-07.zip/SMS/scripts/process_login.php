<?php
// scripts/process_login.php
require_once '../includes/session.php';
require '../includes/config.php';

// Check if email and password have been provided in the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['email']) || !isset($_POST['password'])) {
        echo 'Error: Please provide both email and password.';
        exit();
    }

    // Sanitize and retrieve inputs
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    try {
        // Prepare and execute the query to fetch user by email
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verify if user exists and password is correct
        if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username']; // ADD this
        $_SESSION['role'] = $user['role'];         // FIX this

        // Optional logging if function exists
        if (function_exists('log_action')) {
            log_action($pdo, $user['id'], "User logged in.");
        }

        header('Location: ../views/dashboard.php');
        exit();
        }

    } catch (PDOException $e) {
        echo 'Database error: ' . $e->getMessage();
    }
} else {
    echo 'Invalid request method.';
    header('Location: ../views/index.php');  // Redirect on failure
}

// After successful login
log_action($pdo, $_SESSION['user_id'], "User logged in.");

?>
