<?php
require '../includes/config.php';

if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode([]);
    exit();
}

$id = intval($_GET['id']);
$stmt = $pdo->prepare("SELECT type, description, date FROM stakeholder_activities WHERE stakeholder_id = ? ORDER BY date DESC");
$stmt->execute([$id]);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
