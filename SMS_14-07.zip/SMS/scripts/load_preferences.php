<?php
// Path: scripts/load_preferences.php
session_start();
require_once '../config/db.php';

$userId = $_SESSION['user_id'];
$stmt = $db->prepare("SELECT theme, other_setting FROM preferences WHERE user_id = :user_id");
$stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
$stmt->execute();
$preferences = $stmt->fetch(PDO::FETCH_ASSOC);

// Return preferences as JSON
header('Content-Type: application/json');
echo json_encode($preferences);
?>
