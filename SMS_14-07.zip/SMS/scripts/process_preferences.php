<?php
// scripts/process_preferences.php
session_start();
require_once '../includes/config.php';

$user_id = $_SESSION['user_id']; // Assumes user is logged in
$theme = $_POST['theme'] ?? 'light';
$notifications_enabled = isset($_POST['notifications_enabled']) ? 1 : 0;
$language = $_POST['language'] ?? 'en';

try {
    // Check if preferences for the user already exist
    $stmt = $pdo->prepare("SELECT id FROM user_preferences WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $exists = $stmt->fetch();

    if ($exists) {
        // Update existing preferences
        $stmt = $pdo->prepare("UPDATE user_preferences SET theme = ?, notifications_enabled = ?, language = ? WHERE user_id = ?");
        $stmt->execute([$theme, $notifications_enabled, $language, $user_id]);
    } else {
        // Insert new preferences
        $stmt = $pdo->prepare("INSERT INTO user_preferences (user_id, theme, notifications_enabled, language) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $theme, $notifications_enabled, $language]);
    }
    $_SESSION['message'] = "Preferences updated successfully!";
    header("Location: ../views/system_preferences.php");
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
