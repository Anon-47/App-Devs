<?php
require '../includes/config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $stakeholder_id = $_POST['id'];
    $user_email = $_SESSION['user_email'] ?? 'Unknown';

    // Update stakeholder status to 'retired'
    $stmt = $pdo->prepare("UPDATE stakeholders SET account_status = 'retired' WHERE id = ?");
    $stmt->execute([$stakeholder_id]);

    // Insert into audit log
    $logStmt = $pdo->prepare("INSERT INTO stakeholder_audit_log (action_type, stakeholder_id, performed_by, timestamp)
                              VALUES (?, ?, ?, NOW())");
    $logStmt->execute(['retire_stakeholder', $stakeholder_id, $user_email]);

    // Redirect with success status
    header("Location: ../views/manage_stakeholders.php?status=retired_success");
    exit;
} else {
    echo "Invalid request.";
    exit;
}
