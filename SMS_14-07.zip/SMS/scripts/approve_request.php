<?php
session_start();
require '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    die("Unauthorized access.");
}

if (isset($_GET['id'], $_GET['action'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];
    $approved_by = $_SESSION['user_id'];

    // Get request details
    $stmt = $pdo->prepare("SELECT * FROM approvals WHERE id = ?");
    $stmt->execute([$id]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$request) {
        die("Request not found.");
    }

    $data = json_decode($request['request_data'], true);
    $requested_by = $request['requested_by'];

    // Execute approved action
    if ($action === 'approve') {
        if ($request['request_type'] === 'stakeholder_assignment') {
            $update = $pdo->prepare("UPDATE stakeholders SET relationship_manager = ? WHERE id = ?");
            $update->execute([$data['rm_id'], $data['stakeholder_id']]);
        }
        $status = 'approved';
    } else {
        $status = 'rejected';
    }

    // Update approvals table
    $update = $pdo->prepare("UPDATE approvals SET status = ?, approved_by = ? WHERE id = ?");
    $update->execute([$status, $approved_by, $id]);

    // Fetch requester email
    $user_stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
    $user_stmt->execute([$requested_by]);
    $user_email = $user_stmt->fetchColumn();

    // Send notification email
    $subject = "Approval Request Update";
    $message = "Your request has been $status.";
    $headers = "From: noreply@yourapp.com";

    mail($user_email, $subject, $message, $headers);

    echo "Request $status.";
}

// Log action
log_action($pdo, $approved_by, "Approval request ID $id marked as $status.");

?>
