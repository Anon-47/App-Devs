<?php
// scripts/process_signup.php
session_start();
require '../includes/config.php';

// Check if form was submitted via POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if required fields are set and not empty
    if (!isset($_POST['fullName'], $_POST['email'], $_POST['password']) || 
        empty(trim($_POST['fullName'])) || 
        empty(trim($_POST['email'])) || 
        empty(trim($_POST['password']))) {
        echo 'Error: Please provide all required fields.';
        exit();
    }

    // Retrieve and sanitize inputs
    $fullName = trim($_POST['fullName']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);  // Hash password

    try {
        // Insert the new user into the database
        $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role) VALUES (:full_name, :email, :password, 'user')");
        $stmt->bindParam(':full_name', $fullName);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password);
        $stmt->execute();

        // Redirect to login or dashboard upon successful signup
        header('Location: ../index.php');
        exit();
    } catch (PDOException $e) {
        echo 'Database error: ' . $e->getMessage();
    }
} else {
    echo 'Invalid request method.';
}
?>
