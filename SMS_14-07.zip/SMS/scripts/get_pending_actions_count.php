<?php
require_once '../includes/config.php'; // Assumes database connection file

header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM actions WHERE status = 'pending'");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode(['count' => $result['count']]);
} catch (Exception $e) {
    echo json_encode(['count' => 0]); // Default to 0 on error
}
?>