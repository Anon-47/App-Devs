<?php
// Path: scripts/save_preferences.php
session_start();
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $theme = $_POST['theme'];
    $otherSetting = $_POST['other_setting']; // adjust as needed

    $stmt = $db->prepare("INSERT INTO preferences (user_id, theme, other_setting)
                          VALUES (:user_id, :theme, :other_setting)
                          ON DUPLICATE KEY UPDATE theme = :theme, other_setting = :other_setting");
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->bindParam(':theme', $theme, PDO::PARAM_STR);
    $stmt->bindParam(':other_setting', $otherSetting, PDO::PARAM_STR);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Preferences updated!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update preferences.']);
    }
}
?>
