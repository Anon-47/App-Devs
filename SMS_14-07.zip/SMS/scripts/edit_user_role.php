<!-- scripts/edit_user_role.php -->
<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] !== 'superuser' && $_SESSION['user_role'] !== 'administrator')) {
    header('Location: ../views/index.php'); // Restrict access to admins and superusers
    exit();
}

require '../includes/config.php'; // Database connection

$userId = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newRole = $_POST['role'];

    try {
        $stmt = $pdo->prepare("UPDATE users SET role = :role WHERE id = :id");
        $stmt->bindParam(':role', $newRole);
        $stmt->bindParam(':id', $userId);
        $stmt->execute();
        header('Location: ../views/manage_users.php');  // Redirect back to user management page
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User Role</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <h1>Edit User Role</h1>

    <form method="POST">
        <label for="role">Select Role:</label>
        <select name="role" id="role">
            <option value="superuser">Superuser</option>
            <option value="administrator">Administrator</option>
            <option value="manager">Manager</option>
            <option value="user">User</option>
        </select>
        <button type="submit">Update Role</button>
    </form>
</body>
</html>
