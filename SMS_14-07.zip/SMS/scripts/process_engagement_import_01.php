<?php
require '../includes/config.php';
require '../includes/session.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $fileTmp = $_FILES['csv_file']['tmp_name'];

    if (($handle = fopen($fileTmp, 'r')) !== false) {
        $header = fgetcsv($handle, 1000, ','); // Skip CSV header

        $successCount = 0;
        $errorCount = 0;
        $errors = [];

        while (($data = fgetcsv($handle, 1000, ',')) !== false) {
            // Sanitize and extract
            list(
                $department,
                $contact,
                $firstName,
                $lastName,
                $dateOfInteraction,
                $clientCompany,
                $location,
                $influenceLevel,
                $interestLevel,
                $rmFullName
            ) = $data;

            // Match RM by name
            $rmParts = explode(' ', trim($rmFullName));
            $rmFirst = $rmParts[0] ?? '';
            $rmLast = $rmParts[1] ?? '';

            $rmQuery = $pdo->prepare("SELECT id FROM users WHERE first_name = ? AND last_name = ?");
            $rmQuery->execute([$rmFirst, $rmLast]);
            $rm = $rmQuery->fetch();

            if (!$rm) {
                $errorCount++;
                $errors[] = "RM not found: $rmFullName (for stakeholder $contact)";
                continue;
            }

            $stmt = $pdo->prepare("INSERT INTO stakeholder_engagements 
                (department, contact, staff_first_name, staff_last_name, date_of_interaction, client, 
                location, influence_level, interest_level, rm_user_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $success = $stmt->execute([
                $department,
                $contact,
                $firstName,
                $lastName,
                $dateOfInteraction,
                $clientCompany,
                $location,
                $influenceLevel,
                $interestLevel,
                $rm['id']
            ]);

            $success ? $successCount++ : $errorCount++;
        }

        fclose($handle);

        $_SESSION['success'] = "$successCount engagements imported successfully.";
        if ($errorCount > 0) {
            $_SESSION['error'] = "$errorCount rows failed. Issues: " . implode(', ', $errors);
        }

        header("Location: ../views/import_engagements.php");
        exit;
    } else {
        $_SESSION['error'] = "Unable to read CSV file.";
        header("Location: ../views/import_engagements.php");
        exit;
    }
} else {
    $_SESSION['error'] = "Invalid request.";
    header("Location: ../views/import_engagements.php");
    exit;
}
