<?php
// process_engagement.php

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Extract data from the engagement form
    $engagementDate = $_POST['engagementDate'] ?? '';
    $relationshipManager = $_POST['relationshipManager'] ?? '';
    $engagementType = $_POST['engagementType'] ?? '';
    $notes = $_POST['notes'] ?? '';
    $nextEngagementDate = $_POST['nextEngagementDate'] ?? '';

    // Display data as a temporary confirmation
    echo "Engagement Data Received:<br>";
    echo "Engagement Date: $engagementDate<br>";
    echo "Relationship Manager: $relationshipManager<br>";
    echo "Engagement Type: $engagementType<br>";
    echo "Notes: $notes<br>";
    echo "Next Engagement Date: $nextEngagementDate<br>";
} else {
    echo "Invalid request method.";
}
?>
