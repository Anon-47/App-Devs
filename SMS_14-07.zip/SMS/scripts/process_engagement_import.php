<?php
require '../includes/config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $fileTmp = $_FILES['csv_file']['tmp_name'];

    if (($handle = fopen($fileTmp, 'r')) !== false) {
        $header = fgetcsv($handle, 1000, ',');

        $imported = 0;
        $skipped = 0;
        $unmatchedStakeholders = [];

        while (($data = fgetcsv($handle, 1000, ',')) !== false) {
            list(
                $department,
                $staff_full_name,
                $interaction_date,
                $company,
                $stakeholder_type,
                $category_of_stakeholder,
                $stakeholder_fullname,
                $in_department_db,
                $interaction_nature,
                $other_details,
                $follow_up_action,
                $trace_score
            ) = $data;

            // Find RM ID if exists
            $rmId = null;
            $stmt = $pdo->prepare("SELECT id FROM users WHERE full_name = ?");
            $stmt->execute([trim($staff_full_name)]);
            $user = $stmt->fetch();

            if ($user) {
                $rmId = $user['id'];
            }

            // Find stakeholder ID
            $stakeholderStmt = $pdo->prepare("SELECT id FROM stakeholders WHERE s_name = ?");
            $stakeholderStmt->execute([trim($stakeholder_fullname)]);
            $stakeholder = $stakeholderStmt->fetch();

            if (!$stakeholder) {
                $unmatchedStakeholders[] = trim($stakeholder_fullname);
                $skipped++;
                continue;
            }

            $stakeholder_id = $stakeholder['id'];

            $insert = $pdo->prepare("INSERT INTO stakeholder_engagements (
                department, staff_full_name, interaction_date, company,
                stakeholder_type, stakeholder_category, stakeholder_fullname,
                in_department_db, interaction_nature, other_details,
                follow_up_action, trace_score, relationship_manager_id, stakeholder_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $success = $insert->execute([
                $department,
                $staff_full_name,
                date('Y-m-d', strtotime($interaction_date)),
                $company,
                $stakeholder_type,
                $category_of_stakeholder,
                $stakeholder_fullname,
                $in_department_db,
                $interaction_nature,
                $other_details,
                $follow_up_action,
                $trace_score,
                $rmId,
                $stakeholder_id
            ]);

            if ($success) {
                $imported++;
            } else {
                $skipped++;
            }
        }

        fclose($handle);

        $_SESSION['import_summary'] = [
            'imported' => $imported,
            'skipped' => $skipped,
            'unmatched' => $unmatchedStakeholders
        ];
        header("Location: ../views/import_engagements.php");
        exit;
    } else {
        $_SESSION['error'] = "Error opening CSV file.";
        header("Location: ../views/import_engagements.php");
        exit;
    }
} else {
    $_SESSION['error'] = "Invalid request.";
    header("Location: ../views/import_engagements.php");
    exit;
}
