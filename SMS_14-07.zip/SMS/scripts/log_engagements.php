<?php
require '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // 1. Resolve stakeholder ID from company name
        $company = trim($_POST['company']);
        $stmt = $pdo->prepare("SELECT id FROM stakeholders WHERE organization = ?");
        $stmt->execute([$company]);
        $stakeholder = $stmt->fetch();

        if (!$stakeholder) {
            echo "<script>alert('❌ Stakeholder not found for company: " . htmlspecialchars($company) . "'); window.history.back();</script>";
            exit;
        }

        $stakeholder_id = $stakeholder['id'];

        // 2. Validate dropdown values
        $valid_types = ['Business', 'Regulatory', 'Vendors', 'Community', 'Advocacy Group'];
        $valid_categories = ['Cheer Leader', 'Uncharted', 'Fans', 'Observers'];

        $type = trim($_POST['stakeholder_type']);
        $category = trim($_POST['stakeholder_category']);

        if (!in_array($type, $valid_types)) {
            echo "<script>alert('❌ Invalid stakeholder type selected.'); window.history.back();</script>";
            exit;
        }

        if (!in_array($category, $valid_categories)) {
            echo "<script>alert('❌ Invalid stakeholder category selected.'); window.history.back();</script>";
            exit;
        }

        // 3. Prepare and execute insert
        $insert = $pdo->prepare("
            INSERT INTO stakeholder_engagements (
                stakeholder_id,
                department,
                staff_full_name,
                interaction_date,
                company,
                stakeholder_type,
                stakeholder_category,
                stakeholder_fullname,
                in_department_db,
                interaction_nature,
                other_details,
                follow_up_action,
                trace_score,
                created_at
            ) VALUES (
                :stakeholder_id,
                :department,
                :staff_full_name,
                :interaction_date,
                :company,
                :stakeholder_type,
                :stakeholder_category,
                :stakeholder_fullname,
                :in_department_db,
                :interaction_nature,
                :other_details,
                :follow_up_action,
                :trace_score,
                NOW()
            )
        ");

        $insert->execute([
            ':stakeholder_id'        => $stakeholder_id,
            ':department'            => trim($_POST['department']),
            ':staff_full_name'       => trim($_POST['staff_full_name']),
            ':interaction_date'      => trim($_POST['interaction_date']),
            ':company'               => $company,
            ':stakeholder_type'      => $type,
            ':stakeholder_category'  => $category,
            ':stakeholder_fullname'  => trim($_POST['stakeholder_fullname']),
            ':in_department_db'      => trim($_POST['in_department_db']),
            ':interaction_nature'    => trim($_POST['interaction_nature']),
            ':other_details'         => trim($_POST['other_details']),
            ':follow_up_action'      => trim($_POST['follow_up_action']),
            ':trace_score'           => trim($_POST['trace_score'])
        ]);

        // 4. Redirect with status flag
        header("Location: ../views/profile_stakeholder.php?id={$stakeholder_id}&status=success");
        exit;

    } catch (PDOException $e) {
        echo "<script>alert('❌ Failed to log engagement: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
    }
} else {
    echo "Invalid request method.";
}
