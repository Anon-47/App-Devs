// Place at the very top of the PHP file before any output
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

<?php
require_once '../includes/config.php';

$dept = $_GET['dept'] ?? '';
$rm = $_GET['rm'] ?? '';
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';

$where = "WHERE 1";
if ($dept !== '') $where .= " AND department = '" . mysqli_real_escape_string($conn, $dept) . "'";
if ($rm !== '') $where .= " AND relationship_manager_id = '" . mysqli_real_escape_string($conn, $rm) . "'";
if ($start !== '') $where .= " AND DATE(engagement_date) >= '$start'";
if ($end !== '') $where .= " AND DATE(engagement_date) <= '$end'";

// Totals
$totals = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT 
        COUNT(DISTINCT stakeholder_id) AS stakeholder_count,
        COUNT(id) AS engagement_count
    FROM stakeholder_engagements
    $where
"));

// Stakeholder by Type
$type_data = mysqli_query($conn, "
    SELECT s.type, COUNT(*) as total
    FROM stakeholders s
    JOIN stakeholder_engagements e ON e.stakeholder_id = s.id
    $where
    GROUP BY s.type
");
$typeLabels = $typeValues = [];
while ($row = mysqli_fetch_assoc($type_data)) {
    $typeLabels[] = $row['type'] ?: 'Unknown';
    $typeValues[] = $row['total'];
}

// Stakeholder by Category
$cat_data = mysqli_query($conn, "
    SELECT s.category, COUNT(*) as total
    FROM stakeholders s
    JOIN stakeholder_engagements e ON e.stakeholder_id = s.id
    $where
    GROUP BY s.category
");
$catLabels = $catValues = [];
while ($row = mysqli_fetch_assoc($cat_data)) {
    $catLabels[] = $row['category'] ?: 'Unknown';
    $catValues[] = $row['total'];
}

// Follow-up Status
$follow_data = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT 
        SUM(CASE WHEN followed_up = 'Yes' THEN 1 ELSE 0 END) AS followed,
        SUM(CASE WHEN followed_up = 'No' THEN 1 ELSE 0 END) AS not_followed
    FROM stakeholder_engagements
    $where
"));
$followRate = [
    (int)$follow_data['followed'],
    (int)$follow_data['not_followed']
];

// HTML output
$html = "
<div class='summary-box'>
    <strong>Department:</strong> " . ($dept ?: "All") . "<br>
    <strong>Stakeholders:</strong> {$totals['stakeholder_count']}<br>
    <strong>Engagements:</strong> {$totals['engagement_count']}
</div>

<canvas id='typeChart' height='100'></canvas>
<canvas id='catChart' height='100'></canvas>
<canvas id='followChart' height='100'></canvas>
";

echo json_encode([
    'html' => $html,
    'charts' => [
        'types' => ['labels' => $typeLabels, 'values' => $typeValues],
        'categories' => ['labels' => $catLabels, 'values' => $catValues],
        'followupRate' => $followRate
    ]
]);
