<?php
require_once("../includes/config.php");
require_once("../includes/functions.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);

    $params = [
        $_POST['s_name'], $_POST['organization'], $_POST['designation'], $_POST['location'],
        $_POST['organization_type'], $_POST['influence_level'], $_POST['interest_level'],
        $_POST['contact'], $_POST['email'], $_POST['assigned_rm'], $id
    ];

    $sql = "UPDATE stakeholders SET 
        s_name=?, organization=?, designation=?, location=?, organization_type=?,
        influence_level=?, interest_level=?, contact=?, email=?, assigned_rm=? 
        WHERE id=?";

    $updated = executeQuery($sql, $params);
    
    if ($updated) {
        header("Location: manage_stakeholders.php?updated=1");
        exit;
    } else {
        echo "Error updating stakeholder.";
    }
}
?>
