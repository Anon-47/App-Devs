<?php
require '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO stakeholder_engagements (
                stakeholder_id,
                department,
                staff_full_name,
                interaction_date,
                company,
                stakeholder_type,
                stakeholder_category,
                stakeholder_fullname,
                in_department_db,
                interaction_nature,
                other_details,
                follow_up_action,
                trace_score,
                created_at
            ) VALUES (
                :stakeholder_id,
                :department,
                :staff_full_name,
                :interaction_date,
                :client_company,
                :stakeholder_type,
                :stakeholder_category,
                :stakeholder_fullname,
                :in_department_db,
                :interaction_nature,
                :other_details,
                :follow_up_action,
                :trace_score,
                NOW()
            )
        ");

        $stmt->execute([
            ':stakeholder_id'        => $_POST['stakeholder_id'],
            ':department'            => $_POST['department'],
            ':staff_full_name'      => $_POST['staff_full_name'],
            ':interaction_date'      => $_POST['interaction_date'],
            ':client_company'        => $_POST['client_company'],
            ':stakeholder_type'      => $_POST['stakeholder_type'],
            ':stakeholder_category'  => $_POST['stakeholder_category'],
            ':stakeholder_fullname' => $_POST['stakeholder_fullname'],
            ':in_department_db'         => $_POST['in_department_db'],
            ':interaction_nature' => $_POST['interaction_nature'],
            ':other_details'   => $_POST['other_details'],
            ':follow_up_action'        => $_POST['follow_up_action'],
            ':trace_score'           => $_POST['trace_score'],
        ]);
        
        echo "<script>alert('✅ Engagement logged successfully.'); window.location.href='./views/stakeholder_profile.php?id={$_POST['stakeholder_id']}';</script>";
        exit;

        // Redirect or send JSON response
        header("Location: ../views/stakeholder_profile.php?id=" . $_POST['stakeholder_id']);
        exit;

    } catch (PDOException $e) {
        echo "<script>alert('❌ Failed to log engagement: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
    }
} else {
    echo "Invalid request method.";
}
