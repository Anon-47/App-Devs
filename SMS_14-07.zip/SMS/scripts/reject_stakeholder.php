<?php
// scripts/reject_stakeholder.php

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'manager') {
    header('Location: ../views/index.php'); // Restrict access to managers
    exit();
}

require '../includes/config.php'; // Database connection

$stakeholderId = $_GET['id'];

try {
    // Reject stakeholder by deleting the record or setting status to 'rejected'
    $stmt = $pdo->prepare("UPDATE stakeholders SET status = 'rejected' WHERE id = :id");
    $stmt->bindParam(':id', $stakeholderId);
    $stmt->execute();
    header('Location: ../views/approve_stakeholders.php');  // Redirect back to approval page
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>
