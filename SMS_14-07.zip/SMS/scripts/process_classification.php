<?php
// process_classification.php

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Extract data from the classification form
    $stakeholderName = $_POST['stakeholderName'] ?? '';
    $classificationCategory = $_POST['classificationCategory'] ?? '';
    $classificationReason = $_POST['classificationReason'] ?? '';

    // Display data temporarily
    echo "Classification Data Received:<br>";
    echo "Stakeholder Name: $stakeholderName<br>";
    echo "Classification Category: $classificationCategory<br>";
    echo "Reason for Classification: $classificationReason<br>";
} else {
    echo "Invalid request method.";
}
?>
