<?php
// Initialize session
session_start();

// Before destroying session
//log_action($pdo, $_SESSION['user_id'], "User logged out.");

// Destroy all session variables
$_SESSION = [];

// Destroy the session
session_destroy();

// Redirect to login page with a "see you soon" message
header("Location: ../views/index.php?message=" . urlencode("See you soon!"));
exit();
