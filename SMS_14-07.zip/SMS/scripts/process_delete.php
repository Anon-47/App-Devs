<?php
require '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];

    $stmt = $pdo->prepare("DELETE FROM stakeholders WHERE id = ?");
    $stmt->execute([$id]);

    header("Location: ../views/manage_stakeholders.php?status=deleted");
    exit;
} else {
    echo "Invalid request.";
}
