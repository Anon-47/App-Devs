<?php
session_start();

$clientId = '862aa91a-d531-4bde-b74b-c76740efdb0b';
$tenantId = '127ba93c-40ef-4d02-abf5-3ca72c8ab855';
$redirectUri = 'https://tsllogisticsltd.com/SMS/sso_callback.php';
$scope = 'openid profile email';

$authUrl = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/authorize?"
         . "client_id=$clientId"
         . "&response_type=code"
         . "&redirect_uri=" . urlencode($redirectUri)
         . "&response_mode=query"
         . "&scope=" . urlencode($scope)
         . "&state=secureRandomState123";

header("Location: $authUrl");
exit;
?>
