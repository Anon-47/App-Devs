<!-- onboard_stakeholder.php -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Onboard New Stakeholder</title>
    <link rel="stylesheet" href="../assets/css/forms.css">
    <script src="../assets/js/script.js"></script>
    <script src="../assets/js/form_validation.js"></script>
</head>

<div class="form-container">
    <h2>Onboard New Stakeholder</h2>
    <form action="../scripts/process_onboarding.php" method="POST" id="onboardForm">
        <!-- Surname Field -->
        <label for="surname">Surname*</label>
        <input type="text" name="surname" id="surname" required>

        <!-- First Name Field -->
        <label for="firstName">First Name*</label>
        <input type="text" name="firstName" id="firstName" required>

        <!-- Company Field -->
        <label for="company">Company*</label>
        <input type="text" name="company" id="company" required>

        <!-- Designation Field -->
        <label for="designation">Designation*</label>
        <input type="text" name="designation" id="designation" required>

        <!-- Phone Field -->
        <label for="phone">Phone</label>
        <input type="text" name="phone" id="phone">

        <!-- Email Field -->
        <label for="email">Email</label>
        <input type="email" name="email" id="email">

        <!-- Preferred Communication Channel -->
        <label for="communicationChannel">Preferred Communication Channel</label>
        <select name="communicationChannel" id="communicationChannel">
            <option value="email">Email</option>
            <option value="phone">Phone</option>
            <option value="in_app_message">In-App Message</option>
        </select>

        <!-- Classification Field -->
        <label for="classification">Classification</label>
        <select name="classification" id="classification">
            <option value="primary">Primary</option>
            <option value="secondary">Secondary</option>
            <option value="tertiary">Tertiary</option>
        </select>

        <!-- Submit Button -->
        <button type="submit">Submit</button>
    </form>
</div>
