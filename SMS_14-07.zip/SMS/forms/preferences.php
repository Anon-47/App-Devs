<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Preferences</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h2>System Preferences</h2>
    <form id="preferences-form">
        <label for="theme">Select Theme:</label>
        <select id="theme" name="theme">
            <option value="default">Default</option>
            <option value="dark">Dark</option>
            <option value="light">Light</option>
        </select>

        <label for="other_setting">Other Setting:</label>
        <input type="text" id="other_setting" name="other_setting" placeholder="Add your preference">

        <button type="submit">Save Preferences</button>
    </form>

    <script src="js/preferences.js"></script>
</body>
</html>
