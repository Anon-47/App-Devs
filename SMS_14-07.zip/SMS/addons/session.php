<?php
session_name("sms_app");
$secure = isset($_SERVER['HTTPS']);
$httponly = true;
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => $secure,
    'httponly' => $httponly,
    'samesite' => 'Lax'
]);
session_start();

// Inactivity Timeout: 15 minutes
$inactive = 900;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    session_unset();
    session_destroy();
    header("Location: /login.php?timeout=1");
    exit;
}
$_SESSION['last_activity'] = time();
?>
