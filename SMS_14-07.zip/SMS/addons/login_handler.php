<?php
include 'config.php';
include 'session.php'; // include the secure session

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($pass, $row['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['last_activity'] = time();
            header("Location: /dashboard/index.php");
            exit;
        }
    }
    $_SESSION['flash'] = "Invalid login credentials.";
    header("Location: /login.php");
    exit;
}
?>
