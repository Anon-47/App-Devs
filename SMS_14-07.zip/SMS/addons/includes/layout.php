<?php
if (!isset($pageTitle)) $pageTitle = "SMS App";
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= $pageTitle ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="/assets/css/global.css">
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
  <header class="bg-blue-800 text-white p-4 text-xl font-semibold">Stakeholder Management System</header>
  <main class="flex-1 p-6">
    <?php if (isset($_SESSION['flash'])): ?>
      <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4"><?= $_SESSION['flash']; unset($_SESSION['flash']); ?></div>
    <?php endif; ?>
    <?php include($pageContent); ?>
  </main>
  <footer class="bg-blue-800 text-white p-2 text-center text-sm">© <?= date("Y") ?> SMS App</footer>
</body>
</html>
