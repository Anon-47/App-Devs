<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Server Error</title>
    <link rel="stylesheet" href="../assets/css/error.css">
</head>
<body>
    <div class="error-page">
        <h1>500</h1>
        <p>Something went wrong on our end. Please try again later.</p>
        <a href="dashboard.php" class="button">Back to Dashboard</a>
    </div>
</body>
</html>
