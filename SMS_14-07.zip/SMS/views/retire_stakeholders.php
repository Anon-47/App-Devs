<!-- retire_stakeholder.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retire Stakeholder</title>
    <link rel="stylesheet" href="../assets/css/forms.css">
    <script src="../assets/js/form_validation.js"></script>
</head>
<body>

<div class="form-container">
    <h2>Retire Stakeholder</h2>
    <form action="../scripts/process_retirement.php" method="POST" id="retirementForm">
        <!-- Stakeholder Name -->
        <label for="stakeholderName">Stakeholder Name*</label>
        <select name="stakeholderName" id="stakeholderName" required>
            <option value="">Select Stakeholder</option>
            <!-- Populate options dynamically from active stakeholders -->
            <option value="stakeholder1">Stakeholder 1</option>
            <option value="stakeholder2">Stakeholder 2</option>
        </select>

        <!-- Retirement Reason -->
        <label for="retirementReason">Reason for Retirement*</label>
        <select name="retirementReason" id="retirementReason" required>
            <option value="">Select Reason</option>
            <option value="no_longer_active">No Longer Active</option>
            <option value="end_of_contract">End of Contract</option>
            <option value="business_decision">Business Decision</option>
            <option value="other">Other</option>
        </select>

        <!-- Notes (Optional) -->
        <label for="notes">Additional Notes</label>
        <textarea name="notes" id="notes" rows="4" placeholder="Provide any additional notes..."></textarea>

        <!-- Submit Button -->
        <button type="submit">Retire Stakeholder</button>
    </form>
</div>

</body>
</html>
