<?php
session_start();
require '../includes/config.php';

if (!isset($_GET['id'])) {
    echo "No stakeholder ID provided.";
    exit;
}

$id = intval($_GET['id']);

try {
    $stmt = $pdo->prepare("
        SELECT s.*, u.email AS manager_email 
        FROM stakeholders s
        LEFT JOIN users u ON s.relationship_manager = u.id 
        WHERE s.id = ?
    ");
    $stmt->execute([$id]);
    $stakeholder = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$stakeholder) {
        echo "Stakeholder not found.";
        exit;
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}
?>

<h2>Stakeholder Details</h2>
<ul>
    <li><strong>Name:</strong> <?= htmlspecialchars($stakeholder['name']) ?></li>
    <li><strong>Organization:</strong> <?= htmlspecialchars($stakeholder['organization']) ?></li>
    <li><strong>Type:</strong> <?= htmlspecialchars($stakeholder['organization_type']) ?></li>
    <li><strong>Designation:</strong> <?= htmlspecialchars($stakeholder['designation']) ?></li>
    <li><strong>Contact:</strong> <?= htmlspecialchars($stakeholder['contact']) ?></li>
    <li><strong>Email:</strong> <?= htmlspecialchars($stakeholder['email']) ?></li>
    <li><strong>Location:</strong> <?= htmlspecialchars($stakeholder['location']) ?></li>
    <li><strong>Influence Level:</strong> <?= htmlspecialchars($stakeholder['influence_level']) ?></li>
    <li><strong>Interest Level:</strong> <?= htmlspecialchars($stakeholder['interest_level']) ?></li>
    <li><strong>Relationship Manager:</strong> <?= htmlspecialchars($stakeholder['manager_email']) ?></li>
</ul>
