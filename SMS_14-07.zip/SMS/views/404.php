<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Page Not Found</title>
    <link rel="stylesheet" href="../assets/css/error.css">
</head>
<body>
    <div class="error-page">
        <h1>404</h1>
        <p>Oops! The page you’re looking for can’t be found.</p>
        <a href="dashboard.php" class="button">Back to Dashboard</a>
    </div>
</body>
</html>
