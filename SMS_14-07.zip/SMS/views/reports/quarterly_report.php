<?php require_once '../../includes/session.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quarterly Engagement Reports</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="report-container">
        <h2>📊 Quarterly Engagement Report</h2>

        <!-- Filters -->
        <label for="filter-year">Year:</label>
        <select id="filter-year" class="form-control"></select>

        <label for="quarter">Quarter:</label>
        <select id="quarter">
            <option value="Q1">Q1 (Jan–Mar)</option>
            <option value="Q2">Q2 (Apr–Jun)</option>
            <option value="Q3">Q3 (Jul–Sep)</option>
            <option value="Q4">Q4 (Oct–Dec)</option>
        </select>

        <button onclick="loadReport()">Load Report</button>

        <canvas id="quarterlyChart" width="500" height="300"></canvas>
    </div>

    <script src="../../assets/js/quarterly_charts.js"></script>
    <script>
        // Ensure the report loads correctly when loaded dynamically
        document.addEventListener("DOMContentLoaded", () => {
            if (typeof initQuarterlyReport === 'function') {
                initQuarterlyReport();
            }
        });
    </script>
</body>
</html>
