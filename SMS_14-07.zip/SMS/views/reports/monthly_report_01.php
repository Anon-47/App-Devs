<?php
require_once '../../includes/config.php';
require_once '../../includes/session.php';

$selected_month = $_GET['month'] ?? date('Y-m');
$selected_department = $_GET['department'] ?? '';

// Fetch department list
$departments = $pdo->query("SELECT DISTINCT department FROM stakeholder_engagements ORDER BY department")->fetchAll(PDO::FETCH_COLUMN);

// Build query
$query = "SELECT department, COUNT(*) as total FROM stakeholder_engagements WHERE DATE_FORMAT(interaction_date, '%Y-%m') = :month";
$params = [':month' => $selected_month];

if (!empty($selected_department)) {
    $query .= " AND department = :department";
    $params[':department'] = $selected_department;
}

$query .= " GROUP BY department";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Monthly Engagement Report</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .report-container {
            max-width: 1000px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }
        .filter-form select {
            padding: 5px 10px;
            margin-right: 10px;
        }
        .report-table {
            margin-top: 30px;
            width: 100%;
            border-collapse: collapse;
        }
        .report-table th, .report-table td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        .report-table tr:nth-child(even) {
            background-color: #f8f8f8;
        }
        .chart-box {
            margin: 30px 0;
        }
        .export-btn {
            margin-top: 20px;
            padding: 8px 15px;
            background: #444;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .export-btn:hover {
            background: #222;
        }
    </style>
</head>
<body>
    <div class="report-container">
        <h2>📊 Monthly Engagement Report</h2>

        <!-- Filters -->
        <form class="filter-form" method="get">
            <label for="month">Month:</label>
            <input type="month" name="month" value="<?= htmlspecialchars($selected_month) ?>">

            <label for="department">Department:</label>
            <select name="department">
                <option value="">All</option>
                <?php foreach ($departments as $dpt): ?>
                    <option value="<?= htmlspecialchars($dpt) ?>" <?= $dpt == $selected_department ? 'selected' : '' ?>>
                        <?= htmlspecialchars($dpt) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Filter</button>
        </form>

        <!-- Chart -->
        <div class="chart-box">
            <canvas id="monthlyChart"></canvas>
        </div>

        <!-- Table -->
        <table class="report-table">
            <thead>
                <tr>
                    <th>Department</th>
                    <th>Engagements</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['department']) ?></td>
                        <td><?= $row['total'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Export CSV -->
        <form method="post" action="generate_report.php" style="margin-top:20px;">
            <input type="hidden" name="report_type" value="monthly">
            <input type="hidden" name="month" value="<?= htmlspecialchars($selected_month) ?>">
            <input type="hidden" name="department" value="<?= htmlspecialchars($selected_department) ?>">
            <button type="submit" class="export-btn">⬇️ Export to CSV</button>
        </form>
    </div>

    <script>
        const ctx = document.getElementById('monthlyChart').getContext('2d');
        const chartData = {
            labels: <?= json_encode(array_column($data, 'department')) ?>,
            datasets: [{
                label: 'Engagements',
                data: <?= json_encode(array_column($data, 'total')) ?>,
                backgroundColor: 'rgba(255, 159, 64, 0.7)',
                borderColor: 'rgba(255, 159, 64, 1)',
                borderWidth: 1
            }]
        };

        new Chart(ctx, {
            type: 'bar',
            data: chartData,
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: { display: true, text: 'No. of Engagements' }
                    }
                }
            }
        });
    </script>
</body>
</html>
