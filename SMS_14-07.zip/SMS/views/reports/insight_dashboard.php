<?php
require_once '../../includes/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stakeholder Insight Dashboard</title>
    <link rel="stylesheet" href="../../assets/css/insight_dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .filters {
            margin-bottom: 30px;
        }
        .filters label {
            margin-right: 5px;
        }
        .filters select, .filters input {
            margin-right: 15px;
            padding: 6px;
        }
        #insights {
            margin-top: 30px;
        }
        .summary-box {
            padding: 15px;
            background: #f3f3f3;
            border-radius: 6px;
            margin-bottom: 30px;
            border-left: 5px solid #DA8A1D;
        }
        .chart-block {
            margin-bottom: 40px;
        }
        canvas {
            max-width: 100%;
        }
        .chart-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
            gap: 24px;
            margin-top: 20px;
        }

        .chart-box {
            background: #ffffff;
            border-radius: 8px;
            padding: 16px 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
            border-left: 5px solid #a78bfa;
        }

        .chart-box:hover {
            transform: scale(1.02);
        }

        .chart-box h4 {
            margin-top: 0;
            font-size: 16px;
            color: #4b5563;
            font-weight: 600;
            margin-bottom: 12px;
        }

        .placeholder {
            text-align: center;
            background: #f3f4f6;
            border-left: 5px dashed #9ca3af;
        }

        .note {
            color: #6b7280;
            font-size: 14px;
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <h2>📊 Stakeholder Insight Dashboard</h2>

    <div class="filters">
        <label for="department">Department:</label>
        <select id="department">
            <option value="">All</option>
        </select>

        <label for="rm">Relationship Manager:</label>
        <select id="rm">
            <option value="">All</option>
        </select>

        <label for="startDate">From:</label>
        <input type="date" id="startDate">

        <label for="endDate">To:</label>
        <input type="date" id="endDate">

        <button id="applyBtn" onclick="loadInsights()">Apply</button>
    </div>

    <!-- Dynamic Insights and Charts will be injected here -->
    <div id="insights">
        <div class="charts-grid">
            <div class="chart-box">
                <h4>Stakeholder Types</h4>
                <canvas id="typeChart"></canvas>
            </div>
            <div class="chart-box">
                <h4>Stakeholder Categories</h4>
                <canvas id="catChart"></canvas>
            </div>
            <div class="chart-box">
                <h4>Follow-Up Rate</h4>
                <canvas id="followChart"></canvas>
            </div>
            <div class="chart-box placeholder">
                <h4>Coming Soon</h4>
                <p>More metrics will appear here...</p>
            </div>
        </div>

        <!-- JS will populate this -->
    </div>

    <script src="../../assets/js/insight_dashboard.js"></script>

</body>
</html>
