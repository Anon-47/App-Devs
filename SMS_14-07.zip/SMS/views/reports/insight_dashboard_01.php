<?php
require_once '../../includes/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stakeholder Insight Dashboard</title>
    <link rel="stylesheet" href="../../assets/css/insight_dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <h2>Stakeholder Insight Dashboard</h2>

    <div class="filters">
        <label for="department">Department:</label>
        <select id="department">
            <option value="">All</option>
        </select>

        <label for="rm">Relationship Manager:</label>
        <select id="rm">
            <option value="">All</option>
        </select>

        <label for="startDate">From:</label>
        <input type="date" id="startDate">

        <label for="endDate">To:</label>
        <input type="date" id="endDate">

        <button onclick="loadInsights()">Apply</button>
    </div>

    <div id="insights" class="insight-wrapper">
        <!-- Populated dynamically -->
    </div>

    <div class="chart-container">
    <canvas id="chartTypes"></canvas>
    </div>
    <div class="chart-container">
    <canvas id="chartCategories"></canvas>
    </div>
    <div class="chart-container">
    <canvas id="chartFollowupRate"></canvas>
    </div>

    <script src="../../assets/js/insight_dashboard.js"></script>
</body>
</html>
