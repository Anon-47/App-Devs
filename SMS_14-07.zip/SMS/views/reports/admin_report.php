<?php
require_once '../../includes/session.php'; // if needed
require_once '../../includes/config.php';

// Example: Total users
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

// Example: Total stakeholders
$totalStakeholders = $pdo->query("SELECT COUNT(*) FROM stakeholders")->fetchColumn();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- <script src="../../assets/js/dashboard.js" defer></script> -->
    <script src="../../assets/js/charts_admin_2.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            padding: 20px;
        }
        h2 {
            color: #333;
        }
        .dashboard-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }
        canvas {
            max-width: 100%;
        }
    </style>
</head>
<body>
    <h2>report: Administrator</h2>
    <div class="dashboard-container">
        <div class="card">
            <h3>User Roles</h3>
            <canvas id="userRolesChart"></canvas>
        </div>
        <div class="card">
            <h3>Engagements by Type</h3>
            <canvas id="engagementTypesChart"></canvas>
        </div>
        <div class="card">
            <h3>Most Active Departments</h3>
            <canvas id="activeDepartmentsChart"></canvas>
        </div>
        <div class="card">
            <h3>Database Summary</h3>
            <ul id="dbSummary"></ul>
        </div>
    </div>

    <script>
        fetch('../../api/admin_dashboard_data.php')
            .then(res => res.json())
            .then(data => {
                const userRoles = data.userRoles;
                const userLabels = userRoles.map(r => r.role);
                const userCounts = userRoles.map(r => r.count);

                const ctx1 = document.getElementById('userRolesChart').getContext('2d');
                new Chart(ctx1, {
                    type: 'bar',
                    data: {
                        labels: userLabels,
                        datasets: [{
                            label: 'Users by Role',
                            data: userCounts
                        }]
                    },
                    options: { responsive: true }
                });

                const engagementTypes = data.engagementTypes;
                const engageLabels = engagementTypes.map(e => e.type);
                const engageCounts = engagementTypes.map(e => e.count);

                const ctx2 = document.getElementById('engagementTypesChart').getContext('2d');
                new Chart(ctx2, {
                    type: 'doughnut',
                    data: {
                        labels: engageLabels,
                        datasets: [{
                            label: 'Engagements',
                            data: engageCounts
                        }]
                    },
                    options: { responsive: true }
                });

                const activeDepts = data.activeDepartments;
                const deptLabels = activeDepts.map(d => d.department);
                const deptCounts = activeDepts.map(d => d.engagements);

                const ctx3 = document.getElementById('activeDepartmentsChart').getContext('2d');
                new Chart(ctx3, {
                    type: 'horizontalBar',
                    data: {
                        labels: deptLabels,
                        datasets: [{
                            label: 'Engagements',
                            data: deptCounts
                        }]
                    },
                    options: { responsive: true }
                });

                const summary = data.summary;
                document.getElementById('dbSummary').innerHTML = `
                    <li><strong>Users:</strong> ${summary.users}</li>
                    <li><strong>Stakeholders:</strong> ${summary.stakeholders}</li>
                    <li><strong>Engagements:</strong> ${summary.engagements}</li>
                `;
            })
            .catch(error => console.error('Error loading dashboard data:', error));
    </script>
    <script>
    // Let dashboard.js pick this up after dynamic loading
    window.pageInit = function () {
        if (typeof loadAdminDashboardCharts === 'function') {
            loadAdminDashboardCharts();
        }
    };
    </script>

</body>
</html>
