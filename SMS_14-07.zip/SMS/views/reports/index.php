<?php
include '../../includes/config.php';
?>

<!-- <div id="page-loader" style="position:fixed; top:0; left:0; width:100%; height:100%; background:#fff; z-index:9999; display:flex; justify-content:center; align-items:center;">
    <div class="spinner" style="border:4px solid #ccc; border-top:4px solid #3498db; border-radius:50%; width:40px; height:40px; animation: spin 1s linear infinite;"></div>
</div> -->
<!-- <style>
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style> -->


<!DOCTYPE html>
<html lang="en">
<head>
    <?php include '../../includes/head.php'; ?>
    <title>Reports</title>
    <link rel="stylesheet" href="../assets/css/reports.css">
</head>
<body>
    <!-- Page Loader -->
<!-- <div id="page-loader">
    <div class="spinner"></div>
</div> -->
    
    <div class="main-content">
        <h1>Reports</h1>
        <p>Select from the available reports below:</p>
        <div class="report-list">
            <div class="report-item">
                <h2>Engagement History Report</h2>
                <p>View or export detailed stakeholder engagement history.</p>
                <a href="generate_report.php?type=engagement_history" class="btn btn-primary">Generate</a>
                <a href="../api/export_report.php?type=engagement_history" class="btn btn-secondary">Export</a>
            </div>
            <div class="report-item">
                <h2>Classification Summary Report</h2>
                <p>Analyze stakeholder classifications over time.</p>
                <a href="generate_report.php?type=classification_summary" class="btn btn-primary">Generate</a>
                <a href="../api/export_report.php?type=classification_summary" class="btn btn-secondary">Export</a>
            </div>
            <div class="report-item">
                <h2>Pending Actions Breakdown</h2>
                <p>Breakdown of pending actions by stakeholder or manager.</p>
                <a href="generate_report.php?type=pending_actions" class="btn btn-primary">Generate</a>
                <a href="../api/export_report.php?type=pending_actions" class="btn btn-secondary">Export</a>
            </div>
        </div>
    </div>
</body>
</html>
