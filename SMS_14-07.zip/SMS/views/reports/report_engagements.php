<?php
require_once '../../includes/config.php';
// include '../../includes/sidebar.php';

// Defaults
$start = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$end = $_GET['end_date'] ?? date('Y-m-d');
$type = $_GET['type'] ?? '';
$dept = $_GET['department'] ?? '';

// Fetch engagements
$query = "SELECT * FROM stakeholder_engagements WHERE interaction_date BETWEEN :start AND :end";
$params = [':start' => $start, ':end' => $end];

if ($type) {
    $query .= " AND stakeholder_type = :type";
    $params[':type'] = $type;
}

if ($dept) {
    $query .= " AND department = :dept";
    $params[':dept'] = $dept;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$engagements = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Engagement Reports</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { background: #f2f2f2; font-family: 'Segoe UI', sans-serif; }
        .container { max-width: 95%; margin: 20px auto; background: white; padding: 20px; border-radius: 8px; }
        h2 { margin-bottom: 20px; }
        form.filter-form { margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; }
        form input, form select { padding: 6px; border-radius: 5px; border: 1px solid #ccc; }
        .styled-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .styled-table th, .styled-table td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        .styled-table th { background-color: #222; color: #ffc107; }
        .styled-table tr:nth-child(even) { background-color: #f9f9f9; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Stakeholder Engagement Report</h2>
        <form method="GET" class="filter-form">
            <label>Date Range:
                <input type="date" name="start_date" value="<?= htmlspecialchars($start) ?>"> -
                <input type="date" name="end_date" value="<?= htmlspecialchars($end) ?>">
            </label>
            <label>Department:
                <select name="department">
                    <option value="">All</option>
                    <option value="TSL" <?= $dept == 'TSL' ? 'selected' : '' ?>>TSL</option>
                    <option value="HR" <?= $dept == 'HR' ? 'selected' : '' ?>>HR</option>
                    <option value="Facility" <?= $dept == 'Facility' ? 'selected' : '' ?>>Facility</option>
                    <!-- Add more departments as needed -->
                </select>
            </label>
            <label>Type:
                <select name="type">
                    <option value="">All</option>
                    <option value="Business" <?= $type == 'Business' ? 'selected' : '' ?>>Business</option>
                    <option value="Regulatory" <?= $type == 'Regulatory' ? 'selected' : '' ?>>Regulatory</option>
                    <option value="Vendors" <?= $type == 'Vendors' ? 'selected' : '' ?>>Vendors</option>
                    <option value="Community" <?= $type == 'Community' ? 'selected' : '' ?>>Community</option>
                    <option value="Advocacy Group" <?= $type == 'Advocacy Group' ? 'selected' : '' ?>>Advocacy Group</option>
                </select>
            </label>
            <button type="submit">🔍 Filter</button>
        </form>

        <?php if (count($engagements) > 0): ?>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Department</th>
                        <th>Staff</th>
                        <th>Company</th>
                        <th>Type</th>
                        <th>Category</th>
                        <th>TRACE</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($engagements as $e): ?>
                        <tr>
                            <td><?= htmlspecialchars($e['interaction_date']) ?></td>
                            <td><?= htmlspecialchars($e['department']) ?></td>
                            <td><?= htmlspecialchars($e['staff_full_name']) ?></td>
                            <td><?= htmlspecialchars($e['company']) ?></td>
                            <td><?= htmlspecialchars($e['stakeholder_type']) ?></td>
                            <td><?= htmlspecialchars($e['stakeholder_category']) ?></td>
                            <td><?= htmlspecialchars($e['trace_score']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No engagements found for selected criteria.</p>
        <?php endif; ?>
    </div>
</body>
</html>
