<?php include_once '../../includes/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Monthly Engagement Report</title>
  <link rel="stylesheet" href="../assets/css/dashboard.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
  <style>
    body {
      background-color: #121212;
      color: #f5f5f5;
      font-family: Arial, sans-serif;
      padding: 20px;
    }

    h2 {
      color: #ffa500;
      margin-bottom: 20px;
    }

    .filter-container {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      align-items: center;
      margin-bottom: 30px;
    }

    select, button {
      padding: 8px 14px;
      font-size: 14px;
      border-radius: 6px;
      border: none;
      outline: none;
    }

    select {
      background-color: #1e1e1e;
      color: #fff;
      border: 1px solid #444;
    }

    button {
      background-color: #ffa500;
      color: #000;
      cursor: pointer;
    }

    .chart-container {
      background-color: #1e1e1e;
      padding: 20px;
      border-radius: 12px;
    }

    canvas {
      max-width: 100%;
      height: 400px !important;
    }
  </style>
</head>
<body>

  <h2>Monthly Stakeholder Engagements</h2>

  <div class="filter-container">
    <select id="filterMonth">
      <option value="">Select Month</option>
    </select>

    <select id="filterRM">
      <option value="">All RMs</option>
    </select>

    <select id="filterClassification">
      <option value="">All Classifications</option>
    </select>

    <button id="applyFilters">Generate Report</button>
  </div>

  <div class="chart-container" style="width: 100%; height: 400px;">
    <canvas id="monthlyEngagementChart"></canvas>
  </div>

  <script src="../../assets/js/monthly_report.js"></script>

</body>
</html>
