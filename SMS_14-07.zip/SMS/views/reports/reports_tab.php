<?php require_once '../../includes/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reports Dashboard</title>
  <link rel="stylesheet" href="../../assets/css/reports_tab.css">
</head>
<body>
  <div class="report-container">
    <h2>System Reports Summary</h2>

    <div class="report-metrics">
      <div class="report-card" id="totalStakeholders">Loading...</div>
      <div class="report-card" id="totalEngagements">Loading...</div>
      <div class="report-card" id="totalUsers">Loading...</div>
    </div>

    <div class="report-section">
      <h3>Top Performing Departments</h3>
      <ul id="topDepartments" class="report-list">Loading...</ul>
    </div>

    <div class="report-section">
      <h3>Most Active Relationship Managers</h3>
      <ul id="topRMs" class="report-list">Loading...</ul>
    </div>

    <div class="report-section">
      <h3>Engagements by Type</h3>
      <ul id="engagementTypes" class="report-list">Loading...</ul>
    </div>
  </div>

  <script src="../../assets/js/reports_tab.js"></script>
</body>
</html>
