<?php
include '../../includes/session.php';
require '../../includes/config.php';

// Validate report type
$validReports = ['engagement_history', 'classification_summary', 'pending_actions'];
$type = isset($_GET['type']) && in_array($_GET['type'], $validReports) ? $_GET['type'] : null;

if (!$type) {
    echo "Invalid report type.";
    exit;
}

try {
    // Prepare queries based on report type
    if ($type === 'engagement_history') {
        $query = "SELECT stakeholders.company, engagements.date_of_engagement, engagements.engagement_type, engagements.details 
                  FROM engagements 
                  INNER JOIN stakeholders ON engagements.stakeholder_id = stakeholders.id";
    } elseif ($type === 'classification_summary') {
        $query = "SELECT stakeholders.company, stakeholders.classification, COUNT(*) as total 
                  FROM stakeholders 
                  GROUP BY stakeholders.classification";
    } elseif ($type === 'pending_actions') {
        $query = "SELECT stakeholders.company, actions.type, actions.status 
                  FROM actions 
                  INNER JOIN stakeholders ON actions.stakeholder_id = stakeholders.id
                  WHERE actions.status = 'pending'";
    }

    $stmt = $pdo->query($query);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error generating report: " . $e->getMessage();
    exit;
}

// Export or display the report
if (!empty($data)) {
    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    echo "No data available for this report.";
}
?>
