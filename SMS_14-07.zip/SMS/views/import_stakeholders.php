<?php
require_once '../includes/session.php';
require '../includes/config.php';
?>

<?php if (isset($_GET['status'])): ?>
    <div class="alert <?= $_GET['status'] === 'success' ? 'alert-success' : ($_GET['status'] === 'partial' ? 'alert-warning' : 'alert-danger') ?>">
        <?= $_GET['status'] === 'success' ? 'Stakeholders imported successfully!' : htmlspecialchars($_GET['message']) ?>
    </div>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Import Stakeholders</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .container { max-width: 800px; margin: 30px auto; background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px #ccc; }
        h2 { margin-bottom: 20px; }
        .alert { padding: 10px; border-radius: 5px; margin-bottom: 20px; }
        .alert-success { background-color: #e6ffed; color: #2b662b; }
        .alert-error { background-color: #ffe6e6; color: #a94442; }
        .instructions { background: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        label { display: block; margin-top: 15px; }
        input[type="file"] { margin-top: 5px; }
        button { margin-top: 20px; }
    </style>
</head>
<body>
    
    <div class="container">
        <h2>Import Stakeholders via CSV</h2>

        <!-- Display Session Feedback -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php elseif (isset($_SESSION['error'])): ?>
            <div class="alert alert-error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <!-- Instructions -->
        <div class="instructions">
            <strong>Required CSV Format:</strong>
            <ul>
                <li>Stakeholder Name</li>
                <li>Organization</li>
                <li>Stakeholder Organization Type</li>
                <li>Designation</li>
                <li>Contact of Stakeholder</li>
                <li>Email of Stakeholder</li>
                <li>Location of Stakeholder</li>
                <li>Influence level</li>
                <li>Interest level</li>
                <li>Who is the relationship manager this stakeholder?</li>
            </ul>
            <p>⚠️ Ensure the staff managing the stakeholder already exists in the system with the correct full name.</p>
        </div>

        <!-- Sample CSV -->
        <a href="../assets/sample/stakeholder_template.csv" download class="button">📥 Download Sample CSV</a>

        <!-- Upload Form -->
        <form action="../scripts/process_import.php" method="post" enctype="multipart/form-data">
            <label for="csv_file">Select CSV File to Import:</label>
            <input type="file" name="csv_file" accept=".csv" required>
            <button type="submit" class="btn">Upload and Import</button>
        </form>
    </div>
</body>
</html>
