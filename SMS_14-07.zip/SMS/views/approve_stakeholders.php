<!-- views/approve_stakeholders.php -->
<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'manager') {
    header('Location: index.php'); // Restrict access to managers
    exit();
}

require '../includes/config.php'; // Database connection

// Fetch pending stakeholders
try {
    $stmt = $pdo->query("SELECT * FROM stakeholders WHERE status = 'pending'");
    $pendingStakeholders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>

    <h1>Pending Stakeholders for Approval</h1>

    <?php if (count($pendingStakeholders) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Rating</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pendingStakeholders as $stakeholder): ?>
                <tr>
                    <td><?php echo htmlspecialchars($stakeholder['name']); ?></td>
                    <td><?php echo htmlspecialchars($stakeholder['type']); ?></td>
                    <td><?php echo htmlspecialchars($stakeholder['rating']); ?></td>
                    <td>
                        <a href="../scripts/approve_stakeholder.php?id=<?php echo $stakeholder['id']; ?>">Approve</a> |
                        <a href="../scripts/reject_stakeholder.php?id=<?php echo $stakeholder['id']; ?>">Reject</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No pending stakeholders to approve.</p>
    <?php endif; ?>
