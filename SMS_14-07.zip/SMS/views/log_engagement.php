<!-- log_engagement.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Stakeholder Engagement</title>
    <link rel="stylesheet" href="../assets/css/forms.css">
    <script src="../assets/js/form_validation.js"></script>
</head>
<body>

<form action="../scripts/log_engagements.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="stakeholder_id" value="<!-- Insert Stakeholder ID here -->">

    <label for="department">Department:</label>
    <input type="text" id="department" name="department" required>

    <label for="staff_first_name">Your First Name:</label>
    <input type="text" id="staff_first_name" name="staff_first_name" required>

    <label for="staff_last_name">Your Last Name:</label>
    <input type="text" id="staff_last_name" name="staff_last_name" required>

    <label for="interaction_date">Date of Interaction:</label>
    <input type="date" id="interaction_date" name="interaction_date" required>

    <label for="stakeholder_type">Type of Stakeholder:</label>
    <input type="text" id="stakeholder_type" name="stakeholder_type" required>

    <label for="stakeholder_category">Category of Stakeholder:</label>
    <input type="text" id="stakeholder_category" name="stakeholder_category" required>

    <label for="stakeholder_name">Stakeholder Full Name:</label>
    <input type="text" id="stakeholder_name" name="stakeholder_name" required>

    <label for="in_db">Is the stakeholder in your department's DB?</label>
    <select id="in_db" name="in_db">
        <option value="Yes">Yes</option>
        <option value="No">No</option>
    </select>

    <label for="interaction_nature">Nature of Interaction:</label>
    <textarea id="interaction_nature" name="interaction_nature"></textarea>

    <label for="action_notes">Actions or Notes:</label>
    <textarea id="action_notes" name="action_notes"></textarea>

    <label for="trace_score">TRACE Score (1-5):</label>
    <input type="number" id="trace_score" name="trace_score" min="1" max="5" required>

    <!-- Attachment Field -->
    <label for="attachment">Attach File (PDF, DOCX, JPG, PNG):</label>
    <input type="file" name="attachment" id="attachment" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">

    <button type="submit">Submit Engagement</button>
</form>
