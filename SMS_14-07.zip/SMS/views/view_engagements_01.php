<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stakeholder Engagements</title>
    <link rel="stylesheet" href="../assets/css/view_engagements.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f6fa;
            margin: 0;
            padding: 20px;
        }
        .view-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        h2 {
            color: #2c3e50;
            margin-bottom: 20px;
        }
        .filters {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 20px;
        }
        .filters label {
            display: flex;
            flex-direction: column;
            font-weight: bold;
            color: #34495e;
        }
        .filters input,
        .filters select {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        table.data-table {
            width: 100%;
            border-collapse: collapse;
        }
        table.data-table th,
        table.data-table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        table.data-table th {
            background-color: #ecf0f1;
            color: #2c3e50;
        }
        table.data-table tbody tr:hover {
            background-color: #f0f8ff;
        }
    </style>
    <script>
        async function fetchEngagements() {
            const type = document.getElementById('filterType').value;
            const dept = document.getElementById('filterDept').value;
            const dateFrom = document.getElementById('filterFrom').value;
            const dateTo = document.getElementById('filterTo').value;

            const url = `../api/fetch_engagements.php?type=${encodeURIComponent(type)}&department=${encodeURIComponent(dept)}&date_from=${encodeURIComponent(dateFrom)}&date_to=${encodeURIComponent(dateTo)}`;

            try {
                const response = await fetch(url);
                const data = await response.json();

                const tableBody = document.querySelector("#engagementTable tbody");
                tableBody.innerHTML = '';

                if (data.success) {
                    data.data.forEach(row => {
                        const tr = document.createElement('tr');
                        tr.innerHTML = `
                            <td>${row.department}</td>
                            <td>${row.tsl_contact}</td>
                            <td>${row.interaction_date}</td>
                            <td>${row.client_company}</td>
                            <td>${row.type}</td>
                            <td>${row.category}</td>
                            <td>${row.stakeholder_name}</td>
                            <td>${row.nature_of_interaction}</td>
                            <td>${row.action_notes}</td>
                            <td>${row.trace_score}</td>
                        `;
                        tableBody.appendChild(tr);
                    });
                } else {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `<td colspan="10">No records found.</td>`;
                    tableBody.appendChild(tr);
                }
            } catch (error) {
                console.error("Error fetching engagements:", error);
            }
        }

        document.addEventListener('DOMContentLoaded', fetchEngagements);
        function exportFilteredEngagements() {
        const type = document.getElementById('filterType').value;
        const dept = document.getElementById('filterDept').value;
        const dateFrom = document.getElementById('filterFrom').value;
        const dateTo = document.getElementById('filterTo').value;

        const url = `../api/fetch_engagements.php?type=${type}&department=${dept}&date_from=${dateFrom}&date_to=${dateTo}&export=csv`;

        fetch(url)
            .then(response => {
                if (!response.ok) throw new Error("Network error");
                return response.blob();
            })
            .then(blob => {
                const link = document.createElement("a");
                link.href = URL.createObjectURL(blob);
                link.download = "filtered_engagements.csv";
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            })
            .catch(err => alert("Export failed: " + err));
        }

    </script>
</head>
<body>
    <div class="view-container">
        <h2>Stakeholder Engagements</h2>

        <div class="filters">
            <label>Type:
                <select id="filterType" onchange="fetchEngagements()">
                    <option value="">-- All --</option>
                    <option value="Consultation">Consultation</option>
                    <option value="Meeting">Meeting</option>
                    <option value="Follow-up">Follow-up</option>
                    <option value="Other">Other</option>
                </select>
            </label>

            <label>Department:
                <input type="text" id="filterDept" placeholder="Enter department" onkeyup="fetchEngagements()">
            </label>

            <label>Date From:
                <input type="date" id="filterFrom" onchange="fetchEngagements()">
            </label>

            <label>Date To:
                <input type="date" id="filterTo" onchange="fetchEngagements()">
            </label>
        </div>
        <button onclick="exportFilteredEngagements()">📤 Export Filtered</button>


        <table id="engagementTable" class="data-table">
            <thead>
                <tr>
                    <th>Department</th>
                    <th>TSL Contact</th>
                    <th>Interaction Date</th>
                    <th>Client</th>
                    <th>Type</th>
                    <th>Category</th>
                    <th>Stakeholder</th>
                    <th>Nature</th>
                    <th>Action Notes</th>
                    <th>TRACE Score</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</body>
</html>
