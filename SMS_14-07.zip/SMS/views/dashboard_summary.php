<?php require_once '../includes/session.php'; ?>
<div class="dashboard-cards" id="dashboard-container">
    <h2 style="margin-bottom: 20px;">Stakeholder Dashboard</h2>

    <!-- Top 4 Summary Cards -->
    <div class="metrics-row">
        <div class="metric-card orange"><h4>Total Stakeholders</h4><span id="total-stakeholders">...</span></div>
        <div class="metric-card gold"><h4>Engagements Logged</h4><span id="total-engagements">...</span></div>
        <div class="metric-card amber"><h4>Avg. TRACE Score</h4><span id="avg-trace">...</span></div>
        <div class="metric-card bronze"><h4>Follow-up Rate</h4><span id="follow-rate">...</span>%</div>
    </div>

    <!-- Stakeholders by Type -->
    <h3>Stakeholders by Type</h3>
    <div class="metrics-row" id="type-cards"></div>

    <!-- Stakeholders by Category -->
    <h3 style="margin-top: 30px;">Stakeholders by Category</h3>
    <div class="metrics-row" id="category-cards"></div>
</div>

<style>
    .metrics-row {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        margin-bottom: 30px;
    }
    .metric-card {
        flex: 1 1 200px;
        padding: 20px;
        border-radius: 10px;
        color: white;
        font-weight: bold;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    }

    .orange   { background: linear-gradient(to right, #ec8424, #da8a1d); }
    .gold     { background: linear-gradient(to right, #f6c542, #dfb239); }
    .amber    { background: linear-gradient(to right, #f9b248, #ec8424); }
    .bronze   { background: linear-gradient(to right, #a65e2e, #dfb239); }

    .mustard  { background: linear-gradient(to right, #f5d442, #ecb100); }
    .tan      { background: linear-gradient(to right, #dcae80, #c48a3c); }
    .burgundy { background: linear-gradient(to right, #9c1c2c, #a73737); }
    .grey     { background: linear-gradient(to right, #aaa, #ccc); }
    .brown    { background: linear-gradient(to right, #835C3B, #B08858); }

    .metric-card h4 {
        font-size: 16px;
        margin-bottom: 5px;
    }
    .metric-card span {
        font-size: 26px;
        display: block;
    }
</style>

<script>
    fetch('../api/dashboard_metrics.php')
        .then(res => res.json())
        .then(data => {
            // Top stats
            document.getElementById('total-stakeholders').textContent = data.total_stakeholders;
            document.getElementById('total-engagements').textContent = data.total_engagements;
            document.getElementById('avg-trace').textContent = data.avg_trace_score;
            document.getElementById('follow-rate').textContent = data.follow_up_rate;

            const colorClasses = ['tan', 'mustard', 'burgundy', 'brown', 'grey'];

            // Stakeholder Types
            const typeDiv = document.getElementById('type-cards');
            data.types.forEach((item, index) => {
                const card = document.createElement('div');
                card.className = `metric-card ${colorClasses[index % colorClasses.length]}`;
                card.innerHTML = `<h4>${item.label}</h4><span>${item.count}</span>`;
                typeDiv.appendChild(card);
            });

            // Stakeholder Categories
            const catDiv = document.getElementById('category-cards');
            data.categories.forEach((item, index) => {
                const card = document.createElement('div');
                card.className = `metric-card ${colorClasses[(index + 2) % colorClasses.length]}`;
                card.innerHTML = `<h4>${item.label}</h4><span>${item.count}</span>`;
                catDiv.appendChild(card);
            });
        });
</script>
