<?php
require_once '../includes/session.php';
require '../includes/config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Import Stakeholder Engagements</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    body {
      background-color: #f9f9f9;
      font-family: Arial, sans-serif;
    }

    .container {
      max-width: 800px;
      margin: 40px auto;
      background: #fff;
      padding: 35px;
      border-radius: 12px;
      box-shadow: 0 0 12px rgba(0, 0, 0, 0.08);
    }

    h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #333;
    }

    .alert {
      padding: 12px 20px;
      border-radius: 6px;
      margin-bottom: 20px;
      font-size: 14px;
    }

    .alert-success {
      background-color: #e6ffed;
      color: #2b662b;
    }

    .alert-error {
      background-color: #ffe6e6;
      color: #a94442;
    }

    .instructions {
      background: #f4f4f4;
      padding: 18px;
      border-radius: 8px;
      margin-bottom: 20px;
    }

    .instructions strong {
      color: #444;
      font-size: 16px;
    }

    .instructions ul {
      padding-left: 18px;
      margin-top: 10px;
      line-height: 1.7;
    }

    .instructions li {
      font-size: 14px;
      color: #555;
    }

    .instructions p {
      margin-top: 12px;
      font-size: 13px;
      color: #a94442;
      font-style: italic;
    }

    a.button {
      display: inline-block;
      margin: 15px 0;
      padding: 10px 15px;
      background-color: #d17406;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-size: 14px;
      transition: background 0.3s;
    }

    a.button:hover {
      background-color: #b55d05;
    }

    form {
      margin-top: 20px;
    }

    label {
      display: block;
      font-weight: bold;
      margin-top: 15px;
    }

    input[type="file"] {
      margin-top: 5px;
      padding: 8px;
      width: 100%;
      border: 1px solid #ccc;
      border-radius: 6px;
    }

    button.btn {
      margin-top: 20px;
      background-color: #2f2f2f;
      color: white;
      border: none;
      padding: 10px 20px;
      font-size: 15px;
      border-radius: 6px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    button.btn:hover {
      background-color: #1a1a1a;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Import Stakeholder Engagements</h2>

    <!-- Session Feedback -->
    <?php if (isset($_SESSION['success'])): ?>
      <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php elseif (isset($_SESSION['error'])): ?>
      <div class="alert alert-error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <!-- Updated Instructions -->
    <div class="instructions">
      <strong>Upload Format (CSV columns must follow this order):</strong>
      <ul>
        <li>Department</li>
        <li>Staff Full Name</li>
        <li>Date of Interaction</li>
        <li>Client</li>
        <li>Type of Stakeholder</li>
        <li>Category of Stakeholder</li>
        <li>Stakeholder Full Name</li>
        <li>Is in Contact DB (Yes/No)</li>
        <li>Nature of Interaction</li>
        <li>Additional Details</li>
        <li>Action Notes</li>
        <li>Trace Score</li>
      </ul>
      <p>⚠️ The "Staff Full Name" must match a user’s full name in the system to associate a Relationship Manager.</p>
    </div>

    <!-- Sample Template Download -->
    <a href="../assets/sample/engagement_template.csv" download class="button">📥 Download CSV Template</a>

    <!-- Upload Form -->
    <form action="../scripts/process_engagement_import.php" method="post" enctype="multipart/form-data">
      <label for="csv_file">Select CSV File:</label>
      <input type="file" name="csv_file" accept=".csv" required>
      <button type="submit" class="btn">Upload and Import</button>
    </form>
  </div>
  <?php if (isset($_SESSION['import_summary'])): ?>
<script>
    window.onload = () => {
        const summary = <?= json_encode($_SESSION['import_summary']); ?>;
        let message = `${summary.imported} imported successfully. ${summary.skipped} skipped.`;

        alert(message); // simple feedback popup

        if (summary.unmatched.length > 0) {
            const container = document.createElement('div');
            container.innerHTML = `<h3>⚠️ Unmatched Stakeholders</h3><ul>${summary.unmatched.map(name => `<li>${name}</li>`).join('')}</ul>`;
            container.style.background = '#fff3cd';
            container.style.border = '1px solid #ffeeba';
            container.style.padding = '20px';
            container.style.marginTop = '20px';
            container.style.borderRadius = '8px';
            container.style.color = '#856404';
            document.body.querySelector('.container').appendChild(container);
        }
    }
</script>
<?php unset($_SESSION['import_summary']); endif; ?>

</body>
</html>
