<?php
// Fetch stakeholder data
require_once '../includes/config.php';

$stakeholder_id = $_GET['id'] ?? null;

if (!$stakeholder_id) {
    echo "Invalid stakeholder ID.";
    exit;
}

$stmt = $pdo->prepare("SELECT s.*, u.email as manager_email FROM stakeholders s LEFT JOIN users u ON s.relationship_manager = u.id WHERE s.id = ?");
$stmt->execute([$stakeholder_id]);
$stakeholder = $stmt->fetch();

if (!$stakeholder) {
    echo "Stakeholder not found.";
    exit;
}

$profileImage = !empty($stakeholder['profile_image']) && file_exists("../uploads/" . $stakeholder['profile_image'])
    ? "../uploads/" . $stakeholder['profile_image']
    : "../assets/images/blank-profile.png";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Stakeholder Profile</title>
    <link rel="stylesheet" href="../assets/css/stakeholder_profile.css">
    <style>
        .upload-form {
            margin-top: 10px;
            text-align: center;
        }
        .upload-form input[type="file"] {
            margin: 5px 0;
        }
        .upload-form button {
            padding: 5px 10px;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <!-- Header section -->
        <div class="profile-header">
            <div class="image-container">
                <img src="<?= $stakeholder['profile_image'] ? '../uploads/' . $stakeholder['profile_image'] : '../assets/images/blank-profile.png' ?>" 
                    alt="Stakeholder Image" 
                    class="profile-pic" 
                    id="avatarImage">

                <form id="uploadForm" action="../scripts/upload_profile_image.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="stakeholder_id" value="<?= $stakeholder_id ?>">
                    <label for="profileImageInput" class="edit-icon">&#9998;</label>
                    <input type="file" id="profileImageInput" name="profile_image" accept="image/*" style="display: none;">
                </form>
            </div>

            <h2><?= htmlspecialchars($stakeholder['s_name']) ?></h2>
            <p><?= htmlspecialchars($stakeholder['designation']) ?> @ <?= htmlspecialchars($stakeholder['organization']) ?></p>

            <!-- Profile Picture Upload -->
            <form class="upload-form" action="../scripts/upload_profile_image.php" method="POST" enctype="multipart/form-data">
                <input type="file" name="profile_image" accept="image/*" required>
                <input type="hidden" name="stakeholder_id" value="<?= $stakeholder_id ?>">
                <button type="submit">Upload Image</button>
            </form>
        </div>

        <!-- Info Cards -->
        <div class="card-grid">
            <div class="info-card"><h3>Email</h3><p><?= htmlspecialchars($stakeholder['email']) ?></p></div>
            <div class="info-card"><h3>Contact</h3><p><?= htmlspecialchars($stakeholder['contact']) ?></p></div>
            <div class="info-card"><h3>Organization Type</h3><p><?= htmlspecialchars($stakeholder['organization_type']) ?></p></div>
            <div class="info-card"><h3>Location</h3><p><?= htmlspecialchars($stakeholder['location']) ?></p></div>
            <div class="info-card"><h3>Influence Level</h3><p><?= htmlspecialchars($stakeholder['influence_level']) ?></p></div>
            <div class="info-card"><h3>Interest Level</h3><p><?= htmlspecialchars($stakeholder['interest_level']) ?></p></div>
            <div class="info-card"><h3>Relationship Manager</h3><p><?= htmlspecialchars($stakeholder['manager_email']) ?></p></div>
        </div>

        <!-- Engagement Activity Log -->
        <div class="activity-section">
            <h3>Engagement Activity</h3>
            <div class="activity-log" id="engagement-log">
                <!-- Logs will be loaded via JS -->
            </div>
        </div>
    </div>

    <script>
        const stakeholderId = <?= json_encode($stakeholder_id) ?>;

        fetch(`../api/engagements.php?stakeholder_id=${stakeholderId}`)
            .then(res => res.json())
            .then(data => {
                const container = document.getElementById('engagement-log');
                if (data.length === 0) {
                    container.innerHTML = "<p>No engagement records yet.</p>";
                } else {
                    data.forEach(item => {
                        const logItem = document.createElement('div');
                        logItem.classList.add('log-entry');
                        logItem.innerHTML = `
                            <strong>${item.date_of_interaction}</strong> - 
                            ${item.nature_of_interaction} <br>
                            <em>By ${item.tsl_contact_staff}</em>
                            <p>${item.additional_notes || ''}</p>
                        `;
                        container.appendChild(logItem);
                    });
                }
            })
            .catch(err => {
                document.getElementById('engagement-log').innerHTML = "<p>No engagements yet.</p>";
            });
    </script>
    <script>
    document.getElementById('profileImageInput').addEventListener('change', function () {
        if (this.files.length > 0) {
            document.getElementById('uploadForm').submit();
        }
    });
    </script>

</body>
</html>
