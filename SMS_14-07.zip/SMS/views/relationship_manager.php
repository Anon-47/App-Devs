<?php
// File path: views/relationship_manager.php

require_once '../includes/config.php';

echo "<h1>Relationship Managers</h1>";
echo "<p>Use the search bar to filter Relationship Managers by name or email.</p>";

// Search input for filtering
echo "<input type='text' id='searchInput' placeholder='Search by name or email' onkeyup='filterRMs()'>";

try {
    // Fetch all users with the "Manager" role
    $query = "SELECT id, full_name, email FROM users WHERE role = 'Manager'";
    $stmt = $pdo->prepare($query);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "<table id='rmTable'>";
        echo "<thead>";
        echo "<tr>
                <th>Full Name</th>
                <th>Email</th>
                <th>View Stakeholders</th>
              </tr>";
        echo "</thead>";
        echo "<tbody>";

        // Display each RM with a link to view their stakeholders
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['full_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['email']) . "</td>";
            echo "<td><a href='relationship_manager_stakeholders.php?rm_id=" . $row['id'] . "'>View Stakeholders</a></td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>No relationship managers found.</p>";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!-- JavaScript for filtering -->
<script>
function filterRMs() {
    const input = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#rmTable tbody tr');

    rows.forEach(row => {
        const name = row.cells[0].textContent.toLowerCase();
        const email = row.cells[1].textContent.toLowerCase();

        if (name.includes(input) || email.includes(input)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>

<!-- CSS Styling -->
<style>
    /* Center the title and search bar */
    h1 {
        text-align: center;
        color: #333;
        font-family: Arial, sans-serif;
    }
    p {
        text-align: center;
        color: #666;
    }
    #searchInput {
        width: 60%;
        padding: 10px;
        margin: 15px auto;
        display: block;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 1em;
    }
    #rmTable {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
    }
    #rmTable thead th {
        background-color: #4CAF50;
        color: white;
        padding: 10px;
        text-align: left;
    }
    #rmTable tbody tr {
        border-bottom: 1px solid #ddd;
    }
    #rmTable tbody tr:hover {
        background-color: #f1f1f1;
    }
    #rmTable tbody td {
        padding: 10px;
        font-family: Arial, sans-serif;
    }
    #rmTable tbody td a {
        color: #4CAF50;
        text-decoration: none;
        font-weight: bold;
    }
    #rmTable tbody td a:hover {
        text-decoration: underline;
    }
</style>
