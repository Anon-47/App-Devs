<?php
// File path: views/relationship_manager_stakeholders.php

require_once '../includes/config.php';

if (!isset($_GET['rm_id'])) {
    echo "No Relationship Manager selected.";
    exit;
}

$rm_id = intval($_GET['rm_id']); // Get the RM ID from the URL parameter

try {
    // Fetch the RM's information
    $query = "SELECT full_name, email FROM users WHERE id = :rm_id AND role = 'Manager'";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':rm_id', $rm_id, PDO::PARAM_INT);
    $stmt->execute();
    $rm = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$rm) {
        echo "<p>Relationship Manager not found.</p>";
        exit;
    }

    echo "<h2>Stakeholders Managed by " . htmlspecialchars($rm['full_name']) . "</h2>";
    echo "<p>Email: " . htmlspecialchars($rm['email']) . "</p>";

    // Fetch stakeholders assigned to this RM
    $query = "SELECT company, last_engagement, engagement_type, classification, rating
              FROM stakeholders
              WHERE relationship_manager_id = :rm_id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':rm_id', $rm_id, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "<table>";
        echo "<thead>";
        echo "<tr>
                <th>Company</th>
                <th>Last Engagement</th>
                <th>Engagement Type</th>
                <th>Classification</th>
                <th>Rating</th>
              </tr>";
        echo "</thead>";
        echo "<tbody>";

        // Loop through each stakeholder and display their info
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['company']) . "</td>";
            echo "<td>" . htmlspecialchars($row['last_engagement']) . "</td>";
            echo "<td>" . htmlspecialchars($row['engagement_type']) . "</td>";
            echo "<td>" . htmlspecialchars($row['classification']) . "</td>";
            echo "<td>" . htmlspecialchars($row['rating']) . "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>No stakeholders assigned to " . htmlspecialchars($rm['full_name']) . ".</p>";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
