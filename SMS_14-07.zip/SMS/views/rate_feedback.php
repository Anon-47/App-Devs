<!-- rate_feedback.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate and Feedback</title>
    <link rel="stylesheet" href="../public/css/forms.css">
    <script src="../public/js/form_validation.js"></script>
</head>
<body>

<div class="form-container">
    <h2>Rate and Provide Feedback</h2>
    <form action="../scripts/process_rating.php" method="POST" id="ratingForm">
        <!-- Stakeholder Name -->
        <label for="stakeholderName">Stakeholder Name*</label>
        <select name="stakeholderName" id="stakeholderName" required>
            <option value="">Select Stakeholder</option>
            <!-- Populate options dynamically with stakeholders -->
            <option value="stakeholder1">Stakeholder 1</option>
            <option value="stakeholder2">Stakeholder 2</option>
        </select>

        <!-- Engagement Rating -->
        <label for="engagementRating">Engagement Rating*</label>
        <select name="engagementRating" id="engagementRating" required>
            <option value="">Select Rating</option>
            <option value="excellent">Excellent</option>
            <option value="good">Good</option>
            <option value="average">Average</option>
            <option value="poor">Poor</option>
        </select>

        <!-- Feedback -->
        <label for="feedback">Feedback</label>
        <textarea name="feedback" id="feedback" rows="4" placeholder="Provide detailed feedback..."></textarea>

        <!-- Date of Engagement -->
        <label for="engagementDate">Date of Engagement</label>
        <input type="date" name="engagementDate" id="engagementDate" required>

        <!-- Submit Button -->
        <button type="submit">Submit Feedback</button>
    </form>
</div>

</body>
</html>
