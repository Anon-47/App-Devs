<!-- shell.php -->
<?php include '../includes/session.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        body { margin: 0; font-family: sans-serif; }
        .sidebar { width: 200px; background: #2f2f2f; color: white; height: 100vh; float: left; padding: 10px; }
        .content { margin-left: 200px; padding: 20px; min-height: 100vh; background: #f4f4f4; }
        .menu a { color: white; display: block; margin: 10px 0; text-decoration: none; }
        iframe { width: 100%; height: 90vh; border: none; }
    </style>
    <script>
        function loadPage(page) {
            document.getElementById("main-frame").src = page;
        }
    </script>
</head>
<body>

<div class="sidebar">
    <h3>Welcome, <?= $_SESSION['username']; ?></h3>
    <div class="menu">
        <a href="javascript:void(0);" onclick="loadPage('../views/stakeholders.php')">Stakeholders</a>
        <a href="javascript:void(0);" onclick="loadPage('../views/engagements.php')">Engagements</a>
        <a href="javascript:void(0);" onclick="loadPage('../reports/stakeholder_report.php')">Reports</a>
        <a href="../logout.php">Logout</a>
    </div>
</div>

<div class="content">
    <iframe id="main-frame" src="../views/stakeholders.php"></iframe>
</div>

</body>
</html>
