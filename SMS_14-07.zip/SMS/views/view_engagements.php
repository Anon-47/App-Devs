<?php
require_once '../includes/session.php';
require_once '../includes/config.php';

$typeFilter = $_GET['type'] ?? '';
$deptFilter = $_GET['department'] ?? '';
$fromDate = $_GET['from'] ?? '';
$toDate = $_GET['to'] ?? '';

// Build SQL with optional filters
$sql = "SELECT * FROM stakeholder_engagements WHERE 1=1";
$params = [];

if (!empty($typeFilter)) {
    $sql .= " AND stakeholder_type = ?";
    $params[] = $typeFilter;
}
if (!empty($deptFilter)) {
    $sql .= " AND department LIKE ?";
    $params[] = "%$deptFilter%";
}
if (!empty($fromDate)) {
    $sql .= " AND interaction_date >= ?";
    $params[] = $fromDate;
}
if (!empty($toDate)) {
    $sql .= " AND interaction_date <= ?";
    $params[] = $toDate;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$engagements = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Engagements</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .filter-bar { margin: 20px 0; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .filter-bar input, .filter-bar select { padding: 8px; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; }
        th { background-color: #222; color: orange; }
    </style>
</head>
<body>
<div class="container">
    <h2>Stakeholder Engagements</h2>

    <form class="filter-bar" method="get">
        <select name="type">
            <option value="">-- All --</option>
            <option value="Partner" <?= $typeFilter == 'Partner' ? 'selected' : '' ?>>Partner</option>
            <option value="Business Clients" <?= $typeFilter == 'Business Clients' ? 'selected' : '' ?>>Business Clients</option>
            <option value="Vendors/Partners" <?= $typeFilter == 'Vendors/Partners' ? 'selected' : '' ?>>Vendors/Partners</option>
        </select>
        <input type="text" name="department" placeholder="Enter department" value="<?= htmlspecialchars($deptFilter) ?>">
        <input type="date" name="from" value="<?= htmlspecialchars($fromDate) ?>">
        <input type="date" name="to" value="<?= htmlspecialchars($toDate) ?>">
        <button type="submit">🔍 Filter</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Department</th>
                <th>TSL Contact</th>
                <th>Interaction Date</th>
                <th>Client</th>
                <th>Type</th>
                <th>Category</th>
                <th>Stakeholder</th>
                <th>Nature</th>
                <th>Action Notes</th>
                <th>TRACE Score</th>
            </tr>
        </thead>
        <tbody>
        <?php if (count($engagements) > 0): ?>
            <?php foreach ($engagements as $row): ?>
                <tr>
                    <td><?= htmlspecialchars($row['department']) ?></td>
                    <td><?= htmlspecialchars($row['staff_full_name']) ?></td>
                    <td><?= htmlspecialchars($row['interaction_date']) ?></td>
                    <td><?= htmlspecialchars($row['company']) ?></td>
                    <td><?= htmlspecialchars($row['stakeholder_type']) ?></td>
                    <td><?= htmlspecialchars($row['stakeholder_category']) ?></td>
                    <td><?= htmlspecialchars($row['stakeholder_fullname']) ?></td>
                    <td><?= htmlspecialchars($row['interaction_nature']) ?></td>
                    <td><?= htmlspecialchars($row['follow_up_action']) ?></td>
                    <td><?= htmlspecialchars($row['trace_score']) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="10">No engagements found for the selected filters.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
