<?php
require '../includes/config.php';

if (!isset($_GET['id'])) {
    echo "No stakeholder selected.";
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM stakeholders WHERE id = ?");
$stmt->execute([$id]);
$stakeholder = $stmt->fetch();

if (!$stakeholder) {
    echo "Stakeholder not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Retire Stakeholder</title>
    <link rel="stylesheet" href="../assets/css/forms.css">
    <style>
        body {
            background-color: #0f141e;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .confirm-box {
            background-color: #1e2a3a;
            color: #fff;
            width: 400px;
            margin: 100px auto;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
        }
        h2 {
            color: orange;
            margin-bottom: 20px;
        }
        .highlight {
            color: orange;
            font-weight: bold;
        }
        .btn {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            margin: 10px;
            cursor: pointer;
        }
        .btn-danger {
            background-color: #dc3545;
            color: #fff;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
        }
    </style>
</head>
<body>

<div class="confirm-box">
    <h2>Confirm Retirement</h2>
    <p><span class="highlight">Name:</span> <?= htmlspecialchars($stakeholder['s_name']) ?></p>
    <p><span class="highlight">Organization:</span> <?= htmlspecialchars($stakeholder['organization']) ?></p>
    <p><span class="highlight">Designation:</span> <?= htmlspecialchars($stakeholder['designation']) ?></p>

    <p>Are you sure you want to retire this stakeholder?</p>

    <form action="../scripts/process_retirement.php" method="POST">
        <input type="hidden" name="id" value="<?= $stakeholder['id'] ?>">
        <button type="submit" class="btn btn-danger">Yes, Retire</button>
        <a href="javascript:history.back()" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>
