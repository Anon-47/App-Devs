<?php
// Path: /views/my_profile.php

require_once '../includes/session.php';
require_once '../includes/config.php';  // Database connection file

// Fetch user data
$userId = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Count stakeholders assigned to the user (relationship manager)
$stakeholderCountQuery = "SELECT COUNT(*) AS total FROM stakeholders WHERE relationship_manager = ?";
$stmt2 = $pdo->prepare($stakeholderCountQuery);
$stmt2->execute([$userId]);
$stakeholderCount = $stmt2->fetchColumn();

?>

<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <link rel="stylesheet" href="../assets/css/profile.css">
</head>
<body>
    <div class="profile-container">
        <h2 class="profile-title">User Account: Profile</h2>
        
        <!-- Display user info -->
        <div class="profile-card profile-info">
            <p><strong>Full Name:</strong> <span class="user-info"><?php echo htmlspecialchars($user['full_name']); ?></span></p>
            <p><strong>Username:</strong> <span class="user-info"><?php echo htmlspecialchars($user['username']); ?></span></p>
            <p><strong>Email:</strong> <span class="user-info"><?php echo htmlspecialchars($user['email']); ?></span></p>
            <p><strong>Assigned Stakeholders:</strong> <span class="user-info"><?php echo $stakeholderCount; ?></span></p>
        </div>
        
        <!-- Edit Form -->
        <h3 class="form-title">Update Account Information</h3>
        <form action="../scripts/update_profile.php" method="POST" class="profile-form">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" required class="form-input">
            
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required class="form-input">
            
            <label for="password">New Password:</label>
            <input type="password" name="password" id="password" placeholder="Leave blank if not changing" class="form-input">

            <button type="submit" class="form-button">Update Profile</button>
        </form>
    </div>
</body>
