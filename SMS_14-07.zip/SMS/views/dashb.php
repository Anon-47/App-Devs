<?php
require '../includes/config.php';
require_once '../includes/session.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Fetch Newest 5 Stakeholders
$newest = $pdo->query("SELECT s_name, created_at FROM stakeholders ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Fetch Oldest 5 Stakeholders
$oldest = $pdo->query("SELECT s_name, created_at FROM stakeholders ORDER BY created_at ASC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Fetch Top 5 Relationship Managers
try {
    $stmt = $pdo->prepare("
        SELECT u.full_name, u.email, COUNT(s.id) AS stakeholder_count
        FROM stakeholders s
        JOIN users u ON s.relationship_manager = u.id
        GROUP BY s.relationship_manager
        ORDER BY stakeholder_count DESC
        LIMIT 5
    ");
    $stmt->execute();
    $topManagers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $topManagers = []; // Fallback to empty array if query fails
    error_log("Error fetching top managers: " . $e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="en">
<?php
require '../includes/config.php';

// Count pending actions by status
try {
    $stmt = $pdo->query("
        SELECT status, COUNT(*) as count 
        FROM stakeholders 
        WHERE status IN ('pending_approval', 'pending_review', 'pending_update', 'pending_retirement') 
        GROUP BY status
    ");
    $statusCounts = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $statusCounts[$row['status']] = (int)$row['count'];
    }

    // Default zero if a status is missing
    $pendingApproval = $statusCounts['pending_approval'] ?? 0;
    $pendingReview = $statusCounts['pending_review'] ?? 0;
    $pendingUpdate = $statusCounts['pending_update'] ?? 0;
    $pendingRetirement = $statusCounts['pending_retirement'] ?? 0;

} catch (PDOException $e) {
    echo "Error loading pending actions: " . $e->getMessage();
}
?>

<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dashb.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <main class="main-content">
            <h1>SMS: Central</h1>
            <div class="widgets">
                
                <!-- Newest 5 Stakeholders -->
                <div class="widget" id="newest-stakeholders">
                    <h2>Newest 5 Stakeholders</h2>
                    <table>
                        <thead><tr><th>Name</th><th>Date Joined</th></tr></thead>
                        <tbody>
                            <?php foreach ($newest as $row): ?>
                                <tr><td><?= htmlspecialchars($row['s_name']) ?></td><td><?= htmlspecialchars($row['created_at']) ?></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Top 5 Relationship Managers -->
                <div class="widget" id="top-managers">
                    <h2>Top 5 Relationship Managers</h2>
                    <table>
                        <thead>
                            <tr><th>Manager</th><th>Email</th><th>Stakeholders Managed</th></tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($topManagers)): ?>
                                <?php foreach ($topManagers as $manager): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($manager['full_name']) ?></td>
                                        <td><?= htmlspecialchars($manager['email']) ?></td>
                                        <td><?= $manager['stakeholder_count'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="3">No data available.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>


                <!-- Oldest Stakeholders -->
                <div class="widget" id="oldest-stakeholders">
                    <h2>Oldest Stakeholders</h2>
                    <table>
                        <thead><tr><th>Name</th><th>Date Joined</th></tr></thead>
                        <tbody>
                            <?php foreach ($oldest as $row): ?>
                                <tr><td><?= htmlspecialchars($row['s_name']) ?></td><td><?= htmlspecialchars($row['created_at']) ?></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pending Actions (Static or future dynamic) -->
                <div class="widget chart-widget" id="pending-actions">
                    <h2>Pending Actions</h2>
                    <canvas id="pendingActionsChart"></canvas>
                </div>
            </div>
        </main>
    </div>

    <script>
        const ctx = document.getElementById('pendingActionsChart').getContext('2d');
        const pendingActionsChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Approvals', 'Reviews', 'Updates', 'Retirements'],
                datasets: [{
                    label: 'Pending Actions',
                    data: [12, 9, 15, 8], // You can replace these with dynamic data later
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' }
                }
            }
        });
    </script>
</body>
</html>
