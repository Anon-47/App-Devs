<!-- views/manage_stakeholders.php -->
<?php
require_once '../includes/session.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php'); // Redirect to login if not authenticated
    exit();
}

require '../includes/config.php'; // Database connection

// Fetch stakeholders from database
try {
    $stmt = $pdo->query("SELECT * FROM stakeholders");
    $stakeholders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}

// If the role is not already set in the session, fetch it from the database
if (!isset($_SESSION['role'])) {
    require '../includes/config.php'; // Database connection

    // Query the role of the current user
    try {
        $stmt = $pdo->prepare("SELECT role FROM users WHERE id = :user_id");
        $stmt->execute(['user_id' => $_SESSION['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Set the role in the session if the user is found
        if ($user) {
            $_SESSION['role'] = $user['role'];
        } else {
            $_SESSION['role'] = 'guest'; // Default role if no user found
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
        exit();
    }
}

// Assign the role to a variable for use in this file
$role = $_SESSION['role'];

?>

<?php
// Only Superusers can delete
if ($role === 'superuser'): ?>
    <a href="delete_stakeholder.php?id=<?php echo $stakeholder['id']; ?>">Delete</a>
<?php endif; ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Stakeholders</title>
    <link rel="stylesheet" href="../assets/css/manage_stakeholders.css">
    <script src="../assets/js/scrpt.js"></script>
    <script src="../assets/js/stakeholder_form.js" defer></script>
</head>

    <h1>Manage Stakeholders</h1>

    <!-- List of Stakeholders -->
    <table>
        <thead>
            <tr>
                <th>Stakeholder</th>
                <th>Organization</th>
                <th>Designation</th>
                <th>Location</th>
                <th>Organization_type</th>
                <th>Influence Level</th>
                <th>Interest Level</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($stakeholders as $stakeholder): ?>
            <tr>
                <td><?php echo htmlspecialchars($stakeholder['s_name']); ?></td>
                <td><?php echo htmlspecialchars($stakeholder['organization']); ?></td>
                <td><?php echo htmlspecialchars($stakeholder['designation']); ?></td>
                <td><?php echo htmlspecialchars($stakeholder['location']); ?></td>
                <td><?php echo htmlspecialchars($stakeholder['organization_type']); ?></td>
                <td><?php echo htmlspecialchars($stakeholder['influence_level']); ?></td>
                <td><?php echo htmlspecialchars($stakeholder['interest_level']); ?></td>
                <td>
                    <a href="edit_stakeholder.php?id=<?php echo $stakeholder['id']; ?>">Edit</a> |
                    <a href="profile_stakeholder.php?id=<?php echo $stakeholder['id']; ?>">View Profile</a> |
                    <a href="delete_stakeholder.php?id=<?php echo $stakeholder['id']; ?>">Delete</a> |
                    <a href="edit_stakeholder.php?id=<?php echo $stakeholder['id']; ?>">Classify</a> |
                    <a href="edit_stakeholder.php?id=<?php echo $stakeholder['id']; ?>">Evaluate</a> |
                    <a href="edit_stakeholder.php?id=<?php echo $stakeholder['id']; ?>">Retire</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Buttons to open different forms -->
    <!-- <button class="modal-btn" type="" id="openCreateStakeholderForm" data-form="onboard_stakeholder">Create Stakeholder</button>
    <button class="btn" id="openFeedbackForm" data-form="feedback_form">Feedback Form</button>
    <button class="btn" id="openRetireStakeholderForm" data-form="retire_stakeholder">Retire Stakeholder</button> -->
    
</div>