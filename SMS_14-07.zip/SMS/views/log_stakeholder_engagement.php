<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Engagement Entry</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>

<div class="engagement-form-container">
  <h2>Log New Engagement</h2>
  <form id="logEngagementForm" action="../scripts/log_engagements.php" method="POST">
    <input type="hidden" name="stakeholder_id" value="{{STAKEHOLDER_ID}}">

    <label>Select Department:</label>
    <input type="text" name="department" required>

    <label>TSL Contact/Staff (First Last):</label>
    <input type="text" name="staff_full_name" required>

    <label>Date of Interaction:</label>
    <input type="date" name="interaction_date" required>

    <label>Client (Company):</label>
    <input type="text" name="company" required>

    <!-- Type of Stakeholder Dropdown -->
    <div class="form-group">
        <label for="stakeholder_type">Type of Stakeholder</label>
        <select name="stakeholder_type" id="stakeholder_type" class="form-control" required>
            <option value="">-- Select Type --</option>
            <option value="Business">Business</option>
            <option value="Regulatory">Regulatory</option>
            <option value="Vendors">Vendors</option>
            <option value="Community">Community</option>
            <option value="Advocacy Group">Advocacy Group</option>
        </select>
    </div>

    <!-- Category of Stakeholder Dropdown -->
    <div class="form-group">
        <label for="stakeholder_category">Category of Stakeholder</label>
        <select name="stakeholder_category" id="stakeholder_category" class="form-control" required>
            <option value="">-- Select Category --</option>
            <option value="Cheer Leader">Cheer Leader</option>
            <option value="Uncharted">Uncharted</option>
            <option value="Fans">Fans</option>
            <option value="Observers">Observers</option>
        </select>
    </div>

    <label>Stakeholder Full Name:</label>
    <input type="text" name="stakeholder_fullname" required>

    <label>Already in contact database?</label>
    <select name="in_department_db">
      <option value="Yes">Yes</option>
      <option value="No">No</option>
    </select>

    <label>Nature of Interaction:</label>
    <textarea name="interaction_nature"></textarea>

    <label>If "Other", add details:</label>
    <textarea name="other_details"></textarea>

    <label>Action to be taken or notes:</label>
    <textarea name="follow_up_action"></textarea>

    <label>TRACE Score (1-5):</label>
    <input type="number" name="trace_score" min="1" max="5">

    <button type="submit">Log Engagement</button>
  </form>
</div>
