<!-- views/index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Stakeholder Management App</title>
  <link rel="stylesheet" href="../assets/css/login.css" />
  <style>
    body {
      background: url('../assets/images/sms_bg.jpg') no-repeat center center fixed;
      background-size: cover;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      font-family: 'Segoe UI', sans-serif;
    }
    .login-container {
      background-color: rgba(255, 255, 255, 0.95);
      padding: 30px;
      width: 360px;
      box-shadow: 0px 8px 18px rgba(0,0,0,0.4);
      border-radius: 10px;
      text-align: center;
    }
    h2 {
      color: #d17406;
      margin-bottom: 1em;
    }
    label {
      font-weight: bold;
      color: #333;
      display: block;
      margin-bottom: 6px;
      text-align: left;
    }
    input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    button {
      width: 100%;
      padding: 10px;
      background: #d17406;
      color: white;
      border: none;
      font-weight: bold;
      border-radius: 5px;
      cursor: pointer;
    }
    button:hover {
      background: #b05c03;
    }
    .sso-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      background-color: #2F2F2F;
      color: white;
      padding: 10px;
      width: 100%;
      margin-top: 15px;
      border-radius: 5px;
      text-decoration: none;
      font-weight: bold;
    }
    .sso-button:hover {
      background-color: #1b1b1b;
    }
    .sso-button img {
      width: 18px;
      height: 18px;
    }
    .signup-link {
      margin-top: 12px;
      display: block;
      font-size: 14px;
    }
  </style>
</head>
<body>

  <div class="login-container">
    <h2>Stakeholder Management App</h2>
    <?php if (isset($_GET['timeout'])): ?>
      <p style="color:red;">Session expired due to inactivity.</p>
    <?php endif; ?>

    <form method="POST" action="../scripts/process_login.php">
      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required />

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required />

      <button type="submit">Login</button>
    </form>

    <!-- Office 365 Login -->
    <a href="../scripts/sso_login.php" class="sso-button">
      <img src="https://img.icons8.com/color/48/000000/microsoft.png" alt="MS Logo" />
      Login with Office365
    </a>

    <a class="signup-link" href="signup.php">Create an Account</a>
  </div>

</body>
</html>
