<?php
require '../includes/config.php';
session_start();

if (!isset($_SESSION['preview_data'])) {
    echo "No preview data found.";
    exit;
}

$rows = $_SESSION['preview_data'];
$errors = [];
$successCount = 0;

foreach ($rows as $index => $data) {
    [$name, $email, $phone, $category, $manager_email] = $data;

    // Validate
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Row " . ($index + 1) . ": Invalid email.";
        continue;
    }

    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$manager_email]);
    $rm = $stmt->fetch();

    if (!$rm) {
        $errors[] = "Row " . ($index + 1) . ": Relationship Manager not found.";
        continue;
    }

    $rm_id = $rm['id'];
    $insert = $pdo->prepare("INSERT INTO stakeholders 
        (name, email, phone, category, relationship_manager) 
        VALUES (?, ?, ?, ?, ?)");

    try {
        $insert->execute([$name, $email, $phone, $category, $rm_id]);
        $successCount++;
    } catch (PDOException $e) {
        $errors[] = "Row " . ($index + 1) . ": DB error - " . $e->getMessage();
    }
}

unset($_SESSION['preview_data']); // Clear session

echo "<h3>Import Summary</h3>";
echo "<p>✅ Successfully imported: $successCount</p>";

if (!empty($errors)) {
    echo "<p>❌ Errors:</p><ul>";
    foreach ($errors as $err) echo "<li>" . htmlspecialchars($err) . "</li>";
    echo "</ul>";

    // Log to file
    file_put_contents('../logs/import_errors_' . date('Ymd_His') . '.log', implode(PHP_EOL, $errors));
}
?>
