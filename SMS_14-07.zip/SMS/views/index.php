<?php
// Check if there's a message to display (e.g., after a timeout)
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']); // Sanitize the message
    echo "<div class='timeout-banner'>$message</div>";
}
?>

<?php
require_once '../includes/session.php';
if (isset($_SESSION['user_id'])) {
    // Redirect to dashboard if the user is authenticated
    header("Location: dashboard.php");
    exit;
} else {
    // Redirect to login page if the user is not authenticated
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TSL Logistics Ltd</title>
    <link rel="stylesheet" href="../public/css/dashboardstyles.css">
</head>
<body>
    
    
    <!-- JavaScript for Dynamic Content Loading -->
    <script src="../public/js/dashboard.js"></script>
</body>
</html>
