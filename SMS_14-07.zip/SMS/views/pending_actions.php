<?php
require_once '../includes/session.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

require '../includes/config.php';

$actions = ['approval', 'review', 'update', 'retirement'];
$pendingActions = [];

foreach ($actions as $action) {
    $stmt = $pdo->prepare("SELECT * FROM stakeholders WHERE status = :status");
    $stmt->execute(['status' => $action]);
    $pendingActions[$action] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Pending Actions Counter</title>
  <link rel="stylesheet" href="../assets/css/dashboard.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js" defer></script>
  <!-- <script type="module" src="" defer></script> -->
</head>

<div class="main-content">
    <h1>Pending Actions</h1>

    <?php foreach ($pendingActions as $type => $items): ?>
        <div class="pending-section">
            <h2><?= ucfirst($type) ?>s</h2>
            <?php if (count($items) > 0): ?>
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Organization</th>
                            <th>Designation</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Date Added</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['name']) ?></td>
                                <td><?= htmlspecialchars($row['organization']) ?></td>
                                <td><?= htmlspecialchars($row['designation']) ?></td>
                                <td><?= htmlspecialchars($row['email']) ?></td>
                                <td><?= htmlspecialchars($row['contact']) ?></td>
                                <td><?= htmlspecialchars($row['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No pending <?= $type ?>s at this time.</p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>
