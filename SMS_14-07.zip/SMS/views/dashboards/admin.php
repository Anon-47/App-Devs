<?php
include_once '../../includes/session.php';
include_once '../../includes/config.php';

// Fetch live data
try {
    // Count total stakeholders
    $stmt1 = $pdo->query("SELECT COUNT(*) FROM stakeholders");
    $totalStakeholders = $stmt1->fetchColumn();

    // Count total engagements
    $stmt2 = $pdo->query("SELECT COUNT(*) FROM engagements");
    $totalEngagements = $stmt2->fetchColumn();

    // Monthly engagements
    $stmt3 = $pdo->query("
        SELECT DATE_FORMAT(date, '%b') AS month, COUNT(*) AS count
        FROM engagements
        GROUP BY MONTH(date)
        ORDER BY MONTH(date)
    ");
    $monthlyData = $stmt3->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $totalStakeholders = $totalEngagements = 0;
    $monthlyData = [];
}
?>

<div class="dashboard-section">
    <h2>Admin Dashboard</h2>

    <div class="card-summary">
        <div class="card">
            <h3>Total Stakeholders</h3>
            <p><?= $totalStakeholders ?></p>
        </div>
        <div class="card">
            <h3>Total Engagements</h3>
            <p><?= $totalEngagements ?></p>
        </div>
    </div>

    <div class="chart-area">
        <canvas id="adminChart" height="100"></canvas>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
function renderAdminChart() {
    const labels = <?= json_encode(array_column($monthlyData, 'month')) ?>;
    const data = <?= json_encode(array_column($monthlyData, 'count')) ?>;

    const ctx = document.getElementById('adminChart');
    if (ctx) {
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Monthly Engagements',
                    data: data,
                    backgroundColor: 'rgba(100, 100, 100, 0.6)',
                    borderColor: '#333',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false },
                    title: { display: true, text: 'Engagement Trends' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }
}
</script>

<style>
.dashboard-section {
    padding: 20px;
}
.card-summary {
    display: flex;
    gap: 20px;
    margin-bottom: 30px;
}
.card {
    background: #f3f3f3;
    padding: 20px;
    flex: 1;
    text-align: center;
    border-radius: 8px;
    box-shadow: 0 0 4px rgba(0,0,0,0.1);
}
.chart-area {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
}
</style>
