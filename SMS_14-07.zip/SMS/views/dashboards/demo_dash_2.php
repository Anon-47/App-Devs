<?php
include_once '../../includes/session.php';
include_once '../../includes/config.php';

$role = $_SESSION['role'] ?? 'user';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Stakeholder Dashboard</title>
  <link rel="stylesheet" href="../../assets/css/dashboard.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
        font-family: Arial, sans-serif;
        background: #121212;
        color: #f5f5f5;
        margin: 0;
        padding: 20px;
    }

    h1 {
        color: #ffa500;
        font-weight: bold;
        margin-bottom: 20px;
    }

    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        margin-bottom: 50px;
    }

    .metric-card {
        background-color: #1e1e1e;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        text-align: center;
        transition: 0.3s;
    }

    .metric-card:hover {
        background-color: #2a2a2a;
    }

    .metric-title {
        font-size: 16px;
        margin-bottom: 10px;
        color: #ccc;
    }

    .metric-value {
        font-size: 28px;
        font-weight: bold;
        color: #ffd700;
    }

    .charts-section {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(420px, 1fr));
        gap: 30px;
        align-items: start;
        justify-content: center;
    }

    .chart-box {
        background: #1e1e1e;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.6);
        transition: transform 0.2s ease;
    }

    .chart-box:hover {
        transform: scale(1.01);
    }

    .chart-box h3 {
        color: #ffa500;
        margin-bottom: 20px;
        font-weight: 600;
        border-bottom: 1px solid #444;
        padding-bottom: 5px;
    }

    canvas {
        max-height: 350px;
        width: 100% !important;
    }
  </style>
</head>
<body>

<h1>SMS Overview</h1>

<div class="dashboard-grid" id="metricsContainer">
  <div class="metric-card">
      <div class="metric-title">Total Stakeholders</div>
      <div class="metric-value" id="totalStakeholders">...</div>
  </div>
  <div class="metric-card">
      <div class="metric-title">This Month's Engagements</div>
      <div class="metric-value" id="monthlyEngagements">...</div>
  </div>
  <div class="metric-card">
      <div class="metric-title">Average Stakeholder Rating</div>
      <div class="metric-value" id="averageRating">...</div>
  </div>
  <div class="metric-card">
      <div class="metric-title">Top Classification</div>
      <div class="metric-value" id="topClassification">...</div>
  </div>
  <?php if (in_array($role, ['superuser', 'admin'])): ?>
  <div class="metric-card">
      <div class="metric-title">Top Relationship Manager</div>
      <div class="metric-value" id="topRM">...</div>
  </div>
  <?php endif; ?>
</div>

<!-- CHARTS -->
<div class="charts-section">
  <div class="chart-box">
      <h3>Engagements by Relationship Manager</h3>
      <canvas id="engagementsByRMChart"></canvas>
  </div>
  <div class="chart-box">
      <h3>Stakeholder Classifications</h3>
      <canvas id="classificationPieChart"></canvas>
  </div>
  <div class="chart-box">
      <h3>Stakeholders per Department</h3>
      <canvas id="departmentChart"></canvas>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  fetch('../../api/fetch_dashboard_metrics.php')
    .then(res => res.json())
    .then(data => {
        // Cards
        document.getElementById("totalStakeholders").innerText = data.total_stakeholders;
        document.getElementById("monthlyEngagements").innerText = data.monthly_engagements;
        document.getElementById("averageRating").innerText = data.average_rating;
        document.getElementById("topClassification").innerText = data.top_classification || "—";
        if (data.top_rm !== undefined) {
            document.getElementById("topRM").innerText = data.top_rm || "—";
        }

        // Charts
        renderEngagementsByRMChart(data.engagements_by_rm);
        renderClassificationPieChart(data.classification_distribution);
        renderDepartmentChart(data.stakeholders_per_department);
    })
    .catch(err => {
        console.error("Dashboard Load Error:", err);
    });

  function renderEngagementsByRMChart(data) {
    new Chart(document.getElementById('engagementsByRMChart'), {
      type: 'bar',
      data: {
        labels: data.map(d => d.rm),
        datasets: [{
          label: '# of Engagements',
          data: data.map(d => d.count),
          backgroundColor: '#ffb347'
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { color: '#ccc' },
            grid: { color: '#333' }
          },
          x: {
            ticks: { color: '#ccc' },
            grid: { color: '#333' }
          }
        }
      }
    });
  }

  function renderClassificationPieChart(data) {
    new Chart(document.getElementById('classificationPieChart'), {
      type: 'pie',
      data: {
        labels: data.map(d => d.classification || 'Unclassified'),
        datasets: [{
          data: data.map(d => d.count),
          backgroundColor: ['#ffcc00', '#ff6600', '#66ccff', '#66ff66', '#ff3366']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            labels: {
              color: '#ccc'
            }
          }
        }
      }
    });
  }

  function renderDepartmentChart(data) {
    const labels = data.map(d => d.department || "Unassigned");
    const counts = data.map(d => d.stakeholder_count);

    new Chart(document.getElementById('departmentChart'), {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Stakeholders',
          data: counts,
          backgroundColor: '#4caf50'
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { color: '#ccc' },
            grid: { color: '#333' }
          },
          x: {
            ticks: { color: '#ccc' },
            grid: { color: '#333' }
          }
        }
      }
    });
  }
});
</script>

</body>
</html>
