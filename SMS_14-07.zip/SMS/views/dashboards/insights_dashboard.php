<?php
require_once '../../includes/config.php';

// Department-level insights
$dept_stmt = $pdo->query("SELECT department, COUNT(DISTINCT stakeholder_fullname) AS stakeholders, COUNT(*) AS engagements FROM stakeholder_engagements GROUP BY department");
$departments = $dept_stmt->fetchAll(PDO::FETCH_ASSOC);

// Stakeholder Types
$type_stmt = $pdo->query("SELECT stakeholder_type, COUNT(DISTINCT stakeholder_fullname) AS count FROM stakeholder_engagements GROUP BY stakeholder_type");
$types = $type_stmt->fetchAll(PDO::FETCH_ASSOC);

// Stakeholder Categories
$cat_stmt = $pdo->query("SELECT stakeholder_category, COUNT(DISTINCT stakeholder_fullname) AS count FROM stakeholder_engagements GROUP BY stakeholder_category");
$categories = $cat_stmt->fetchAll(PDO::FETCH_ASSOC);

// Relationship Manager insights
$rm_stmt = $pdo->query("
    SELECT relationship_manager_email, COUNT(*) AS engagements, 
           AVG(trace_score) AS avg_trace, 
           SUM(follow_up_status = 'Yes') / COUNT(*) * 100 AS follow_rate 
    FROM stakeholder_engagements 
    GROUP BY relationship_manager_email
");
$rms = $rm_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stakeholder Insights Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            background: #f8f9fa;
        }
        h1 {
            padding: 20px;
        }
        .metrics {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            padding: 20px;
        }
        .card {
            background: linear-gradient(135deg, #c96f00, #ffc107);
            padding: 20px;
            flex: 1 1 300px;
            border-radius: 8px;
            color: white;
            box-shadow: 0 3px 6px rgba(0,0,0,0.2);
        }
        .section-title {
            margin: 30px 20px 10px;
            font-weight: bold;
            font-size: 1.2em;
        }
        table {
            width: 95%;
            margin: 0 auto 30px;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 12px;
            text-align: left;
        }
        th {
            background: #f4a940;
            color: #fff;
        }
    </style>
</head>
<body>

<h1>Stakeholder Insight Dashboard</h1>

<div class="metrics">
    <?php foreach ($departments as $dept): ?>
        <div class="card">
            <h3><?= htmlspecialchars($dept['department']) ?></h3>
            <p><strong>Stakeholders:</strong> <?= $dept['stakeholders'] ?></p>
            <p><strong>Engagements:</strong> <?= $dept['engagements'] ?></p>
        </div>
    <?php endforeach; ?>
</div>

<div class="section-title">Stakeholders by Type</div>
<div class="metrics">
    <?php foreach ($types as $type): ?>
        <div class="card">
            <h3><?= htmlspecialchars($type['stakeholder_type']) ?></h3>
            <p><strong>Total:</strong> <?= $type['count'] ?></p>
        </div>
    <?php endforeach; ?>
</div>

<div class="section-title">Stakeholders by Category</div>
<div class="metrics">
    <?php foreach ($categories as $cat): ?>
        <div class="card">
            <h3><?= htmlspecialchars($cat['stakeholder_category']) ?></h3>
            <p><strong>Total:</strong> <?= $cat['count'] ?></p>
        </div>
    <?php endforeach; ?>
</div>

<div class="section-title">Relationship Manager Insights</div>
<table>
    <thead>
        <tr>
            <th>RM Email</th>
            <th>Total Engagements</th>
            <th>Avg TRACE Score</th>
            <th>Follow-Up Rate (%)</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($rms as $rm): ?>
            <tr>
                <td><?= htmlspecialchars($rm['relationship_manager_email']) ?></td>
                <td><?= $rm['engagements'] ?></td>
                <td><?= number_format($rm['avg_trace'], 2) ?></td>
                <td><?= number_format($rm['follow_rate'], 1) ?>%</td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>
