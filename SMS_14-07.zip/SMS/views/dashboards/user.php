<!-- Dashboard Metrics Layout -->
<div class="dashboard-metrics">
  <div class="metric-card mustard">
    <h3>Total Stakeholders</h3>
    <p id="totalStakeholders">...</p>
  </div>
  <div class="metric-card burgundy">
    <h3>New Stakeholders (Month)</h3>
    <p id="newStakeholders">...</p>
  </div>
  <div class="metric-card tan">
    <h3>Total Engagements</h3>
    <p id="totalEngagements">...</p>
  </div>
  <div class="metric-card grey">
    <h3>Average Engagement Rating</h3>
    <p id="avgRating">...</p>
  </div>
  <div class="metric-card brown">
    <h3>Follow-Up Actions (%)</h3>
    <p id="followUpPercentage">...</p>
  </div>
</div>

<!-- Chart Containers -->
<div class="chart-section">
  <div class="chart-card">
    <canvas id="typeBreakdownChart"></canvas>
  </div>
  <div class="chart-card">
    <canvas id="categoryBreakdownChart"></canvas>
  </div>
</div>
