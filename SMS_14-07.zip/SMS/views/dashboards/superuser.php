<?php 
include_once(__DIR__ . '/../../includes/session.php');
// include_once(__DIR__ . '/../../includes/config.php');
// include_once(__DIR__ . '/../../includes/sidebar.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Superuser Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { font-family: sans-serif; background: #f9f9f9; margin: 0; }
    .header { background: #2f2f2f; color: white; padding: 12px; }
    .cards { display: flex; gap: 16px; padding: 20px; flex-wrap: wrap; }
    .card { background: white; flex: 1 1 200px; border-left: 5px solid #444; padding: 16px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
    .charts { display: flex; gap: 20px; padding: 20px; }
    .chart-box { background: white; padding: 16px; flex: 1; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
  </style>
</head>
<body>

<div class="header"> <strong>Superuser</strong> </div>

<div class="cards">
  <div class="card"><h3>0</h3><p>Sample Metric A</p></div>
  <div class="card"><h3>0</h3><p>Sample Metric B</p></div>
  <div class="card"><h3>0</h3><p>Sample Metric C</p></div>
  <div class="card"><h3>0</h3><p>Sample Metric D</p></div>
</div>

<div class="charts">
  <div class="chart-box">
    <h4>Pie Chart</h4>
    <canvas id="pieChart"></canvas>
  </div>
  <div class="chart-box">
    <h4>Bar Chart</h4>
    <canvas id="barChart"></canvas>
  </div>
</div>

<script>
const pieCtx = document.getElementById('pieChart').getContext('2d');
new Chart(pieCtx, {
  type: 'pie',
  data: {
    labels: ['Red', 'Green', 'Blue'],
    datasets: [{ data: [70, 45, 88], backgroundColor: ['#e74c3c', '#2ecc71', '#3498db'] }]
  }
});

const barCtx = document.getElementById('barChart').getContext('2d');
new Chart(barCtx, {
  type: 'bar',
  data: {
    labels: ['Jan', 'Feb', 'Mar'],
    datasets: [{ label: 'Activity', data: [32, 79, 17], backgroundColor: '#34495e' }]
  }
});
</script>

</body>
</html>