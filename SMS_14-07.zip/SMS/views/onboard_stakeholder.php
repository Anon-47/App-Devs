<!-- onboard_stakeholder.php -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Stakeholder</title>
    <link rel="stylesheet" href="../assets/css/forms.css">
    <style> 
    .popup {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #e6ffed;
    color: #155724;
    padding: 15px 20px;
    border-left: 6px solid #28a745;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    z-index: 9999;
    animation: slideFade 0.5s ease;
    }

    .popup.success::before {
        content: "✔️ ";
        font-weight: bold;
    }

    @keyframes slideFade {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    </style>
</head>

<body>
<div class="form-container">
    <h2>Onboard New Stakeholder</h2>
    <?php if (isset($_GET['status']) && $_GET['status'] === 'success'): ?>
    <div id="popupMessage" class="popup success">
        ✅ Stakeholder created successfully!
    </div>
    <script>
        setTimeout(() => {
            const popup = document.getElementById('popupMessage');
            if (popup) popup.style.display = 'none';
        }, 4000); // auto-hide after 4 seconds
    </script>
    <?php endif; ?>

    <form action="../scripts/process_onboarding.php" method="POST" id="onboardForm">
        <label for="name">Full Name*</label>
        <input type="text" name="s_name" id="name" required>

        <label for="organization">Organization*</label>
        <input type="text" name="organization" id="organization" required>

        <label for="organization_type">Organization Type*</label>
        <input type="text" name="organization_type" id="organization_type" required>

        <label for="designation">Designation*</label>
        <input type="text" name="designation" id="designation" required>

        <label for="contact">Contact Number*</label>
        <input type="text" name="contact" id="contact" required>

        <label for="email">Email*</label>
        <input type="email" name="email" id="email" required>

        <label for="location">Location*</label>
        <input type="text" name="location" id="location" required>

        <label for="influence_level">Influence Level*</label>
        <select name="influence_level" id="influence_level" required>
            <option value="">-- Select Level --</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
        </select>

        <label for="interest_level">Interest Level*</label>
        <select name="interest_level" id="interest_level" required>
            <option value="">-- Select Level --</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
        </select>

        <label for="relationship_manager">Relationship Manager*</label>
        <select name="relationship_manager" id="relationship_manager" required>
        <?php
        require '../includes/config.php';

        // Allow multiple roles to be relationship managers
        $allowedRoles = ['User', 'Guest', 'Manager', 'Superuser'];
        $placeholders = implode(',', array_fill(0, count($allowedRoles), '?'));

        $query = "SELECT id, full_name FROM users WHERE role IN ($placeholders)";
        $stmt = $pdo->prepare($query);
        $stmt->execute($allowedRoles);

        $managers = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($managers) {
            foreach ($managers as $row) {
                echo "<option value='{$row['id']}'>" . htmlspecialchars($row['full_name']) . "</option>";
            }
        } else {
            echo "<option disabled>No Eligible Managers Found</option>";
        }
        ?>
        </select>

        <button type="submit" class="btn">Create Stakeholder</button>
    </form>
</div>
</body>
