<?php
// Assuming user is authenticated
// require_once '../includes/session.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../views/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="logo">Stakeholder Manager</div>
        <!-- <nav>
            <ul>
                <li><a href="#" data-page="dashb.php">Dashboard</a></li>
                <li><a href="#" data-page="manage_users.php">Manage Users</a></li>
                <li><a href="#" data-page="manage_stakeholders.php">Manage Stakeholders</a></li>
                <li><a href="#" data-page="approve_stakeholders.php">Approve Stakeholders</a></li>
                <li><a href="#" data-page="profile.php">Profile</a></li>
                <button type="submit"> <a href="../scripts/process_logout.php"> Logout</a> </button>
            </ul>
        </nav> -->
            <ul class="nav-list">
                <!-- Main Menu Item with Submenu -->
                <li class="nav-item">
                    <a href="#" class="main-menu" onclick="toggleSubmenu('dashboardSubmenu')">Dashboard</a>
                    <ul class="submenu" id="dashboardSubmenu">
                        <li><a href="#" data-page="dashboard_new.php">View Dashboard</a></li>
                        <!-- Assuming this is within the sidebar menu structure -->
                        <li class="nav-item">
                        <a href="pending_actions.php" onclick="loadContent(event, 'pending_actions.php')">
                        Pending Actions
                        <span id="pendingBadge" class="badge">0</span>
                        </a>
                        </li>
                    </ul>
                </li>
                                
                <!-- Main Menu Item with Submenu -->
                <li class="nav-item">
                    <a href="#" class="main-menu" onclick="toggleSubmenu('stakeholderSubmenu')">Stakeholders</a>
                    <ul class="submenu" id="stakeholderSubmenu">
                        <li><a href="#" class="dashboard-link" data-page="view_stakeholders.php">View Stakeholders</a></li>
                        <li><a href="#" class="dashboard-link" data-page="onboard_stakeholder.php">Create Stakeholder</a></li>
                        <li><a href="#" class="dashboard-link" data-page="import_stakeholders.php">Import Stakeholders</a></li>
                        <li><a href="#" class="dashboard-link" data-page="manage_stakeholders.php">Manage Stakeholders</a></li>
                    </ul>
                </li>

                <!-- Main Menu Item with Submenu -->
                <li class="nav-item">
                    <a href="#" class="main-menu" onclick="toggleSubmenu('engagementSubmenu')">Engagements</a>
                    <ul class="submenu" id="engagementSubmenu">
                        <li><a href="#" class="dashboard-link" data-page="view_engagements.php">View Engagements</a></li>
                        <li><a href="#" class="dashboard-link" data-page="log_stakeholder_engagement.php">Enter Engagement</a></li>
                        <li><a href="#" class="dashboard-link" data-page="import_engagements.php">Import Engagements</a></li>
                        <!-- <li><a href="#" class="dashboard-link" data-page="relationship_manager.php">Relationship</a></li> -->
                    </ul>
                </li>

                <!-- Main Menu Item with Submenu -->
                <li class="nav-item">
                    <a href="#" class="main-menu" onclick="toggleSubmenu('relationshipmangerSubmenu')">Relationship Managers</a>
                    <ul class="submenu" id="relationshipmangersSubmenu">
                        <li><a href="#" class="dashboard-link" data-page="../views/relationship_managers/index.php">View RMs</a></li>
                        <li><a href="#" class="dashboard-link" data-page="../views/relationship_managers/create.php">Create RMs</a></li>
                        <li><a href="#" class="dashboard-link" data-page="manage_stakeholders.php">Manage RMs</a></li>
                        <!-- <li><a href="#" class="dashboard-link" data-page="relationship_manager.php">Relationship Managers</a></li> -->
                    </ul>
                </li>

                <!-- Another Main Menu Item with Submenu -->
                <li class="nav-item">
                    <a href="#" class="main-menu" onclick="toggleSubmenu('reportsSubmenu')">Reports</a>
                    <ul class="submenu" id="reportsSubmenu">
                        <li><a href="#" class="dashboard-link" data-page="../reports/monthly_report.php">Monthly Report</a></li>
                        <li><a href="#" class="dashboard-link" data-page="../reports/quarterly_report.php">Quarterly Report</a></li>
                        <li><a href="#" class="dashboard-link" data-page="../reports/index.php">Custom Report</a></li>
                    </ul>
                </li>

                <!-- Another Main Menu Item with Submenu -->
                <li class="nav-item">
                    <a href="#" class="main-menu" onclick="toggleSubmenu('settingsSubmenu')">Settings</a>
                    <ul class="submenu" id="settingsSubmenu">
                        <li><a href="#" class="dashboard-link" data-page="my_profile.php">My Account</a></li>
                        <li><a href="#" class="dashboard-link" data-page="manage_users.php">Manage Users</a></li>
                        <li><a href="#" class="dashboard-link" data-page="system_preferences.php">System Preference</a></li>
                    </ul>
                </li>

                <!-- Single Navigation Item (No Submenu) -->
                <!-- <li class="nav-item">
                    <a class="main-menu" href="#" data-page="dashb.php">Dashboard</a>
                </li> -->

                <!-- Single Navigation Item (No Submenu) -->
                <li class="nav-item">
                <button type="submit"> <a href="../scripts/process_logout.php"> Logout</a> </button>
                </li>
            </ul>
        </nav>
    </aside>

    <!-- Main Activity Area -->
    <main class="activity-area" id="activity-area">
        <div class="main-content" id="contentArea">
            <!-- Loaded content will appear here -->
            <h2 position = "center">Welcome to your Dashboard</h2>
            <p position = "center">Select a section from the sidebar to begin.</p>
        </div>
        <!-- Move this to your main layout if needed -->
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    </main>
    <!-- JavaScript for Dynamic Content Loading -->
    <script src="../assets/js/dashboard.js"></script>
    
</body>
</html>


 <!-- Footer -->
 <footer class="footer">
        <p>&copy; 2024 TSL Stakeholder Management Software.   Developed by: TSLLOG_IT.   All rights reserved.</p>
    </footer>