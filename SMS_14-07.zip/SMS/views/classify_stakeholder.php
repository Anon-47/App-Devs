<?php
require_once '../includes/config.php';

if (!isset($_GET['id'])) {
    die("Missing stakeholder ID.");
}

$id = intval($_GET['id']);

// Fetch stakeholder details
$stmt = $pdo->prepare("SELECT * FROM stakeholders WHERE id = ?");
$stmt->execute([$id]);
$stakeholder = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$stakeholder) {
    die("Stakeholder not found.");
}

$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['classification'])) {
    $classification = trim($_POST['classification']);
    $update = $pdo->prepare("UPDATE stakeholders SET classification = ? WHERE id = ?");
    $update->execute([$classification, $id]);
    $success = true;

    // Refresh details
    $stmt->execute([$id]);
    $stakeholder = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Classify Stakeholder</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #111827;
            color: #fff;
        }
        .container {
            max-width: 960px;
            margin: 40px auto;
            padding: 40px;
            background-color: #1f2937;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.4);
        }
        h2 {
            font-size: 26px;
            font-weight: bold;
            margin-bottom: 30px;
        }
        .grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .card {
            background-color: #2d3748;
            padding: 20px;
            border-radius: 10px;
            flex: 1 1 260px;
            min-width: 240px;
        }
        .card label {
            color: #f59e0b;
            font-weight: 600;
            display: block;
            margin-bottom: 5px;
        }
        .card span, .card input, .card textarea {
            display: block;
            color: #e5e7eb;
            background: transparent;
            border: none;
            width: 100%;
            font-size: 15px;
        }
        .card input:read-only, .card textarea:read-only {
            background-color: transparent;
        }
        .form-group {
            margin-top: 30px;
        }
        select {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            background-color: #374151;
            color: #f3f4f6;
            border: 1px solid #4b5563;
        }
        button {
            background-color: #f59e0b;
            border: none;
            color: #fff;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 25px;
        }
        button:hover {
            background-color: #d97706;
        }
        .success {
            background-color: #16a34a;
            color: white;
            padding: 12px;
            margin-top: 20px;
            border-radius: 6px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Classify Stakeholder</h2>

    <?php if ($success): ?>
        <div class="success">Classification successfully updated!</div>
    <?php endif; ?>

    <form method="POST" action="classify_stakeholder.php?id=<?= $id ?>">
        <div class="grid">
            <div class="card">
                <label>Full Name</label>
                <span><?= htmlspecialchars($stakeholder['s_name']) ?></span>
            </div>
            <div class="card">
                <label>Organization</label>
                <span><?= htmlspecialchars($stakeholder['organization']) ?></span>
            </div>
            <div class="card">
                <label>Designation</label>
                <span><?= htmlspecialchars($stakeholder['designation']) ?></span>
            </div>
            <div class="card">
                <label>Location</label>
                <span><?= htmlspecialchars($stakeholder['location']) ?></span>
            </div>
            <div class="card">
                <label>Organization Type</label>
                <span><?= htmlspecialchars($stakeholder['organization_type']) ?></span>
            </div>
            <div class="card">
                <label>Email</label>
                <span><?= htmlspecialchars($stakeholder['email']) ?></span>
            </div>
            <div class="card">
                <label>Contact</label>
                <span><?= htmlspecialchars($stakeholder['contact']) ?></span>
            </div>
            <div class="card">
                <label>Influence Level</label>
                <textarea readonly rows="2"><?= htmlspecialchars($stakeholder['influence_level']) ?></textarea>
            </div>
            <div class="card">
                <label>Interest Level</label>
                <textarea readonly rows="2"><?= htmlspecialchars($stakeholder['interest_level']) ?></textarea>
            </div>
        </div>

        <div class="form-group">
            <label style="color: #f59e0b;">Classify Stakeholder</label>
            <select name="classification" required>
                <option value="">-- Select Classification --</option>
                <option value="Key Player" <?= $stakeholder['classification'] == 'Key Player' ? 'selected' : '' ?>>Key Player</option>
                <option value="Cheer Leader" <?= $stakeholder['classification'] == 'Cheer Leader' ? 'selected' : '' ?>>Cheer Leader</option>
                <option value="Observers" <?= $stakeholder['classification'] == 'Observers' ? 'selected' : '' ?>>Observers</option>
                <option value="Minimal Effort" <?= $stakeholder['classification'] == 'Minimal Effort' ? 'selected' : '' ?>>Minimal Effort</option>
            </select>

            <button type="submit">Update Classification</button>
        </div>
    </form>
</div>
</body>
</html>
