<?php
// view_stakeholders.php
include_once '../includes/session.php';
include_once '../includes/config.php';

// Handle search
$search = $_GET['search'] ?? '';
$params = [];

$sql = "
    SELECT 
        s.id,
        s.organization,
        rm.full_name AS relationship_manager_name,
        s.relationship_manager,
        e.latest_date AS last_engagement_date,
        e.interaction_nature,
        s.classification,
        s.rating
    FROM stakeholders s
    LEFT JOIN users rm ON s.relationship_manager = rm.id
    LEFT JOIN (
        SELECT se1.stakeholder_id, se1.interaction_date AS latest_date, se1.interaction_nature
        FROM stakeholder_engagements se1
        INNER JOIN (
            SELECT stakeholder_id, MAX(interaction_date) AS max_date
            FROM stakeholder_engagements
            GROUP BY stakeholder_id
        ) se2 ON se1.stakeholder_id = se2.stakeholder_id AND se1.interaction_date = se2.max_date
    ) e ON s.id = e.stakeholder_id
    WHERE s.account_status = 'active'
";

if (!empty($search)) {
    $sql .= " AND (s.organization LIKE :search OR rm.full_name LIKE :search)";
    $params['search'] = '%' . $search . '%';
}

$sql .= " ORDER BY s.organization ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$stakeholders = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$stakeholders) {
    $stakeholders = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Stakeholders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f6f6f6;
            margin: 0;
            padding: 0;
        }
        .manage-stakeholders-container {
            padding: 20px;
        }
        h1 {
            color: #444;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 8px 16px;
            background-color: #d2691e;
            color: white;
            border: none;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 8px rgba(0,0,0,0.05);
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #e0e0e0;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        a {
            text-decoration: none;
            color: #007BFF;
        }
    </style>
    <script>
    let currentPage = 1;
    const rowsPerPage = 10;

    function paginateTable() {
        const table = document.getElementById("stakeholderTable");
        const tbody = table.querySelector("tbody");
        const allRows = Array.from(tbody.querySelectorAll("tr"));

        allRows.forEach((row, index) => {
            row.style.display = (index >= (currentPage - 1) * rowsPerPage && index < currentPage * rowsPerPage) ? "" : "none";
        });

        renderPaginationControls(allRows.length);
    }

    function renderPaginationControls(totalRows) {
        const totalPages = Math.ceil(totalRows / rowsPerPage);
        let paginationHtml = "";

        for (let i = 1; i <= totalPages; i++) {
            paginationHtml += `<button onclick="goToPage(${i})" ${i === currentPage ? 'style="font-weight:bold;"' : ''}>${i}</button>`;
        }

        document.getElementById("pagination").innerHTML = paginationHtml;
    }

    function goToPage(page) {
        currentPage = page;
        paginateTable();
    }

    function exportToCSV() {
        const rows = document.querySelectorAll("#stakeholderTable tr");
        const csv = [];

        rows.forEach(row => {
            if (row.style.display === "none") return;
            const cols = row.querySelectorAll("td, th");
            const rowData = Array.from(cols).map(col => `"${col.innerText}"`);
            csv.push(rowData.join(","));
        });

        const csvBlob = new Blob([csv.join("\n")], { type: "text/csv" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(csvBlob);
        link.download = "stakeholders_export.csv";
        link.click();
    }

    document.addEventListener("DOMContentLoaded", () => {
        paginateTable();
    });
    </script>
</head>
<body>
<div class="manage-stakeholders-container">
    <h1>All Stakeholders</h1>

    <form method="GET">
        <input type="text" name="search" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" placeholder="Search stakeholders...">
        <button type="submit">Search</button>
    </form>

    <div style="margin: 10px 0;">
        <button onclick="exportToCSV()">📤 Export to CSV</button>
    </div>

    <table id="stakeholderTable">
        <thead>
        <tr>
            <th>Stakeholder Company</th>
            <th>Relationship Manager</th>
            <th>Last Engagement Date</th>
            <th>Engagement Type</th>
            <th>Classification</th>
            <th>Rating</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($stakeholders as $row): ?>
            <tr>
                <td><a href="profile_stakeholder.php?id=<?= $row['id'] ?>"><?= htmlspecialchars($row['organization']) ?></a></td>
                <td><?= htmlspecialchars($row['relationship_manager_name']) ?></td>
                <td><?= $row['last_engagement_date'] ?? '—' ?></td>
                <td><?= $row['interaction_nature'] ?? '—' ?></td>
                <td><?= $row['classification'] ?? '—' ?></td>
                <td><?= $row['rating'] ?? '—' ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div id="pagination" style="margin-top: 20px;"></div>
</div>
</body>
</html>
