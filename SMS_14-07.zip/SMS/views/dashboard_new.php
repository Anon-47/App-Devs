<!-- Loading Spinner -->
<!-- <div id="loader" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(255,255,255,0.8); z-index:9999; display:flex; justify-content:center; align-items:center;">
    <div style="border:6px solid #ccc; border-top:6px solid #333; border-radius:50%; width:40px; height:40px; animation: spin 1s linear infinite;"></div>
</div>

<style>
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style> -->

<?php
// include_once(__DIR__ . '/../includes/session.php');
require '../includes/session.php';

if (!isset($_SESSION['role'])) {
    echo "User role not set.";
    exit;
}

switch ($_SESSION['role']) {
    case 'superuser':
        header("Location: dashboards/superuser.php");
        exit;
    case 'admin':
        header("Location: dashboards/admin.php");
        exit;
    case 'manager':
        header("Location: dashboards/manager.php");
        exit;
    case 'user':
        header("Location: dashboards/user.php");
        exit;
    default:
        echo "Unknown role. Please contact administrator.";
        exit;
}
?>
