<?php
session_start();
require '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    die("Unauthorized access.");
}

// Fetch pending approvals
$stmt = $pdo->query("SELECT * FROM approvals WHERE status = 'pending'");
$approvals = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Pending Approvals</h2>
<table>
    <tr>
        <th>Type</th>
        <th>Data</th>
        <th>Requested By</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($approvals as $approval): ?>
    <tr>
        <td><?= ucfirst(str_replace('_', ' ', $approval['request_type'])) ?></td>
        <td><?= htmlentities($approval['request_data']) ?></td>
        <td><?= $approval['requested_by'] ?></td>
        <td>
            <a href="approve_request.php?id=<?= $approval['id'] ?>&action=approve" class="btn btn-primary">Approve</a>
            <a href="approve_request.php?id=<?= $approval['id'] ?>&action=reject" class="btn btn-danger">Reject</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
