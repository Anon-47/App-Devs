<?php
require_once("../includes/config.php");
require_once("../includes/functions.php");

if (!isset($_GET['id'])) {
    die("Missing stakeholder ID.");
}

$id = intval($_GET['id']);

try {
    $stmt = $pdo->prepare("SELECT * FROM stakeholders WHERE id = ?");
    $stmt->execute([$id]);
    $stakeholder = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$stakeholder) {
        die("Stakeholder not found.");
    }

    $rmList = $pdo->query("SELECT id, full_name FROM users WHERE role IN ('manager', 'admin', 'superuser', 'user') ORDER BY full_name ASC")->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("DB error: " . $e->getMessage());
}

// Match RM full name
$currentRMName = 'Not Assigned';
foreach ($rmList as $rm) {
    if ((string)$rm['id'] === (string)$stakeholder['relationship_manager']) {
        $currentRMName = $rm['full_name'];
        break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Stakeholder</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <style>
        body {
            background: #0f172a;
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            padding: 40px;
        }
        .card-container {
            background: #1e293b;
            max-width: 960px;
            margin: 0 auto;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.5);
        }
        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .card {
            background: #334155;
            padding: 16px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.4);
        }
        .card label {
            color: #f59e0b;
            font-weight: 600;
            display: block;
            margin-bottom: 6px;
        }
        .card input,
        .card textarea,
        .card select {
            width: 100%;
            padding: 10px;
            background: #1e293b;
            color: #f1f5f9;
            border: 1px solid #475569;
            border-radius: 5px;
        }
        .action {
            text-align: right;
        }
        .btn-submit {
            background: #f59e0b;
            color: #000;
            padding: 12px 30px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }
        .btn-submit:hover {
            background: #d97706;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 1.8rem;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="card-container">
        <h2>Edit Stakeholder</h2>
        <form method="POST" action="update_stakeholder.php">
            <input type="hidden" name="id" value="<?= htmlspecialchars($stakeholder['id']) ?>">

            <div class="card-grid">
                <div class="card">
                    <label>Full Name</label>
                    <input type="text" name="s_name" value="<?= htmlspecialchars($stakeholder['s_name']) ?>" required>
                </div>
                <div class="card">
                    <label>Organization</label>
                    <input type="text" name="organization" value="<?= htmlspecialchars($stakeholder['organization']) ?>">
                </div>
                <div class="card">
                    <label>Designation</label>
                    <input type="text" name="designation" value="<?= htmlspecialchars($stakeholder['designation']) ?>">
                </div>
                <div class="card">
                    <label>Location</label>
                    <input type="text" name="location" value="<?= htmlspecialchars($stakeholder['location']) ?>">
                </div>
                <div class="card">
                    <label>Org Type</label>
                    <input type="text" name="organization_type" value="<?= htmlspecialchars($stakeholder['organization_type']) ?>">
                </div>
                <div class="card">
                    <label>Influence Level</label>
                    <textarea name="influence_level"><?= htmlspecialchars($stakeholder['influence_level']) ?></textarea>
                </div>
                <div class="card">
                    <label>Interest Level</label>
                    <textarea name="interest_level"><?= htmlspecialchars($stakeholder['interest_level']) ?></textarea>
                </div>
                <div class="card">
                    <label>Contact</label>
                    <input type="text" name="contact" value="<?= htmlspecialchars($stakeholder['contact']) ?>">
                </div>
                <div class="card">
                    <label>Email</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($stakeholder['email']) ?>">
                </div>
                <div class="card">
                    <label>Current RM</label>
                    <input type="text" value="<?= htmlspecialchars($currentRMName) ?>" readonly>
                </div>
                <div class="card">
                    <label>Newly Assigned RM</label>
                    <select name="assigned_rm">
                        <option value="">-- Select RM --</option>
                        <?php foreach ($rmList as $rm): ?>
                            <option value="<?= $rm['id'] ?>"><?= htmlspecialchars($rm['full_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="action">
                <button type="submit" class="btn-submit">Save Changes</button>
            </div>
        </form>
    </div>
</body>
</html>
