<!-- views/system_preferences.php -->

<head>
    <meta charset="UTF-8">
    <title>System Preferences</title>
    <link rel="stylesheet" href="../assets/css/sys_preferences.css">
</head>
<body>
    <div class="preferences-container">
        <h2>System Preferences</h2>
        <form action="../scripts/process_preferences.php" method="POST">
            <label for="theme">Theme</label>
            <select name="theme" id="theme">
                <option value="light">Light</option>
                <option value="dark">Dark</option>
            </select>
            
            <label for="notifications_enabled">Enable Notifications</label>
            <input type="checkbox" name="notifications_enabled" id="notifications_enabled" checked>
            
            <label for="language">Language</label>
            <select name="language" id="language">
                <option value="en">English</option>
                <option value="fr">French</option>
                <!-- Add more languages as needed -->
            </select>
            
            <button type="submit">Save Preferences</button>
        </form>
    </div>
</body>

