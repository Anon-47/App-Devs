<?php
require '../includes/config.php';

// Get stakeholder ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "Invalid stakeholder ID.";
    exit;
}
$stakeholder_id = intval($_GET['id']);

// Fetch stakeholder info
$stmt = $pdo->prepare("SELECT * FROM stakeholders WHERE id = ?");
$stmt->execute([$stakeholder_id]);
$stakeholder = $stmt->fetch();

if (!$stakeholder) {
    echo "Stakeholder not found.";
    exit;
}

// Fetch related engagements
$engagements_stmt = $pdo->prepare("SELECT * FROM stakeholder_engagements WHERE stakeholder_id = ? ORDER BY interaction_date DESC");
$engagements_stmt->execute([$stakeholder_id]);
$engagements = $engagements_stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Stakeholder Profile</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body class="dark-theme">
    <?php include '../includes/sidebar.php'; ?>
    <div class="main-content">
        <div class="profile-card">
            <div class="profile-header">
                <div class="profile-picture">
                    <img src="../assets/img/avatar.png" alt="Profile Picture" />
                </div>
                <h2><?= htmlspecialchars($stakeholder['s_name']) ?></h2>
                <p><?= htmlspecialchars($stakeholder['designation']) ?> @ <?= htmlspecialchars($stakeholder['organization']) ?></p>
                <form method="POST" enctype="multipart/form-data">
                    <input type="file" name="profile_image" />
                    <button type="submit">Upload Image</button>
                </form>
            </div>

            <div class="profile-info">
                <div class="info-box">Email<br><strong><?= htmlspecialchars($stakeholder['email']) ?></strong></div>
                <div class="info-box">Contact<br><strong><?= htmlspecialchars($stakeholder['phone']) ?></strong></div>
                <div class="info-box">Organization Type<br><strong><?= htmlspecialchars($stakeholder['organization_type']) ?></strong></div>
                <div class="info-box">Location<br><strong><?= htmlspecialchars($stakeholder['location']) ?></strong></div>
                <div class="info-box">Influence Level<br><strong><?= htmlspecialchars($stakeholder['influence_level']) ?></strong></div>
                <div class="info-box">Interest Level<br><strong><?= htmlspecialchars($stakeholder['interest_level']) ?></strong></div>
                <div class="info-box">Relationship Manager<br><strong><?= htmlspecialchars($stakeholder['relationship_manager']) ?></strong></div>
            </div>

            <div class="engagement-history">
                <h3>Engagement Activity</h3>
                <?php if (count($engagements) > 0): ?>
                    <table class="styled-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Staff Contact</th>
                                <th>Nature</th>
                                <th>Action Notes</th>
                                <th>TRACE Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($engagements as $e): ?>
                                <tr>
                                    <td><?= htmlspecialchars(date('Y-m-d', strtotime($e['interaction_date']))) ?></td>
                                    <td><?= htmlspecialchars($e['staff_full_name']) ?></td>
                                    <td><?= htmlspecialchars($e['interaction_nature']) ?></td>
                                    <td><?= htmlspecialchars($e['follow_up_action']) ?></td>
                                    <td><?= htmlspecialchars($e['trace_score']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No engagements yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
