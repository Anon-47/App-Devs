<?php
// views/manage_users.php
require_once '../includes/session.php';
require '../includes/config.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['administrator', 'superuser'])) {
    header('Location: access_denied.php');  // Redirect if not an administrator
    exit();
}

// Fetch users from the database
try {
    $stmt = $pdo->query("SELECT * FROM users");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}

// Update user role
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_id']) && isset($_POST['role'])) {
    $userId = $_POST['user_id'];
    $newRole = $_POST['role'];

    try {
        $stmt = $pdo->prepare("UPDATE users SET role = :role WHERE id = :id");
        $stmt->bindParam(':role', $newRole);
        $stmt->bindParam(':id', $userId);
        $stmt->execute();
        header("Location: manage_users.php");  // Refresh page after role update
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
}
?>

    <title>Manage Users</title>
    <link rel="stylesheet" href="../assets/css/manage_users.css">
    
    <div class="manage-users-container">
        <h1>Manage Users</h1>
        
        <!-- Action Buttons -->
        <div class="action-buttons">
            <button class="btn create-user" onclick="window.location.href='signup.php'">Create User</button>
            <button class="btn sort-users" onclick="sortUsers()">Sort</button>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
            <input type="text" id="searchName" placeholder="Search by Name" oninput="filterUsers()">
            <select id="filterRole" onchange="filterUsers()">
                <option value="">All Roles</option>
                <option value="Superuser">Superuser</option>
                <option value="Administrator">Administrator</option>
                <option value="Manager">Manager</option>
                <option value="User">User</option>
            </select>
        </div>

        <!-- User Table -->
        <table class="user-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="userTableBody">
                <!-- Dummy Data for Illustration -->
                <!-- <tr>
                    <td>Jane Doe</td>
                    <td>jane.doe@example.com</td>
                    <td>Administrator</td>
                    <td>
                        <button class="btn modify-btn" onclick="modifyUser('Jane Doe')">Modify</button>
                    </td>
                </tr>
                <tr>
                    <td>John Smith</td>
                    <td>john.smith@example.com</td>
                    <td>Manager</td>
                    <td>
                        <button class="btn modify-btn" onclick="modifyUser('John Smith')">Modify</button>
                    </td>
                </tr> -->

                <!-- Further user rows populated dynamically -->
                <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td><?php echo htmlspecialchars($user['role']); ?></td>
                <td>
                    <form method="POST" action="manage_users.php">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <select name="role">
                            <option value="user" <?php if ($user['role'] === 'user') echo 'selected'; ?>>User</option>
                            <option value="manager" <?php if ($user['role'] === 'manager') echo 'selected'; ?>>Manager</option>
                            <option value="administrator" <?php if ($user['role'] === 'administrator') echo 'selected'; ?>>Administrator</option>
                            <option value="superuser" <?php if ($user['role'] === 'superuser') echo 'selected'; ?>>Superuser</option>
                        </select>
                        <button type="submit">Update Role</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script src="../public/js/manage_users.js"></script>


    <!-- <h1>User Management</h1>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td><?php echo htmlspecialchars($user['role']); ?></td>
                <td>
                    <form method="POST" action="manage_users.php">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <select name="role">
                            <option value="user" <?php if ($user['role'] === 'user') echo 'selected'; ?>>User</option>
                            <option value="manager" <?php if ($user['role'] === 'manager') echo 'selected'; ?>>Manager</option>
                            <option value="administrator" <?php if ($user['role'] === 'administrator') echo 'selected'; ?>>Administrator</option>
                            <option value="superuser" <?php if ($user['role'] === 'superuser') echo 'selected'; ?>>Superuser</option>
                        </select>
                        <button type="submit">Update Role</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table> -->
