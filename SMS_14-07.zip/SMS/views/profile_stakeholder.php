<?php
// Fetch stakeholder data
require_once '../includes/config.php';

$stakeholder_id = $_GET['id'] ?? null;

if (!$stakeholder_id) {
    echo "Invalid stakeholder ID.";
    exit;
}

$stmt = $pdo->prepare("SELECT s.*, u.email as manager_email FROM stakeholders s LEFT JOIN users u ON s.relationship_manager = u.id WHERE s.id = ?");
$stmt->execute([$stakeholder_id]);
$stakeholder = $stmt->fetch();

if (!$stakeholder) {
    echo "Stakeholder not found.";
    exit;
}

// Fetch related engagements
$engagements_stmt = $pdo->prepare("SELECT * FROM stakeholder_engagements WHERE stakeholder_id = ? ORDER BY interaction_date DESC");
$engagements_stmt->execute([$stakeholder_id]);
$engagements = $engagements_stmt->fetchAll();

$profileImage = !empty($stakeholder['profile_image']) && file_exists("../uploads/" . $stakeholder['profile_image'])
    ? "../uploads/" . $stakeholder['profile_image']
    : "../assets/images/blank-profile.png";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Stakeholder Profile</title>
    <link rel="stylesheet" href="../assets/css/stakeholder_profile.css">
    <style>
        .upload-form {
            margin-top: 10px;
            text-align: center;
        }
        .upload-form input[type="file"] {
            margin: 5px 0;
        }
        .upload-form button {
            padding: 5px 10px;
        }
        .styled-table {
            width: 100%;
            border-collapse: collapse;
            font-family: 'Segoe UI', sans-serif;
            background-color: #1f1f1f;
            color: #f0f0f0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.4);
            border-radius: 6px;
            overflow: hidden;
            margin-top: 15px;
            font-size: 0.95rem;
        }

        .styled-table th {
            background-color: #ff8c00;
            color: #fff;
            text-align: left;
            padding: 12px 15px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .styled-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #333;
            vertical-align: top;
        }

        .styled-table tr:nth-child(even) {
            background-color: #2a2a2a;
        }

        .styled-table tr:hover {
            background-color: #373737;
            transition: background 0.3s ease;
        }

        .engagement-history {
            overflow-x: auto;
            padding-bottom: 10px;
        }

    </style>
</head>
<body>
    <div class="profile-container">
        <!-- Header section -->
        <div class="profile-header">
            <div class="image-container">
                <img src="<?= $profileImage ?>" alt="Stakeholder Image" style="width:120px;height:120px;border-radius:50%;object-fit:cover;">
            </div>
            <h2><?= htmlspecialchars($stakeholder['s_name']) ?></h2>
            <p><?= htmlspecialchars($stakeholder['designation']) ?> @ <?= htmlspecialchars($stakeholder['organization']) ?></p>

            <!-- Profile Picture Upload -->
            <form class="upload-form" action="../scripts/upload_profile_image.php" method="POST" enctype="multipart/form-data">
                <input type="file" name="profile_image" accept="image/*" required>
                <input type="hidden" name="stakeholder_id" value="<?= $stakeholder_id ?>">
                <button type="submit">Upload Image</button>
            </form>
        </div>

        <!-- Info Cards -->
        <div class="card-grid">
            <div class="info-card"><h3>Email</h3><p><?= htmlspecialchars($stakeholder['email']) ?></p></div>
            <div class="info-card"><h3>Contact</h3><p><?= htmlspecialchars($stakeholder['contact']) ?></p></div>
            <div class="info-card"><h3>Organization Type</h3><p><?= htmlspecialchars($stakeholder['organization_type']) ?></p></div>
            <div class="info-card"><h3>Location</h3><p><?= htmlspecialchars($stakeholder['location']) ?></p></div>
            <div class="info-card"><h3>Influence Level</h3><p><?= htmlspecialchars($stakeholder['influence_level']) ?></p></div>
            <div class="info-card"><h3>Interest Level</h3><p><?= htmlspecialchars($stakeholder['interest_level']) ?></p></div>
            <div class="info-card"><h3>Relationship Manager</h3><p><?= htmlspecialchars($stakeholder['manager_email']) ?></p></div>
        </div>

        <!-- Engagement Activity Log -->
        <div class="activity-section">
            <h3>Engagement Activity</h3>
            <div class="activity-log" id="engagement-log">
                <div class="engagement-history">
                
                <?php if (count($engagements) > 0): ?>
                    <table class="styled-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Relationship Manager</th>
                                <th>Nature</th>
                                <th>Action Notes</th>
                                <th>TRACE Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($engagements as $e): ?>
                                <tr>
                                    <td><?= htmlspecialchars(date('Y-m-d', strtotime($e['interaction_date']))) ?></td>
                                    <td><?= htmlspecialchars($e['staff_full_name']) ?></td>
                                    <td><?= htmlspecialchars($e['interaction_nature']) ?></td>
                                    <td><?= htmlspecialchars($e['follow_up_action']) ?></td>
                                    <td><?= htmlspecialchars($e['trace_score']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No engagements yet.</p>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- <script>
        const stakeholderId = <?= json_encode($stakeholder_id) ?>;

        fetch(`../api/engagements.php?stakeholder_id=${stakeholderId}`)
            .then(res => res.json())
            .then(data => {
                const container = document.getElementById('engagement-log');
                if (data.length === 0) {
                    container.innerHTML = "<p>No engagement records yet.</p>";
                } else {
                    data.forEach(item => {
                        const logItem = document.createElement('div');
                        logItem.classList.add('log-entry');
                        logItem.innerHTML = `
                            <strong>${item.date_of_interaction}</strong> - 
                            ${item.nature_of_interaction} <br>
                            <em>By ${item.tsl_contact_staff}</em>
                            <p>${item.additional_notes || ''}</p>
                        `;
                        container.appendChild(logItem);
                    });
                }
            })
            .catch(err => {
                document.getElementById('engagement-log').innerHTML = "<p>No engagements yet.</p>";
            });
    </script> -->
</body>
</html>
