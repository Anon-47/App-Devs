<?php
session_start();
require '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'superuser') {
    die("Unauthorized access.");
}

// Fetch logs
$stmt = $pdo->query("SELECT logs.*, users.full_name FROM logs JOIN users ON logs.user_id = users.id ORDER BY logs.timestamp DESC");
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>System Logs</h2>
<table>
    <tr>
        <th>User</th>
        <th>Action</th>
        <th>Timestamp</th>
    </tr>
    <?php foreach ($logs as $log): ?>
    <tr>
        <td><?= $log['full_name'] ?></td>
        <td><?= $log['action'] ?></td>
        <td><?= $log['timestamp'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>
