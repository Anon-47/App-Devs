<?php
require '../includes/config.php';

if (!isset($_GET['id'])) {
    echo "No stakeholder selected.";
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM stakeholders WHERE id = ?");
$stmt->execute([$id]);
$stakeholder = $stmt->fetch();

if (!$stakeholder) {
    echo "Stakeholder not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Evaluate Stakeholder</title>
    <link rel="stylesheet" href="../assets/css/forms.css">
    <style>
        body {
            background-color: #0f141e;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            background-color: #101622;
            max-width: 1000px;
            margin: 40px auto;
            padding: 30px;
            border-radius: 12px;
            color: white;
        }

        h2 {
            text-align: center;
            color: orange;
            margin-bottom: 30px;
        }

        .info-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: flex-start;
        }

        .info-card {
            flex: 1 1 280px;
            background-color: #1e2a3a;
            padding: 15px 20px;
            border-radius: 10px;
        }

        .info-card b {
            color: orange;
            display: block;
            margin-bottom: 5px;
        }

        .rating-section {
            margin-top: 30px;
            background-color: #1e2a3a;
            padding: 20px;
            border-radius: 10px;
        }

        .rating-section label {
            color: orange;
            font-weight: bold;
            margin-right: 10px;
        }

        .star-display {
            font-size: 22px;
            color: #ffa500;
            letter-spacing: 3px;
            display: inline-block;
            position: center;
            vertical-align: middle;
        }

        .rating-section {
            margin-top: 30px;
            background-color: #1e2a3a;
            padding: 25px 20px;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .rating-section label {
            color: orange;
            font-weight: bold;
            margin-bottom: 10px;
            font-size: 18px;
        }

        .star-display {
            font-size: 22px;
            color: #ffa500;
            letter-spacing: 3px;
            margin-bottom: 15px;
        }

        .rating-section input[type="number"] {
            width: 80px;
            padding: 8px;
            font-size: 16px;
            text-align: center;
            border-radius: 5px;
            border: none;
            margin-bottom: 15px;
        }

        .rating-section button {
            padding: 10px 25px;
            background-color: orange;
            color: white;
            font-weight: bold;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: auto;
        }


        .popup {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #e6ffed;
            color: #155724;
            padding: 15px 20px;
            border-left: 6px solid #28a745;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            z-index: 9999;
            animation: slideFade 0.5s ease;
        }

        .popup.success::before {
            content: "✔️ ";
            font-weight: bold;
        }

        @keyframes slideFade {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<?php if (isset($_GET['status']) && $_GET['status'] === 'success'): ?>
    <div id="popupMessage" class="popup success">
        ✅ Rating updated successfully!
    </div>
    <script>
        setTimeout(() => {
            const popup = document.getElementById('popupMessage');
            if (popup) popup.style.display = 'none';
        }, 4000);
    </script>
<?php endif; ?>

<div class="container">
    <h2>Evaluate Stakeholder</h2>

    <div class="info-grid">
        <div class="info-card"><b>Full Name</b><?= htmlspecialchars($stakeholder['s_name']) ?></div>
        <div class="info-card"><b>Organization</b><?= htmlspecialchars($stakeholder['organization']) ?></div>
        <div class="info-card"><b>Designation</b><?= htmlspecialchars($stakeholder['designation']) ?></div>
        <div class="info-card"><b>Location</b><?= htmlspecialchars($stakeholder['location']) ?></div>
        <div class="info-card"><b>Organization Type</b><?= htmlspecialchars($stakeholder['organization_type']) ?></div>
        <div class="info-card"><b>Email</b><?= htmlspecialchars($stakeholder['email']) ?></div>
        <div class="info-card"><b>Contact</b><?= htmlspecialchars($stakeholder['contact']) ?></div>
        <div class="info-card"><b>Influence Level</b><?= htmlspecialchars($stakeholder['influence_level']) ?></div>
        <div class="info-card"><b>Interest Level</b><?= htmlspecialchars($stakeholder['interest_level']) ?></div>
    </div>

    <form class="rating-section" method="POST" action="../scripts/process_rating.php">
        <label for="rating">Rate Stakeholder</label>
        <div class="star-display" id="starDisplay"></div>

        <input type="number" id="rating" name="rating" min="0" max="5" step="0.5"
            value="<?= htmlspecialchars($stakeholder['rating']) ?>" required>

        <input type="hidden" name="id" value="<?= $stakeholder['id'] ?>">
        <button type="submit">Update Rating</button>
    </form>

</div>

<script>
    const input = document.getElementById("rating");
    const starDisplay = document.getElementById("starDisplay");

    function renderStars(val) {
        let fullStars = Math.floor(val);
        let halfStar = val % 1 >= 0.5 ? 1 : 0;
        let stars = "★".repeat(fullStars) + (halfStar ? "½" : "") + "☆".repeat(5 - fullStars - halfStar);
        starDisplay.textContent = stars;
    }

    input.addEventListener("input", () => renderStars(parseFloat(input.value) || 0));
    renderStars(parseFloat(input.value) || 0);
</script>

</body>
</html>
