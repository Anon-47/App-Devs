<?php
require '../includes/config.php';

if (!isset($_GET['id'])) {
    echo "No stakeholder selected.";
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM stakeholders WHERE id = ?");
$stmt->execute([$id]);
$stakeholder = $stmt->fetch();

if (!$stakeholder) {
    echo "Stakeholder not found.";
    exit;
}
session_start(); // if not already started
$performed_by = $_SESSION['user_email'] ?? 'Unknown';

$logStmt = $pdo->prepare("INSERT INTO stakeholder_audit_log (stakeholder_id, action_type, performed_by) VALUES (?, 'DELETE', ?)");
$logStmt->execute([$_GET['id'], $performed_by]);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Stakeholder</title>
    <link rel="stylesheet" href="../assets/css/forms.css">
    <style>
        body {
            background-color: #0f141e;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            background-color: #1e2a3a;
            color: white;
            width: 450px;
            margin: 100px auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 12px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: orange;
            margin-bottom: 25px;
        }

        .info-line {
            margin-bottom: 12px;
            text-align: center;
            font-size: 17px;
        }

        .info-line b {
            color: orange;
        }

        .warning {
            text-align: center;
            color: #ccc;
            margin-top: 15px;
            font-size: 15px;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 25px;
        }

        .btn-danger, .btn-cancel {
            padding: 10px 24px;
            font-size: 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s ease;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .btn-cancel {
            background-color: #6c757d;
            color: white;
        }

        .btn-cancel:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Confirm Delete</h2>

        <div class="info-line"><b>Name:</b> <?= htmlspecialchars($stakeholder['s_name']) ?></div>
        <div class="info-line"><b>Organization:</b> <?= htmlspecialchars($stakeholder['organization']) ?></div>
        <div class="info-line"><b>Designation:</b> <?= htmlspecialchars($stakeholder['designation']) ?></div>

        <p class="warning">Are you sure you want to delete this stakeholder? This action cannot be undone.</p>

        <form method="POST" action="../scripts/process_delete.php" onsubmit="return confirm('Permanently delete this stakeholder?');">
            <input type="hidden" name="id" value="<?= $stakeholder['id'] ?>">
            <div class="action-buttons">
                <button type="submit" class="btn-danger">Yes, Delete</button>
                <a href="javascript:history.back();" class="btn-cancel">Cancel</a>
            </div>
        </form>
    </div>

</body>
</html>
