<?php
require_once '../includes/session.php';
require '../includes/config.php';

try {
    $stmt = $pdo->query("SELECT * FROM stakeholders");
    $stakeholders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}

if (!isset($_SESSION['role'])) {
    try {
        $stmt = $pdo->prepare("SELECT role FROM users WHERE id = :user_id");
        $stmt->execute(['user_id' => $_SESSION['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        $_SESSION['role'] = $user ? $user['role'] : 'guest';
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
        exit();
    }
}

$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Stakeholders</title>
    <link rel="stylesheet" href="../assets/css/manage_stakeholders.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f3f4f6;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #444;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 4px rgba(0,0,0,0.08);
        }

        th, td {
            padding: 14px 16px;
            text-align: left;
        }

        th {
            background: #e5e7eb;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }

        tr:nth-child(even) {
            background-color: #f9fafb;
        }

        tr:hover {
            background-color: #f3f4f6;
        }

        a {
            text-decoration: none;
            color: #2563eb;
            font-weight: 500;
            transition: color 0.2s ease;
        }

        a:hover {
            color: #1e40af;
        }

        .actions a {
            margin-right: 8px;
            padding: 6px 10px;
            border-radius: 20px;
            background-color: #e5e7eb;
            font-size: 13px;
            display: inline-block;
        }

        .actions a:hover {
            background-color: #d1d5db;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        @media (max-width: 768px) {
            th, td {
                font-size: 13px;
                padding: 10px;
            }

            h1 {
                font-size: 22px;
            }
        }
    </style>
</head>

<body>
    <?php if (isset($_GET['status']) && $_GET['status'] === 'deleted'): ?>
        <div class="popup success" id="popupMessage">✅ Stakeholder deleted successfully!</div>
        <script>
            setTimeout(() => {
                const popup = document.getElementById('popupMessage');
                if (popup) popup.style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>
    
    <?php if (isset($_GET['status']) && $_GET['status'] === 'retired_success'): ?>
        <div class="popup success" id="popupMessage">✅ Stakeholder retired successfully!</div>
        <script>
            setTimeout(() => {
                const popup = document.getElementById('popupMessage');
                if (popup) popup.style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>


    <h1>Manage Stakeholders</h1>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Stakeholder</th>
                    <th>Organization</th>
                    <th>Designation</th>
                    <th>Location</th>
                    <th>Org Type</th>
                    <th>Influence</th>
                    <th>Interest</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($stakeholders as $stakeholder): ?>
                <tr>
                    <td><?= htmlspecialchars($stakeholder['s_name']) ?></td>
                    <td><?= htmlspecialchars($stakeholder['organization']) ?></td>
                    <td><?= htmlspecialchars($stakeholder['designation']) ?></td>
                    <td><?= htmlspecialchars($stakeholder['location']) ?></td>
                    <td><?= htmlspecialchars($stakeholder['organization_type']) ?></td>
                    <td><?= htmlspecialchars($stakeholder['influence_level']) ?></td>
                    <td><?= htmlspecialchars($stakeholder['interest_level']) ?></td>
                    <td class="actions">
                    <div class="action-row">
                        <a href="edit_stakeholder.php?id=<?= $stakeholder['id'] ?>">✏️ Edit</a>
                        <a href="profile_stakeholder.php?id=<?= $stakeholder['id'] ?>">👁 View</a>
                        <?php if ($role === 'superuser'): ?>
                            <a href="delete_stakeholder.php?id=<?= $stakeholder['id'] ?>">🗑 Delete</a>
                        <?php else: ?>
                            <span class="action-placeholder"></span>
                        <?php endif; ?>
                    </div>
                    <div class="action-row">
                        <a href="classify_stakeholder.php?id=<?= $stakeholder['id'] ?>">📌 Classify</a>
                        <a href="evaluate_stakeholder.php?id=<?= $stakeholder['id'] ?>">🧮 Evaluate</a>
                        <a href="retire_stakeholder.php?id=<?= $stakeholder['id'] ?>">📥 Retire</a>
                    </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
