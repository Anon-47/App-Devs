<!-- views/signup.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stakeholder Management - Sign Up</title>
    <link rel="stylesheet" href="../assets/css/login.css">
    <script src="https://cdn.jsdelivr.net/npm/vue@2"></script>
</head>
<body>
    <div class="signup-container">
        <div class="signup-form" id="signupApp">
            <h2>Create an Account</h2>
            <form method="POST" action="../scripts/process_signup.php">
                <div class="form-group">
                    <label for="fullName">Full Name:</label>
                    <input type="text" name="fullName" v-model="fullName" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" v-model="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" v-model="password" required>
                </div>
                <div class="form-group">
                    <label for="confirmPassword">Confirm Password:</label>
                    <input type="password" v-model="confirmPassword" required>
                </div>
                <button type="submit">Create Account</button>
            </form>
            <p>Already have an account? <a href="index.php">Log in here</a></p>
        </div>
    </div>

    <!-- Vue.js for sign-up form -->
    <script>
        new Vue({
            el: '#signupApp',
            data: {
                fullName: '',
                email: '',
                password: '',
                confirmPassword: ''
            },
            methods: {
                signUp(e) {
                    e.preventDefault();
                    if (this.password !== this.confirmPassword) {
                        alert("Passwords do not match!");
                        return;
                    }
                    console.log('Account creation attempt with:', this.fullName, this.email);
                    // Post data to backend for account creation
                }
            }
        });
    </script>
</body>
</html>
