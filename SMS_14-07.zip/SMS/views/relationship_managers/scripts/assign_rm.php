<?php
session_start();
require '../../includes/config.php';

// Check if user is authorized
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    die("Unauthorized access.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stakeholder_id = $_POST['stakeholder_id'];
    $rm_id = $_POST['rm_id'];
    $requested_by = $_SESSION['user_id'];

    // Insert into approvals table
    $sql = "INSERT INTO approvals (request_type, request_data, requested_by, status) 
            VALUES ('stakeholder_assignment', :data, :requested_by, 'pending')";
    $stmt = $pdo->prepare($sql);
    $data = json_encode(["stakeholder_id" => $stakeholder_id, "rm_id" => $rm_id]);
    $stmt->execute(['data' => $data, 'requested_by' => $requested_by]);

    // Fetch manager emails
    $manager_stmt = $pdo->query("SELECT email FROM users WHERE role = 'manager'");
    $managers = $manager_stmt->fetchAll(PDO::FETCH_COLUMN);

    // Send email notification
    $subject = "New Approval Request";
    $message = "A new stakeholder assignment request requires approval. Login to review.";
    $headers = "From: noreply@yourapp.com";

    foreach ($managers as $manager_email) {
        mail($manager_email, $subject, $message, $headers);
    }

    echo "Assignment request submitted for approval.";
}
?>
