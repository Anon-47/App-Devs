<?php
require '../../includes/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["user_id"])) {
    $user_id = $_POST["user_id"];

    $stmt = $pdo->prepare("UPDATE users SET role = 'relationship_manager' WHERE id = ?");
    if ($stmt->execute([$user_id])) {
        header("Location: ../index.php?success=RM added successfully");
    } else {
        header("Location: ../index.php?error=Failed to add RM");
    }
    exit();
}
?>
