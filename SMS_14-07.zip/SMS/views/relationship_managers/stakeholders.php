<?php include '../includes/head.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div class="container">
    <h2>Stakeholders Managed by RM</h2>
    <table>
        <thead>
            <tr><th>Name</th><th>Email</th><th>Phone</th></tr>
        </thead>
        <tbody>
            <?php
            require '../includes/config.php';
            $rm_id = $_GET['rm_id'] ?? 0;
            $stmt = $pdo->prepare("SELECT name, email, phone FROM stakeholders WHERE relationship_manager = ?");
            $stmt->execute([$rm_id]);
            while ($row = $stmt->fetch()) {
                echo "<tr><td>{$row['name']}</td><td>{$row['email']}</td><td>{$row['phone']}</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
