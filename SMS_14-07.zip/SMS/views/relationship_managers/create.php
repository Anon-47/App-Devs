<?php include '../includes/head.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div class="container">
    <h2>Create Relationship Manager</h2>
    <form action="scripts/add_rm.php" method="POST">
        <label for="user">Select User:</label>
        <select name="user_id">
            <?php
            require '../includes/config.php';
            $stmt = $pdo->query("SELECT id, full_name, email FROM users WHERE role != 'relationship_manager'");
            while ($row = $stmt->fetch()) {
                echo "<option value='{$row['id']}'>{$row['full_name']} ({$row['email']})</option>";
            }
            ?>
        </select>
        <button type="submit">Convert to RM</button>
    </form>
</div>
