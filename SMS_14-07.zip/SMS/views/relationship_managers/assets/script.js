document.addEventListener("DOMContentLoaded", function () {
    // Load Relationship Managers dynamically
    loadRelationshipManagers();
    
    // Event listener for form submission (Assign RM)
    document.getElementById("assignForm")?.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent default form submission
        assignStakeholderToRM();
    });
});

// Load Relationship Managers using AJAX
function loadRelationshipManagers() {
    fetch("scripts/fetch_rms.php")
        .then(response => response.json())
        .then(data => {
            let tableBody = document.getElementById("rmsTableBody");
            if (!tableBody) return;
            tableBody.innerHTML = "";
            
            data.forEach(rm => {
                let row = `
                    <tr>
                        <td>${rm.full_name}</td>
                        <td>${rm.email}</td>
                        <td><a href="stakeholders.php?rm_id=${rm.id}" class="btn btn-primary">View Assigned</a></td>
                        <td><a href="remove.php?rm_id=${rm.id}" class="btn btn-danger">Remove RM</a></td>
                    </tr>
                `;
                tableBody.innerHTML += row;
            });
        })
        .catch(error => console.error("Error loading RMs:", error));
}

// Assign Stakeholder to RM
function assignStakeholderToRM() {
    let stakeholderId = document.getElementById("stakeholderSelect").value;
    let rmId = document.getElementById("rmSelect").value;

    fetch("scripts/assign_rm.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `stakeholder_id=${stakeholderId}&rm_id=${rmId}`
    })
    .then(response => response.text())
    .then(data => {
        alert(data); // Show success message
        location.reload(); // Reload the page
    })
    .catch(error => console.error("Error assigning RM:", error));
}
