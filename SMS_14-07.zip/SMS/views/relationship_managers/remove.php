<?php
require '../includes/config.php';
$rm_id = $_GET['rm_id'] ?? 0;

$stmt = $pdo->prepare("UPDATE users SET role = 'user' WHERE id = ?");
$stmt->execute([$rm_id]);

header("Location: index.php?success=RM role removed");
exit();
?>
