<?php include '../includes/head.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div class="container">
    <h2>Relationship Managers</h2>
    <table>
        <thead>
            <tr>
                <th>Name</th><th>Email</th><th>Assigned Stakeholders</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            require '../includes/config.php';
            $stmt = $pdo->query("SELECT id, full_name, email FROM users WHERE role = 'relationship_manager'");
            while ($row = $stmt->fetch()) {
                echo "<tr>
                        <td>{$row['full_name']}</td>
                        <td>{$row['email']}</td>
                        <td><a href='stakeholders.php?rm_id={$row['id']}'>View Assigned</a></td>
                        <td><a href='remove.php?rm_id={$row['id']}'>Remove RM</a></td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
</div>
