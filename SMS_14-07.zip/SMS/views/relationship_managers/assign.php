<?php include '../includes/head.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div class="container">
    <h2>Assign Stakeholders to Relationship Manager</h2>
    <form action="scripts/assign_rm.php" method="POST">
        <label for="stakeholder">Select Stakeholder:</label>
        <select name="stakeholder_id">
            <?php
            require '../includes/config.php';
            $stmt = $pdo->query("SELECT id, name, email FROM stakeholders WHERE relationship_manager IS NULL");
            while ($row = $stmt->fetch()) {
                echo "<option value='{$row['id']}'>{$row['name']} ({$row['email']})</option>";
            }
            ?>
        </select>

        <label for="rm">Select Relationship Manager:</label>
        <select name="rm_id">
            <?php
            $stmt = $pdo->query("SELECT id, full_name FROM users WHERE role = 'relationship_manager'");
            while ($row = $stmt->fetch()) {
                echo "<option value='{$row['id']}'>{$row['full_name']}</option>";
            }
            ?>
        </select>

        <button type="submit">Assign</button>
    </form>
</div>
