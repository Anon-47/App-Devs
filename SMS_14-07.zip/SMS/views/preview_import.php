<?php
require '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file']['tmp_name'];
    $previewData = [];

    if (($handle = fopen($file, 'r')) !== FALSE) {
        $headers = fgetcsv($handle);
        while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
            $previewData[] = $data;
        }
        fclose($handle);

        // Store in session for processing
        session_start();
        $_SESSION['preview_data'] = $previewData;
    }
}
?>

<h2>Preview Stakeholder Data</h2>
<form action="confirm_import.php" method="post">
    <table border="1" cellpadding="5">
        <tr>
            <th>Name</th><th>Email</th><th>Phone</th><th>Category</th><th>Manager Email</th>
        </tr>
        <?php foreach ($previewData as $row): ?>
            <tr>
                <?php foreach ($row as $cell): ?>
                    <td><?= htmlspecialchars($cell) ?></td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <button type="submit">Confirm Import</button>
</form>
