<?php
// dashboard_base.php (Admin Dashboard View)
require_once '../includes/session.php';
require_once '../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../views/index.php');
    exit;
}

$role = $_SESSION['role'] ?? 'guest';
if ($role !== 'superuser' && $role !== 'admin') {
    echo "Access Denied.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        .chart-card {
            background: #fff;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .chart-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <h2 style="text-align:center;">Admin Dashboard</h2>
    <div class="dashboard-grid">

        <div class="chart-card">
            <div class="chart-title">Users by Role</div>
            <canvas id="userRoleChart"></canvas>
        </div>

        <div class="chart-card">
            <div class="chart-title">Engagement Types</div>
            <canvas id="engagementTypeChart"></canvas>
        </div>

        <div class="chart-card">
            <div class="chart-title">Unit Activity (Most/Least)</div>
            <canvas id="unitActivityChart"></canvas>
        </div>

        <div class="chart-card">
            <div class="chart-title">Database Summary</div>
            <ul id="dbSummary"></ul>
        </div>

    </div>

<script>
// Fetch and render dashboard data
fetch('../api/admin_dashboard_data.php')
    .then(res => res.json())
    .then(data => {
        const ctx1 = document.getElementById('userRoleChart');
        new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: Object.keys(data.user_roles),
                datasets: [{
                    label: 'Users',
                    data: Object.values(data.user_roles),
                    backgroundColor: 'rgba(54, 162, 235, 0.6)'
                }]
            },
            options: { responsive: true }
        });

        const ctx2 = document.getElementById('engagementTypeChart');
        new Chart(ctx2, {
            type: 'pie',
            data: {
                labels: Object.keys(data.engagement_types),
                datasets: [{
                    data: Object.values(data.engagement_types),
                    backgroundColor: ['#4caf50', '#ff9800', '#f44336', '#2196f3']
                }]
            },
            options: { responsive: true }
        });

        const ctx3 = document.getElementById('unitActivityChart');
        new Chart(ctx3, {
            type: 'horizontalBar',
            data: {
                labels: data.units.map(u => u.name),
                datasets: [{
                    label: 'Engagements',
                    data: data.units.map(u => u.count),
                    backgroundColor: 'rgba(255, 206, 86, 0.6)'
                }]
            },
            options: { responsive: true }
        });

        const summary = document.getElementById('dbSummary');
        summary.innerHTML = `
            <li><strong>Users:</strong> ${data.summary.users}</li>
            <li><strong>Stakeholders:</strong> ${data.summary.stakeholders}</li>
            <li><strong>Engagements:</strong> ${data.summary.engagements}</li>
        `;
    })
    .catch(err => console.error('Dashboard fetch error:', err));
</script>
</body>
</html>
