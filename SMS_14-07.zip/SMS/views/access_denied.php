<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Access Denied</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #1e1e1e;
      color: #f0f0f0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      overflow: hidden;
    }

    .denied-box {
      background-color: #2b2b2b;
      padding: 40px 50px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.4);
      text-align: center;
      animation: fadeIn 0.8s ease;
    }

    .denied-box h1 {
      font-size: 3em;
      color: #d38e0d;
      margin-bottom: 10px;
    }

    .denied-box p {
      font-size: 1.1em;
      margin-bottom: 30px;
      color: #ccc;
    }

    .btn-home {
      background-color: #d38e0d;
      color: #1e1e1e;
      padding: 12px 24px;
      border: none;
      border-radius: 6px;
      font-size: 1em;
      cursor: pointer;
      transition: background-color 0.3s ease;
      text-decoration: none;
      display: inline-block;
    }

    .btn-home:hover {
      background-color: #f0a000;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<script>
  setTimeout(() => window.location.href = 'dashboard.php', 8000);
</script>

<body>

  <div class="denied-box">
    <h1>Access Denied</h1>
    <p>You do not have the necessary permissions to view this page.</p>
    <a href="dashboard.php" class="btn-home">← Back to Dashboard</a>
  </div>

</body>
</html>
